# 本地存储法 —— 分片落盘缓存 Repack 方案（Local-Storage Chunked Cached Repack，简称 LSCR）

> 面向《空洞骑士》手机版（Android, 32 位, 约 1G 内存）的 Enemy Randomizer 预载优化方案。
> 本文档写给另一位 AI 作为独立实施参考：背景、已查证的源码事实、方案架构、具体改造点、数据结构、风险与验证步骤均在此，可按文档直接动手。

---

## 1. 背景与问题

### 1.1 运行环境
- 游戏：Hollow Knight 手机版（Android），包名 `com.TeamCherry.HollowKnight`，**32 位进程（armv7）**，设备约 **1G 物理内存**。
- ModLoader 机制：手机版 **Modding API 内嵌在 `Assembly-CSharp.dll`**（APK 中搜不到独立 `Modding.dll`，已确认）。
- Mod：Enemy Randomizer 官方原版（`2023.0.8580.23150`，逐字节等于 PC release）。

### 1.2 两条预载路线的困境
ModLoader 启动时 `Preloader.Preload()`（`Modding.Preloader` 类）会把 mod 需要预载的游戏对象从场景里取出来。有两条路线：

| 路线 | 原理 | 手机实测 |
|------|------|---------|
| **FullScene** | 逐个完整加载场景（`SceneManager.LoadSceneAsync(Additive)`），取对象后卸载 | 可行但**极慢**：166 个场景约 **532 秒**，每次启动都重跑（结果只存内存不落盘） |
| **RepackAssets** | 用 Rust 库 `unity-scene-repacker` 把场景重打包成只含目标对象的 AssetBundle | 快，但需解析游戏数据文件（约 **700MB**），32 位 + 1G 内存直接 **OOM 崩溃** |

现状：Android 上因 Rust 原生库加载失败自动回退 FullScene（日志 `Android detected. Changing to full scene loads.`），1G 老爷机能进但每次等 9 分钟；大内存设备反而因 FullScene 批载 5 场景内存峰值高而崩，或没耐心等。

### 1.3 本方案目标
- 让 **RepackAssets 优化路线在 1G 内存下不 OOM**。
- 预载结果**落盘缓存**，后续启动秒进、跳过 700MB 解析与 532 秒全场景加载。
- 支持**断点续传**（中断后从已完成处继续）、**容错**（单场景失败跳过）、**增量**（只处理未完成的场景）。

---

## 2. 已查证的关键源码事实

所有结论均基于对以下仓库源码的阅读（已克隆到本地）：

- 上游：`https://github.com/jakobhellermann/unity-scene-repacker`（Rust）
- 解析库：`https://github.com/jakobhellermann/rabex`（crates.io 上的 `rabex`）
- 环境层：`https://github.com/jakobhellermann/rabex-env`
- 实施者 fork：`3901827159-cloud/Unity-scene-repacker`（含 `build-android-armv7.yml`）

### 2.1 C# 侧（Modding API，内嵌在手机 Assembly-CSharp.dll）
- 对应 PC 开源源码 `hkmodding-src/Preloader.cs`：
  - `Preload()`（行 31-94）：按 `ModHooks.GlobalSettings.PreloadMode` 分发；`RepackAssets` 模式依赖 Rust 原生库，`Marshal.PrelinkAll(typeof(UnitySceneRepacker))` 抛 `DllNotFoundException` 时回退 `FullScene`（行 49-61）。手机版日志 `Android detected...` 即此定制分支。
  - `DoPreloadAssetBundle()`（行 101-217）：`AssetBundle.LoadFromMemoryAsync(bundleData)` 加载 Rust 产出的 bundle，然后按 `{sceneName}/{path}.prefab`（**小写**）`LoadAssetAsync<GameObject>`。
  - `DoPreloadScenes()`（行 290-462）：FullScene 实现，`PreloadBatchSize`（默认 5）个场景并发加载。
- `UnitySceneRepacker.cs`：`DllImport("unityscenerepacker")` 调 `export(...)`；返回的 bundle 字节经 `Marshal.Copy` 整份拷入托管数组（行 89-98）→ 再 `LoadFromMemoryAsync` → **bundle 在内存里叠 3 份**（Rust 原生 + 托管拷贝 + Unity 内部加载）。

### 2.2 Rust 侧（unity-scene-repacker）
- `bindings/src/lib.rs`：
  - `export()`（行 37-76）：C ABI，入参 `(name, game_dir, preload_json, error, bundle_size, bundle_data, stats_ret, mb_typetree_export, mb_typetree_len, mode)`；`mode` 0=SceneBundle, 1=AssetBundle, 2=AssetBundleShallow。返回 `bundle_data` 指针 + `bundle_size`。
  - `export_inner()`（行 91-196）：解析 JSON → `repack_settings = { scene_objects, extra_objects: IndexMap::new() }` → `GameFiles::probe(game_dir)` → `Environment::new` → **AssetBundle 模式**（mode=1）时走 `repack_scenes` + `pack_to_asset_bundle`。
- `src/lib.rs`：
  - `repack_scenes()`（行 60-100）→ `collect_what_to_repack()`（行 103-213）：
    - `has_extra_objects` 为 false 时：`scene_files.par_iter()` **并行**读取所有请求场景的 `level{index}` 文件并逐个 `repack_scene`（行 202-208）。**所有 `RepackScene` 累积到 Vec 直到打包结束。**
    - `has_extra_objects` 为 true 时：`env.game_files.serialized_files()` 全量并行遍历（更吃内存；当前 EnemyRandomizer 场景未用到，但保留扩展性）。
  - `repack_scene()`（行 220-258）：`rabex_env::reachable::prune::prune_scene` 做可达性分析（跨文件解析依赖对象，数据经 `Environment` 持有）；产出 `RepackScene { serialized(完整对象表), serialized_data(完整文件字节), keep_objects, roots, replacements, monobehaviour_types }`。**每个场景的完整字节 + 对象表在此常驻。**
  - `pack_to_asset_bundle()`（行 438-569）：
    - `intermediate` Vec（行 466-529）：每个场景 `add_scene_meta_to_builder` 后保留 `(scene, remap)`。
    - `objects`（行 531-547）：`into_par_iter()` 对每个对象 `merge_serialized::remap_objects` 产出 `(ObjectInfo, Cow<[u8]>)` 双层 Vec——**与 `intermediate`、`builder.objects` 三份叠加持有。**
  - `pack_to_scene_bundle()`（行 338-431）：SceneBundle 模式，每场景一个独立 serialized 文件；trim 逻辑（行 380-424，`retain keep_objects` + `prune_types` + `write_serialized_with_objects`）可作为**中间文件生成模板**。
- `src/merge_serialized.rs`：
  - `add_scene_meta_to_builder()`（行 23-77）：把场景的 types / externals / scriptTypes 并入 builder，产出 path_id/file_id/types 重映射表。
  - `remap_objects()`（行 79-127）：对每个对象用 **typetree**（优先 `monobehaviour_types`，否则 `file.get_typetree_for`）做 PPtr 就地重写（`replace_pptrs_inplace_endianed`）。
- `rabex-env/src/resolver/game_files.rs`：
  - `GameFiles::probe_inner()`（行 82-100）：`data.unity3d` 存在则 `Mmap::map` 整个 bundle → `BundleFileReader`（**mmap，bundle 本体不占物理内存**）。
  - `read_path()`（行 180-188）：解包目录返回 mmap；Packed 模式 `read_at` 返回 `Vec<u8>`（解压后的完整文件字节，**这是内存大头之一**）。

### 2.3 内存爆炸点总结
1. `collect_what_to_repack` 用 `par_iter` 并行解析所有场景，且所有 `RepackScene` 全量累积（`src/lib.rs:202-208` + `collect` 结果）。
2. 每个 `RepackScene` 持有完整 `serialized_data` + 对象表，直到打包（`src/lib.rs:248-257`）。
3. AssetBundle 合并阶段 `intermediate` / `objects` / `builder.objects` 三份持有（`src/lib.rs:466-555`）。
4. 最终 bundle 走 `Marshal.Copy` + `LoadFromMemoryAsync` 三份拷贝（`hkmodding-src/UnitySceneRepacker.cs:89-98` + `Preloader.cs:146`）。

---

## 3. 方案总体架构

**分三层，逐层递进。Layer 1 只动 Rust（重编 .so，C# 侧完全不用动，风险最低），先做；Layer 2 需改内嵌在 Assembly-CSharp 的 Preloader（风险高）；Layer 3 可选。**

```
┌─────────────────────────────────────────────────────────────┐
│  Layer 1（本方案核心，纯 Rust/.so）                          │
│  「分片 + 中间产物落盘 + 断点续传 + 容错」                    │
│  把 700MB 解析从"一次全载"改为"单场景处理、用后即弃"        │
│  输出仍为单个 AssetBundle（C# 加载逻辑不变）                 │
├─────────────────────────────────────────────────────────────┤
│  Layer 2（改 Assembly-CSharp.dll 内嵌 Preloader）            │
│  LoadFromMemory → LoadFromFile 流式加载，砍掉 3 份拷贝       │
│  启动检查本地缓存 → 命中直接加载，跳过 repack（秒进）        │
├─────────────────────────────────────────────────────────────┤
│  Layer 3（可选）                                             │
│  依赖裁剪 / extra_objects 支持 / 压缩（LZ4）等进一步瘦身     │
└─────────────────────────────────────────────────────────────┘
```

**为什么分 Layer：** Layer 1 解决"解析 700MB 阶段 OOM"；即便成功，最终 bundle 若 > 约 200MB，在 1G 设备上仍会因 3 份拷贝 OOM——那是 Layer 2 的职责。两层都做完才能"既快又不爆"。

---

## 4. Layer 1：分片落盘 Repack（本方案核心）

### 4.1 总流程

```
输入：game_dir, preload_json, cache_dir, resume(bool)
输出：cache_dir/final.unity3d（单个 AssetBundle）+ manifest.json

[Phase 0] 读取 cache_dir/manifest.json（resume 时）
[Phase 1] 分批处理（顺序，单场景内存）
   对每批（默认 8 个场景/批）：
     1. repack_scenes(仅本批场景)          # 去并行，或限制 rayon 线程数=1
     2. 对每个 RepackScene 立即生成中间文件  # 见 4.3 格式
        - scene.{i}.serialized   (trimmed 序列化文件)
        - scene.{i}.meta.json    (roots / externals / scriptTypes / mb-typetree)
     3. 丢弃 RepackScene，内存释放
     4. 更新 manifest：该场景 done
   单场景报错 → manifest 记 failed，继续下一个场景（容错）
[Phase 2] 合并（内存小：只读中间文件，均为 trimmed 小文件）
   读入所有 done 场景的中间文件
   用 merge_serialized 逻辑合并进单 SerializedFileBuilder
   构建 AssetBundle.m_Container（prefab 路径 → PathID，小写）
   写入 cache_dir/final.unity3d
   返回 bundle 字节/路径
```

### 4.2 具体改造点（Rust）

**A. `bindings/src/lib.rs`：新增 `export_batched` C ABI 入口**

保留原 `export`（兼容），新增：

```c
// 新增入参：cache_dir, resume_flag
export_batched(
  name, game_dir, preload_json,
  cache_dir, resume_flag,
  error, out_final_path /* 或仍返回字节 */,
  stats_ret, mb_typetree_export, mb_typetree_len, mode
)
```

推荐返回**最终 bundle 文件路径**（字符串），而非内存字节——为 Layer 2 的 `LoadFromFile` 铺路；同时避免大 bundle 在 C#/Rust 间再拷贝一次。若手机 C# 侧暂不改（只做 Layer 1），则仍需返回字节指针（C# 现有 `export` 调用签名不变），此时 Layer 1 已解决解析 OOM，但最终 bundle 仍会叠 3 份，需控制产物大小。

**B. `src/lib.rs`：给 `collect_what_to_repack` 增加"分批/回调式"变体**

新增一个按单场景回调的收集函数（替代 `par_iter`）：

```rust
// 伪代码：逐场景处理，每场景处理完立即回调，调用方负责落盘+释放
pub fn repack_scenes_batched(
    env: &Environment,
    repack_settings: RepackSettings,
    batch_size: usize,
    on_scene_done: impl Fn(&Path, &str, RepackScene) -> Result<()>,
) -> Result<Vec<ExtraObject>> {
    // 1. 解析出 (scene_name -> level{index}) 映射，去除 par_iter，顺序循环
    // 2. 每批调用 repack_scene，得到 RepackScene
    // 3. 立即 on_scene_done(scene) 落盘，随后 drop RepackScene
    // 4. 单场景 Err 时：由调用方决定记录 failed 继续，不 `?` 上抛
}
```

内存要点：
- **去掉 `par_iter`**（或 `rayon::ThreadPoolBuilder::num_threads(1)`）——顺序处理。
- 每个 `RepackScene` 处理完立即销毁（作用域结束即 drop），`serialized_data`/`serialized`/`replacements` 随之释放。
- Phase 1 峰值内存 = 单批场景的解析 + 中间小文件，与场景总数无关。

**C. 中间文件生成**（复用 `pack_to_scene_bundle` 的 trim 逻辑，`src/lib.rs:380-424` 提取成函数）

```rust
fn trim_scene_to_file(scene: &RepackScene, out_serialized: &Path, out_meta: &Path) -> Result<()> {
    // serialized: retain(keep_objects) + prune_types + 用 replacements 覆盖对象数据
    //            + write_serialized_with_objects -> out_serialized
    // meta(json): scene.scene_name, original_name,
    //            roots (prefab 路径 -> GameObject pathID),
    //            m_Externals 映射, m_ScriptTypes,
    //            monobehaviour_types (pathID -> typetree, 见 4.4 风险)
}
```

**D. `src/lib.rs`：`pack_to_asset_bundle_from_intermediate`（Phase 2）**

不改原 `pack_to_asset_bundle` 主体逻辑，只把输入从 `Vec<RepackScene>` 换成"从中间文件重建的轻量场景结构"：
- 读 `scene.{i}.serialized` → `SerializedFile`（trimmed，小）。
- 读 `scene.{i}.meta.json` 恢复 `roots` / `monobehaviour_types`（需要拥有所有权的 typetree 容器，见风险）。
- 复用现有 `add_scene_meta_to_builder` + `remap_objects` 做合并（`merge_serialized.rs` 无需改动）。
- 写 `final.unity3d`（AssetBundle 模式，m_Container 用小写 `{scene}/{path}.prefab` 键，与 C# 查找一致）。

### 4.3 中间文件与 manifest 格式

```
cache_dir/
├── manifest.json
├── scene.000.serialized      # trimmed 序列化文件
├── scene.000.meta.json
├── scene.001.serialized
├── scene.001.meta.json
└── final.unity3d             # Phase 2 完成后生成
```

`manifest.json`：

```json
{
  "version": 1,
  "mode": "AssetBundle",
  "bundle_name": "modding_api_asset_bundle",
  "scenes": {
    "Room_Colosseum_Bronze": { "status": "done",   "idx": 12 },
    "Crossroads_01":          { "status": "done",   "idx": 30 },
    "Ruins1_27":              { "status": "failed", "idx": 58 },
    "Fungus2_04":             { "status": "pending", "idx": 91 }
  },
  "failed": ["Ruins1_27"],
  "final_bundle": "final.unity3d",
  "stats": { "objects_before": 505, "objects_after": 412 }
}
```

**断点续传语义：**
- `resume=false`：清空 cache_dir，全量重建。
- `resume=true`：`status=done` 的场景直接跳过 Phase 1，只处理 `pending`；`failed` 的场景默认跳过（可加 `retry_failed` 标志重试）。
- 任何时刻进程被杀：已 `done` 的场景不重做，下次从中断处继续。

**容错语义：** `repack_scene` 返回 Err（如场景文件缺失、对象找不到、依赖解析失败）→ 记 `failed`，`?` 不上抛，流程继续；Phase 2 只合并 `done` 场景。C# 侧拿到缺失场景的对象时本就有"找不到则跳过"的兜底（`Preloader.cs:382-386`）。

### 4.4 风险与权衡（必须提前告知实施 AI）

1. **typetree 依赖（最大不确定点）**：`remap_objects` 做 PPtr 重写需要每个对象的 typetree。
   - 若 HK 原始 level 文件**带 typetree**（`m_EnableTypeTree=true`，多数 Unity 安卓包如此）→ trimmed 中间文件保留 typetree，Phase 2 用 `file.get_typetree_for` 即可，**无需 meta 存 typetree**。
   - 若不带（或 MonoBehaviour 部分）→ 必须在 Phase 1 把 `monobehaviour_types`（`FxHashMap<PathId, &TypeTreeNode>`）序列化进 meta，Phase 2 反序列化重建。注意 `&TypeTreeNode` 是借用引用，需改成拥有所有权/由 `TypeTreeCache` 持有再借用。**实施前先确认原始 level 文件的 `m_EnableTypeTree` 值。**
2. **Phase 2 合并仍是全量小文件进内存**：trimmed 文件总量 = 505 个对象的依赖，可能几十到两三百 MB。1G 设备可接受，但若超出需把 Phase 2 也做"部分合并 + 增量归并"（manifest 记录中间合并产物）。
3. **最终 bundle 3 份拷贝仍在**（Layer 1 不解决）：若最终 bundle > ~200MB，C# `LoadFromMemoryAsync` 阶段仍可能 OOM。→ 必须推进 Layer 2，或缩小预载池。
4. **顺序处理变慢**：去掉并行后单次 repack 时间变长，但只在首次/未完成场景上付出，且可接受。
5. **产物一致性**：分批合并后 pathID 重映射与一次性合并**顺序相关**，`builder.get_next_path_id()` 按处理顺序分配——分批顺序必须稳定（按场景名排序处理），否则两次运行产物 pathID 不同。对功能无影响，但缓存校验时应按场景清单校验而非 pathID。

---

## 5. Layer 2：C# 侧流式加载 + 缓存（需改 Assembly-CSharp）

### 5.1 现状
- 手机版 Modding API 内嵌在 `Assembly-CSharp.dll`（APK 内无独立 `Modding.dll`）。
- `Preloader.DoPreloadAssetBundle` 用 `AssetBundle.LoadFromMemoryAsync(bundleData)`：整份 bundle 先进内存 + Unity 内部再拷一份。

### 5.2 改造
参照 PC 源码 `hkmodding-src/Preloader.cs`，把 `DoPreloadAssetBundle` 改为：
1. **缓存检查**：启动时查 `persistentDataPath/ModdingApi.PreloadCache/final.unity3d` 是否存在且 manifest 全 done → 直接 `AssetBundle.LoadFromFile(path)`，跳过 Rust `export` 调用。
2. **流式加载**：`LoadFromFile` 替代 `LoadFromMemoryAsync`——Unity 按需从磁盘读取，不再整份进内存，砍掉 `Marshal.Copy` 和内部拷贝。
3. **首次构建**：调 `export_batched(..., cache_dir, resume=true)`，完成后缓存 bundle + manifest。

### 5.3 实施方式与风险
- 手机端是 Mono 架构（能跑托管 mod），`Assembly-CSharp.dll` 可从 APK 提取、反编译修改、重新打包（需绕过签名或使用已 root 环境 / 替换式安装）。
- 也可考虑用 **Hook 方案**（MonoMod/MonoMod.RuntimeDetour 已在 mod 目录有 `MMHOOK_Assembly-CSharp.dll`）**不改 Assembly-CSharp**，而是做一个"预载缓存管理 mod"：启动早期 hook 住 preload 流程，替代 Preloader 行为。**这是更安全的替代路线，优先评估。**
- 风险：内嵌 ModLoader 的 Assembly-CSharp 是手机版定制构建，改动后需与游戏本体版本严格匹配；替换失败会导致游戏无法启动（有备份/回滚预案）。

---

## 6. 验证与部署步骤

1. **PC 上先验证 Rust 逻辑**：
   - 用 PC 版 HK 数据目录跑 `export_batched`（分批 + 断点 + 容错），对比"一次性 repack"产物的 `Stats.objects_after` 是否一致、`final.unity3d` 能否被 C# 侧正常加载。
   - 手动中断进程再 resume，确认 `done` 场景被跳过、`pending` 被续做、`failed` 被跳过。
2. **确认 typetree**：检查 HK 安卓 `level*` 文件 `m_EnableTypeTree`，决定 meta 是否存 typetree。
3. **交叉编译**：复用现有 `build-android-armv7.yml`（armv7-linux-androideabi + r26d NDK + 既有的 typetree-generator/dotnetdll/rabex-env patch），产出 `libunityscenerepacker.so`。
4. **手机实测**：
   - 放 .so → 首次启动跑分批 repack（观察内存峰值，`adb shell dumpsys meminfo` / logcat 的 `lowmemorykiller`）。
   - 中途杀进程 → 重启验证断点续传。
   - 对比 FullScene 路线：确认不再 532 秒、不再 OOM。
5. **Layer 2 验证**：第二次启动确认命中缓存、秒进、内存峰值显著下降。

---

## 7. 交付物清单

- `bindings/src/lib.rs`：新增 `export_batched`（含 cache_dir / resume 参数）。
- `src/lib.rs`：新增 `repack_scenes_batched`（分批/回调/容错）+ 中间文件生成 + `pack_to_asset_bundle_from_intermediate`。
- `src/merge_serialized.rs`：原则上无需改动（复用 `add_scene_meta_to_builder` / `remap_objects`）。
- manifest 读写与断点逻辑模块（建议新增 `src/batched_cache.rs`）。
- `build-android-armv7.yml`：更新构建产物入口（新增 export 符号）。
- 可选 Layer 2：Preloader 缓存/Hook 方案 + 对应 mod/DLL。

---

## 8. 与现有代码的兼容性

- 原 `export` 保留，`mode=0/1/2` 语义不变；新 `export_batched` 与原 `export` 并行存在，互不影响。
- C# 侧不升级时（只做 Layer 1），`export_batched` 可返回字节指针复用现有 `Marshal.Copy` 通路。
- 分批合并产物与一次性合并产物对游戏功能等价（对象集相同，pathID 顺序不同，无功能影响）。
