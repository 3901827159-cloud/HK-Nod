use anyhow::{Context, Result};
use log::warn;
use rabex::files::SerializedFile;
use rabex::files::serializedfile::{FileIdentifier, ObjectInfo};
use rabex::files::serializedfile::builder::SerializedFileBuilder;
use rabex::objects::pptr::{FileId, PathId};
use rabex::typetree::{TypeTreeNode, TypeTreeProvider};
use rabex_env::trace_pptr::replace_pptrs_resolver_endianed;
use rustc_hash::{FxHashMap, FxHashSet};
use std::borrow::Cow;
use std::fmt::Debug;
use std::path::PathBuf;

use crate::scene_name_display;

pub struct RemapSerializedIndices {
    pub path_id: FxHashMap<PathId, PathId>,
    pub file_id: FxHashMap<FileId, FileId>,
    pub types: FxHashMap<i32, i32>,
}

/// Takes the metadata (types, externals etc.) from `file` and moves them into `builder`.
pub fn add_scene_meta_to_builder(
    builder: &mut SerializedFileBuilder<impl TypeTreeProvider>,
    file: &mut SerializedFile,
) -> Result<RemapSerializedIndices> {
    if let Some(ref_types) = &file.m_RefTypes
        && !ref_types.is_empty()
    {
        warn!(
            "Found {} m_RefTypes in scene, this is untested.",
            ref_types.len(),
        );
    }

    let mut remap_path_id = FxHashMap::default();
    for obj in file.objects() {
        remap_path_id.insert(obj.m_PathID, builder.get_next_path_id());
    }

    let mut remap_file_id = FxHashMap::default();
    // TODO: deduplicate
    for (i, external) in file.m_Externals.iter().enumerate() {
        let orig_file_id = FileId::from_externals_index(i);
        let new_file_id = FileId::from_externals_index(builder.serialized.m_Externals.len());
        remap_file_id.insert(orig_file_id, new_file_id);
        builder.serialized.m_Externals.push(external.clone());
    }
    for ty in file.m_ScriptTypes.as_deref_mut().unwrap_or_default() {
        ty.m_LocalSerializedFileIndex = *remap_file_id
            // .get(&(ty.m_LocalIdentifierInFile as i32)) TODO: this was previously here??
            .get(&ty.m_LocalSerializedFileIndex)
            .unwrap_or(&ty.m_LocalSerializedFileIndex);
    }
    // TODO: deduplicate
    let remap_script_types = remap_vecs_all::<i16, _>(
        file.m_ScriptTypes.as_mut().unwrap_or(&mut vec![]),
        builder.serialized.m_ScriptTypes.get_or_insert_default(),
    );
    for ty in &mut file.m_Types {
        ty.m_ScriptTypeIndex = *remap_script_types
            .get(&ty.m_ScriptTypeIndex)
            .unwrap_or(&ty.m_ScriptTypeIndex);
    }
    let used_types: FxHashSet<_> = file.objects().map(|obj| obj.m_TypeID).collect();
    let remap_types = remap_vecs(
        used_types,
        &mut file.m_Types,
        &mut builder.serialized.m_Types,
    );

    Ok(RemapSerializedIndices {
        path_id: remap_path_id,
        file_id: remap_file_id,
        types: remap_types,
    })
}

pub fn remap_objects(
    scene_name: &str,
    original_name: PathBuf,
    file: &SerializedFile,
    data: &[u8],
    tpk: &impl TypeTreeProvider,
    objects: Vec<ObjectInfo>,
    mut replacements: FxHashMap<PathId, Vec<u8>>,
    mb_types: FxHashMap<PathId, &TypeTreeNode>,
    remap: RemapSerializedIndices,
    // v12 (embed-deps): `localizer` resolves an external reference
    // `(file name, path id)` to a fresh *local* path id when the target object
    // was embedded into the output file; `None` keeps the stock
    // external-reference behaviour. `ctx_externals` is the external table of
    // the file the objects come from (used to turn `file_id` indices into names
    // for the localizer).
    localizer: Option<&(dyn Fn(&str, PathId) -> Option<PathId> + Sync)>,
    ctx_externals: &[FileIdentifier],
) -> impl Iterator<Item = Result<(ObjectInfo, Cow<'static, [u8]>)>> {
    objects.into_iter().map(move |mut obj| -> Result<_> {
        obj.m_TypeID = remap.types[&obj.m_TypeID];

        let tt = match mb_types.get(&obj.m_PathID) {
            Some(ty) => ty,
            // TODO: take types from file if they exist
            None => &*file.get_typetree_for(&obj, &tpk)?,
        };
        let mut object_data = match replacements.remove(&obj.m_PathID) {
            Some(owned) => Cow::Owned(owned),
            None => {
                let offset = obj.m_Offset as usize;
                let size = obj.m_Size as usize;
                Cow::Borrowed(&data[offset..offset + size])
            }
        };

        let orig_path_id = obj.m_PathID;
        obj.m_PathID = *remap.path_id.get(&obj.m_PathID).unwrap_or(&obj.m_PathID);

        {
            let mut resolve = |fid_raw: i32, pid_raw: i64| -> (i32, i64) {
                if fid_raw == 0 {
                    return match remap.path_id.get(&pid_raw) {
                        Some(n) => (0, *n),
                        // points at a pruned object -> null it out (v7 semantics)
                        None => (0, 0),
                    };
                }
                if fid_raw < 0 {
                    // direct builtin reference: keep verbatim
                    return (fid_raw, pid_raw);
                }
                let keep = remap
                    .file_id
                    .get(&FileId::new(fid_raw))
                    .map(|f| f.value())
                    .unwrap_or(fid_raw);
                if let Some(ext) = ctx_externals.get((fid_raw - 1) as usize) {
                    let name = ext.pathName.as_str();
                    if !crate::embed_deps::is_builtin_external(name) {
                        if let Some(loc) = localizer {
                            if let Some(nid) = loc(name, pid_raw) {
                                // target was embedded into the output file
                                return (0, nid);
                            }
                        }
                    }
                }
                (keep, pid_raw)
            };
            replace_pptrs_resolver_endianed(
                object_data.to_mut().as_mut_slice(),
                tt,
                file.m_Header.m_Endianess,
                &mut resolve,
            )
        }
        .with_context(|| {
            format!(
                "Could not remap path IDs in bundle for {orig_path_id} in {}:\n{}",
                scene_name_display(scene_name, &original_name),
                tt.dump_pretty()
            )
        })?;

        Ok((obj, Cow::Owned(object_data.into_owned())))
    })
}

/// Moves the elements from `old` into `new`, returning where each index ended up in
#[must_use]
fn remap_vecs_all<I, T>(old: &mut Vec<T>, new: &mut Vec<T>) -> FxHashMap<I, I>
where
    I: std::hash::Hash + std::cmp::Eq + TryFrom<usize>,
    <I as TryFrom<usize>>::Error: Debug,
{
    std::mem::take(old)
        .into_iter()
        .enumerate()
        .map(|(old_index, ty)| {
            let new_index = new.len();
            new.push(ty);
            (old_index.try_into().unwrap(), new_index.try_into().unwrap())
        })
        .filter(|(old, new)| old != new)
        .collect()
}

#[must_use]
fn remap_vecs<T>(
    used_types: FxHashSet<i32>,
    old: &mut Vec<T>,
    new: &mut Vec<T>,
) -> FxHashMap<i32, i32> {
    let mut old_to_new: FxHashMap<i32, i32> = FxHashMap::default();

    for (old_index, ty) in std::mem::take(old)
        .into_iter()
        .enumerate()
        .filter(|&(idx, _)| used_types.contains(&(idx as i32)))
    {
        let new_index = new.len();
        old_to_new.insert(old_index as i32, new_index as i32);
        new.push(ty);
    }
    old_to_new
}
