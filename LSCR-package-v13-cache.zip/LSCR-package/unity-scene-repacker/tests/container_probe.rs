//! Local diagnostic (not shipped behavior): parse a device-produced bundle
//! (BUNDLE_PATH), locate the class-142 AssetBundle object, deserialize its
//! m_Container, and resolve every AssetInfo PPtr against the merged object
//! table. Answers: are container entries present? do their pointers resolve
//! to real GameObjects whose m_Name matches the entry basename?
//!
//! Usage:
//!   BUNDLE_PATH=/path/to/bundle-xxxx.unity3d cargo test --test container_probe -- --nocapture

use std::collections::BTreeMap;
use std::io::Cursor;

use rabex::files::bundlefile::{BundleFile, ExtractionConfig};
use rabex::files::SerializedFile;
use rabex::objects::ClassId;
use rabex::tpk::TpkTypeTreeBlob;
use rabex::typetree::typetree_cache::TypeTreeCache;
use rabex_env::unity::types::{AssetBundle, GameObject};

#[test]
fn probe_container_resolution() {
    let Ok(path) = std::env::var("BUNDLE_PATH") else {
        eprintln!("probe: BUNDLE_PATH unset, skipping");
        return;
    };
    let data = std::fs::read(&path).expect("read bundle");
    eprintln!("probe: {} bytes", data.len());
    let bf = BundleFile::from_reader(&mut Cursor::new(&data), &ExtractionConfig::default())
        .expect("parse bundle");
    eprintln!(
        "probe: blocks={} directory={}",
        bf.m_BlocksInfo.len(),
        bf.m_DirectoryInfo.len()
    );
    let e0 = &bf.m_DirectoryInfo[0];
    eprintln!("probe: file0 path={} size={}", e0.path, e0.size);
    let bd = &bf.m_BlockData[e0.offset as usize..(e0.offset + e0.size) as usize];
    let sf = SerializedFile::from_reader(&mut Cursor::new(bd)).expect("parse serialized file");
    eprintln!(
        "probe: version={:?} platform={:?} enable_typetree={} objects={}",
        sf.m_UnityVersion,
        sf.m_TargetPlatform,
        sf.m_EnableTypeTree,
        sf.objects().len()
    );

    // class histogram (top entries)
    let mut hist: BTreeMap<String, u32> = BTreeMap::new();
    for o in sf.objects() {
        *hist.entry(format!("{:?}", o.m_ClassID)).or_insert(0) += 1;
    }
    eprintln!("probe: class histogram {:?}", hist);

    let tpk = TypeTreeCache::new(TpkTypeTreeBlob::embedded());
    let ab_info = sf
        .find_object_info_of::<AssetBundle>()
        .expect("no class-142 AssetBundle object in merged file");
    eprintln!(
        "probe: AssetBundle object at path_id={} size={} typeID={}",
        ab_info.m_PathID, ab_info.m_Size, ab_info.m_TypeID
    );
    let ab_ref = sf
        .get_object::<AssetBundle>(ab_info.m_PathID, &tpk)
        .expect("get AssetBundle ref");
    let ab: AssetBundle = ab_ref
        .read(&mut Cursor::new(bd))
        .expect("deserialize AssetBundle");
    eprintln!(
        "probe: m_Name={:?} container={} preload_table={} deps={} streamed={} compat={} layout={} pathflags={}",
        ab.m_Name,
        ab.m_Container.len(),
        ab.m_PreloadTable.len(),
        ab.m_Dependencies.len(),
        ab.m_IsStreamedSceneAssetBundle,
        ab.m_RuntimeCompatibility,
        ab.m_ExplicitDataLayout,
        ab.m_PathFlags
    );
    eprintln!("probe: main_asset={:?}", ab.m_MainAsset);

    let mut ok = 0u32;
    let mut dangling = 0u32;
    let mut wrongclass = 0u32;
    let mut namemismatch = 0u32;
    for (key, info) in ab.m_Container.iter() {
        let pid = info.asset.m_PathID;
        let Some(oi) = sf.get_object_info(pid) else {
            dangling += 1;
            if dangling <= 8 {
                eprintln!("probe: DANGLING {key} -> path_id {pid}");
            }
            continue;
        };
        if oi.m_ClassID != ClassId::GameObject {
            wrongclass += 1;
            if wrongclass <= 8 {
                eprintln!("probe: WRONGCLASS {key} -> path_id {pid} class {:?}", oi.m_ClassID);
            }
            continue;
        }
        // resolve GameObject name via typetree
        match sf.get_object::<GameObject>(pid, &tpk) {
            Ok(go_ref) => match go_ref.read(&mut Cursor::new(bd)) {
                Ok(go) => {
                    let base = key.rsplit('/').next().unwrap_or(key);
                    let base_noprefab = base.strip_suffix(".prefab").unwrap_or(base);
                    if !go.m_Name.eq_ignore_ascii_case(base_noprefab) {
                        namemismatch += 1;
                        if namemismatch <= 8 {
                            eprintln!(
                                "probe: NAMEMISMATCH key={key} go.m_Name={:?}",
                                go.m_Name
                            );
                        }
                    } else {
                        ok += 1;
                        if ok <= 8 {
                            eprintln!("probe: OK {key} -> {pid} name={:?} preload=({},{})",
                                go.m_Name, info.preloadIndex, info.preloadSize);
                        }
                    }
                }
                Err(e) => {
                    wrongclass += 1;
                    eprintln!("probe: GO-DESER-FAIL {key} -> {pid}: {e}");
                }
            },
            Err(e) => {
                wrongclass += 1;
                eprintln!("probe: GO-REF-FAIL {key} -> {pid}: {e}");
            }
        }
    }
    eprintln!(
        "probe: container resolution: ok={ok} dangling={dangling} wrongclass={wrongclass} namemismatch={namemismatch}"
    );
}
