//! Ad-hoc bundle autopsy: BUNDLE_PATH=<file> prints header/block-table/object
//! counts via rabex's own reader. Local diagnostic only; skips when unset.
use std::io::Cursor;
use unity_scene_repacker::rabex::files::bundlefile::{BundleFile, ExtractionConfig};
use unity_scene_repacker::rabex::files::SerializedFile;

#[test]
fn autopsy_bundle_at_path() {
    let Ok(path) = std::env::var("BUNDLE_PATH") else {
        eprintln!("autopsy: BUNDLE_PATH unset, skipping");
        return;
    };
    let data = std::fs::read(&path).expect("read bundle");
    eprintln!("autopsy: {} bytes", data.len());
    let bf = BundleFile::from_reader(&mut Cursor::new(&data), &ExtractionConfig::default())
        .expect("parse bundle");
    eprintln!("autopsy: header.size={}", bf.m_Header.size);
    eprintln!("autopsy: blocks={}", bf.m_BlocksInfo.len());
    for (i, b) in bf.m_BlocksInfo.iter().enumerate().take(3) {
        eprintln!(
            "autopsy: block {i} uncomp={} comp={} flags={:#x}",
            b.uncompressed_size, b.compressed_size, b.flags
        );
    }
    if bf.m_BlocksInfo.len() > 3 {
        let b = bf.m_BlocksInfo.last().unwrap();
        eprintln!("autopsy: last block uncomp={} comp={}", b.uncompressed_size, b.compressed_size);
    }
    eprintln!("autopsy: directory entries={}", bf.m_DirectoryInfo.len());
    let e0 = &bf.m_DirectoryInfo[0];
    eprintln!("autopsy: file0 path={} off={} size={}", e0.path, e0.offset, e0.size);
    let bd = &bf.m_BlockData[e0.offset as usize..(e0.offset + e0.size) as usize];
    let sf = SerializedFile::from_reader(&mut Cursor::new(bd)).expect("parse serialized");
    eprintln!("autopsy: objects={}", sf.objects().len());
}
