//! v13.19 dissecting table: replays the phase-2 per-scene body of
//! `pack_to_asset_bundle_from_cache` against on-device shards copied out of
//! the phone's work dir (scene.NNN.serialized + scene.NNN.meta.json), with
//! per-stage and per-object timing printed to stderr.
//!
//! Usage (local only; skipped when REPLAY_DIR is unset so CI/gates stay green):
//!   REPLAY_DIR=/path/to/workdir-copy REPLAY_SCENE=Abyss_15 \
//!     cargo test --test scene_replay -- --nocapture
//!
//! The serial iterator is used on purpose: the on-device hang reproduced
//! single-threaded (v13.17) as well as four-threaded (v13.18), so serial
//! replay pins the exact object the walker dies inside, one eprintln at a
//! time, instead of a black screen.

use std::path::Path;
use std::time::Instant;

use rabex::files::serializedfile::{self, builder::SerializedFileBuilder};
use rabex::tpk::TpkTypeTreeBlob;
use rabex::typetree::typetree_cache::TypeTreeCache;
use rabex::UnityVersion;
use rabex_env::unity::types::AssetBundle;
use rustc_hash::FxHashMap;
use unity_scene_repacker::{batched_cache, merge_serialized};

#[test]
fn replay_one_scene_with_stage_timing() {
    let Ok(dir) = std::env::var("REPLAY_DIR") else {
        eprintln!("replay: REPLAY_DIR unset, skipping");
        return;
    };
    let dir = Path::new(&dir);
    let want = std::env::var("REPLAY_SCENE").unwrap_or_else(|_| "Abyss_15".to_string());
    assert!(dir.join("manifest.json").exists(), "REPLAY_DIR lacks manifest.json");

    let manifest = batched_cache::Manifest::load(dir)
        .expect("manifest io")
        .expect("manifest present");
    let entry = manifest
        .scenes
        .get(&want)
        .unwrap_or_else(|| panic!("scene {want} not in manifest"));
    eprintln!("replay: scene {want} idx={} status={:?}", entry.idx, entry.status);

    let unity_version: UnityVersion = "2020.3.26f1".parse().expect("unity version");
    let blob_for_map = TpkTypeTreeBlob::embedded();
    let common_offset_map = serializedfile::build_common_offset_map(&blob_for_map, &unity_version);
    let tpk = TypeTreeCache::new(TpkTypeTreeBlob::embedded());
    let mut builder = SerializedFileBuilder::new(&unity_version, &tpk, &common_offset_map, false);
    builder.next_path_id = 2;
    let mut asset_bundle = AssetBundle::asset_base(&manifest.bundle_name);
    eprintln!("replay: bootstrap ok");

    // ---- stage 1: meta ----
    let t = Instant::now();
    let meta = batched_cache::SceneMeta::load(dir, entry.idx).expect("meta load");
    eprintln!("replay: stage meta done in {:?} (objects_before={})", t.elapsed(), meta.objects_before);

    // ---- stage 2: shard read ----
    let t = Instant::now();
    let serialized_bytes =
        std::fs::read(batched_cache::scene_serialized_path(dir, entry.idx)).expect("shard read");
    eprintln!("replay: stage shard read done in {:?} ({} bytes)", t.elapsed(), serialized_bytes.len());

    // ---- stage 3: parse ----
    let t = Instant::now();
    let mut file = rabex::files::SerializedFile::from_reader(&mut std::io::Cursor::new(
        serialized_bytes.as_slice(),
    ))
    .expect("parse");
    eprintln!("replay: stage parse done in {:?} ({} objects)", t.elapsed(), file.objects().len());

    // ---- stage 4: type-table merge ----
    let t = Instant::now();
    let remap = merge_serialized::add_scene_meta_to_builder(&mut builder, &mut file).expect("meta merge");
    eprintln!("replay: stage meta-merge done in {:?}", t.elapsed());

    // ---- stage 5: roots ----
    for (scene_path, go_path_id) in &meta.roots {
        let mut go = rabex::objects::pptr::PPtr::local(*go_path_id);
        if let Some(r) = remap.path_id.get(&go.m_PathID) {
            go.m_PathID = *r;
        }
        let info = rabex_env::unity::types::AssetInfo::new(go);
        let path = unity_scene_repacker::get_asset_bundle_object_asset_name(&want, scene_path);
        asset_bundle.m_Container.insert(path, info);
    }
    eprintln!("replay: stage roots done ({} containers)", asset_bundle.m_Container.len());

    // ---- stage 6: typetrees ----
    let owned_typetrees = meta.owned_monobehaviour_types();
    let mb_types: FxHashMap<_, _> = owned_typetrees.iter().map(|(k, v)| (*k, v)).collect();
    eprintln!("replay: stage typetrees done ({} mb types)", mb_types.len());

    // ---- stage 7: per-object remap, serial, loud ----
    let scene_externals = file.m_Externals.clone();
    let objects = file.take_objects();
    let total = objects.len();
    for (i, o) in objects.iter().enumerate() {
        eprintln!(
            "replay: table {i}: path_id={} type_id={} size={} mb_owned={}",
            o.m_PathID,
            o.m_TypeID,
            o.m_Size,
            mb_types.contains_key(&o.m_PathID)
        );
    }
    let t0 = Instant::now();
    let mut done = 0usize;
    // Print at every object START: if the walker dies inside object i, the
    // last line on stderr names it exactly.
    let mut started = 0usize;
    for (i, obj) in merge_serialized::remap_objects(
        &want,
        meta.original_name.clone(),
        &builder.serialized,
        &serialized_bytes,
        &tpk,
        objects,
        FxHashMap::default(),
        mb_types,
        remap,
        None,
        &scene_externals,
    )
    .enumerate()
    {
        // NOTE: the iterator is lazy - this line prints AFTER object i finished.
        // A hang inside object k therefore leaves "object {k-1} yielded" as
        // the last line: the dying object is last-printed + 1.
        eprintln!("replay: object {i}/{total} yielded");
        started = i + 1;
        let (info, data) = obj.unwrap_or_else(|e| panic!("object {i} failed: {e:?}"));
        done += 1;
        if done % 50 == 0 || done == total {
            eprintln!(
                "replay: object {done}/{total} path_id={} bytes={} elapsed={:?}",
                info.m_PathID,
                data.len(),
                t0.elapsed()
            );
        }
    }
    let _ = started;
    eprintln!("replay: scene {want} fully remapped in {:?} ({total} objects)", t0.elapsed());
}
