//! v13.15 repro harness: replays the phase-2 preamble of
//! `pack_to_asset_bundle_from_cache` against REAL on-device intermediates
//! (manifest.json + embedded_index.json captured 2026-09-27 from the phone's
//! work-bec3f26ad4222df9 dir, where phase 2 died silently before writing
//! objects_data.tmp or any breadcrumb).
//!
//! If the preamble regresses, this test dies the same way the phone did —
//! but with a Rust backtrace instead of a black screen.

use std::path::Path;

use rabex::files::serializedfile::{self, SerializedType};
use rabex::files::serializedfile::builder::SerializedFileBuilder;
use rabex::objects::pptr::PathId;
use rabex::objects::ClassId;
use rabex::tpk::TpkTypeTreeBlob;
use rabex::typetree::typetree_cache::TypeTreeCache;
use rabex::UnityVersion;
use rabex_env::unity::types::AssetBundle;
use rustc_hash::FxHashMap;
use unity_scene_repacker::batched_cache::{self, EmbeddedIndex, Manifest};

fn fixture_dir() -> &'static Path {
    Path::new(concat!(env!("CARGO_MANIFEST_DIR"), "/tests/fixtures/work-repro"))
}

#[test]
fn phase2_preamble_survives_device_intermediates() {
    let cache_dir = fixture_dir();
    assert!(cache_dir.join("manifest.json").exists(), "fixtures missing");

    // ---- mirror of pack_to_asset_bundle_from_cache preamble ----
    let manifest = Manifest::load(cache_dir)
        .expect("manifest load")
        .expect("manifest present");
    let bundle_name = manifest.bundle_name.clone();
    eprintln!("repro: manifest ok, bundle_name={bundle_name}, scenes={}", manifest.scenes.len());

    let unity_version: UnityVersion = "2020.3.26f1".parse().expect("device unity version");
    // two embedded copies, mirroring lib.rs (map borrows from its own blob)
    let blob_for_map = TpkTypeTreeBlob::embedded();
    let common_offset_map = serializedfile::build_common_offset_map(&blob_for_map, &unity_version);
    let tpk = TypeTreeCache::new(TpkTypeTreeBlob::embedded());
    eprintln!("repro: offset map ok");

    let mut builder = SerializedFileBuilder::new(&unity_version, &tpk, &common_offset_map, false);
    builder.next_path_id = 2;
    let _asset_bundle = AssetBundle::asset_base(&bundle_name);
    eprintln!("repro: builder ok");

    let embedded = match batched_cache::EmbeddedIndex::load(cache_dir).expect("index io") {
        Some(idx) => {
            eprintln!(
                "repro: embedded index ok: {} records, {} sources, {} types",
                idx.records.len(),
                idx.sources.len(),
                idx.types.len()
            );
            idx
        }
        None => panic!("embedded_index.json unreadable/absent"),
    };

    let mut src_by_name: FxHashMap<&str, u32> = FxHashMap::default();
    for (i, src) in embedded.sources.iter().enumerate() {
        src_by_name.insert(src.name.as_str(), i as u32);
    }

    let mut embedded_ids: FxHashMap<(u32, PathId), PathId> = FxHashMap::default();
    for rec in &embedded.records {
        embedded_ids.insert((rec.src, rec.path_id), builder.get_next_path_id());
    }
    eprintln!("repro: embedded ids assigned");

    let mut embedded_type_ids: Vec<i32> = Vec::with_capacity(embedded.types.len());
    for (ti, ty) in embedded.types.iter().enumerate() {
        let tt = ty
            .typetree
            .as_ref()
            .map(|flat| typetree_generator_api::reconstruct_typetree_node(flat));
        let mut st = SerializedType::simple(ClassId(ty.class_id), tt);
        st.m_ScriptID = batched_cache::unhex16(&ty.script_id_hex);
        st.m_OldTypeHash = batched_cache::unhex16(&ty.old_type_hash_hex);
        if let Some((ext_name, ext_id)) = ty.script_ext.as_ref() {
            let fid = match ext_name {
                Some(name) => builder.get_or_insert_external(name),
                None => rabex::objects::pptr::FileId::LOCAL,
            };
            let script_types = builder.serialized.m_ScriptTypes.get_or_insert_default();
            let sti: i16 = script_types
                .len()
                .try_into()
                .expect("m_ScriptTypes exceeded i16::MAX");
            script_types.push(serializedfile::LocalSerializedObjectIdentifier {
                m_LocalSerializedFileIndex: fid,
                m_LocalIdentifierInFile: *ext_id,
            });
            st.m_ScriptTypeIndex = sti;
        }
        embedded_type_ids.push(builder.add_type_uncached(st));
        if ti % 256 == 0 {
            eprintln!("repro: type {}/{} registered", ti, embedded.types.len());
        }
    }
    eprintln!(
        "repro: PREAMBLE OK ({} types, {} ids) — device death NOT reproduced by preamble",
        embedded_type_ids.len(),
        embedded_ids.len()
    );
}
