//! v12 (embed-deps): Phase 1b — collect the cross-file dependency closure of
//! every repacked scene and persist it next to the trimmed scene intermediates.
//!
//! Why this exists: the stock repacker leaves references to sprites, materials,
//! textures, meshes, audio clips, ... as *external* references (bare file names
//! like `sharedassets7.assets`). On PC those loose files sit next to the game
//! data and resolve at runtime. On Android the whole data set is packed inside
//! `data.unity3d`; a separately loaded bundle cannot resolve bare-name
//! externals, so every such reference arrives as null in game (invisible
//! enemies, null object pools, broken death effects).
//!
//! Phase 1b walks every external reference found in the reachable closure of
//! the requested scene objects (recorded per scene in `SceneMeta::externals`),
//! follows references transitively (a sprite needs its texture, a material
//! needs its shader and textures, a GameObject needs its components, ...), and
//! stores each needed object verbatim in `embedded.bin` with metadata in
//! `embedded_index.json`. Phase 2 assigns fresh local path ids, embeds the
//! objects into the merged serialized file and rewrites every PPtr — in scene
//! objects *and* in embedded objects — so the final bundle is self-contained
//! (except engine builtins, which resolve at runtime by design).
//!
//! Memory profile: one source file is decompressed at a time (uncached), its
//! needed objects are copied to disk immediately, then the file is dropped.

use std::collections::{HashSet, VecDeque};
use std::fs::File;
use std::io::{BufWriter, Cursor, Write};
use std::path::Path;

use anyhow::{Context, Result};
use rabex::files::serializedfile::Endianness;
use rabex::objects::pptr::PathId;
use rustc_hash::FxHashMap;

use rabex_env::Environment;
use rabex_env::trace_pptr;

use crate::batched_cache::{
    EmbeddedIndex, EmbeddedRecord, EmbeddedSource, EmbeddedType, FlatTypeTreeNode,
    embedded_bin_path, flatten_typetree_node, hex16,
};

/// Engine-provided files that resolve at runtime and must stay external.
pub const BUILTIN_EXTERNALS: &[&str] = &[
    "Library/unity default resources",
    "Library/unity editor resources",
    "Resources/unity_builtin_extra",
];

pub fn is_builtin_external(name: &str) -> bool {
    BUILTIN_EXTERNALS.iter().any(|b| *b == name)
}

const CLASS_ID_MONOBEHAVIOUR: i32 = 114;
const CLASS_ID_MONOSCRIPT: i32 = 115;

pub struct EmbedStats {
    pub records: usize,
    pub sources: usize,
    pub bytes: u64,
}

/// Collect the dependency closure for all `Done` scenes listed in
/// `scene_indices` (`(scene_name, idx)`), writing `embedded.bin` +
/// `embedded_index.json` into `cache_dir`. Idempotent-ish: callers skip this
/// when `manifest.deps_done` is already set.
pub fn collect_embedded_deps(
    env: &Environment,
    cache_dir: &Path,
    scene_indices: &[(String, usize)],
) -> Result<EmbedStats> {
    // v13: per-file buckets + FIFO of file names. The old flat queue was
    // scanned linearly on every pop to group same-file refs (O(n²)/O(n³)
    // with tens of thousands of queued refs), which looked like a frozen
    // "phase 1" on device.
    let mut buckets: FxHashMap<String, VecDeque<PathId>> = FxHashMap::default();
    let mut order: VecDeque<String> = VecDeque::new();
    let mut seeded: HashSet<(String, PathId)> = HashSet::new();

    for (scene_name, idx) in scene_indices {
        let meta = crate::batched_cache::SceneMeta::load(cache_dir, *idx)
            .with_context(|| format!("loading meta for scene {scene_name}"))?;
        for (name, pid) in meta.externals {
            if is_builtin_external(&name) {
                continue;
            }
            if seeded.insert((name.clone(), pid)) {
                if !buckets.contains_key(&name) {
                    order.push_back(name.clone());
                }
                buckets.entry(name).or_default().push_back(pid);
            }
        }
    }

    log::info!(
        "LSCR embed-deps: seeded with {} cross-file references from {} scenes",
        seeded.len(),
        scene_indices.len()
    );

    let mut index = EmbeddedIndex::default();
    let mut src_lookup: FxHashMap<String, u32> = FxHashMap::default();
    let mut type_lookup: FxHashMap<(i32, String, String, Option<(Option<String>, i64)>), u32> =
        FxHashMap::default();
    let mut seen: HashSet<(String, PathId)> = HashSet::new();

    let bin_path = embedded_bin_path(cache_dir);
    let tmp_path = bin_path.with_extension("bin.tmp");
    let mut bin = BufWriter::new(File::create(&tmp_path).context("creating embedded.bin")?);
    let mut bin_offset: u64 = 0;
    let mut skipped: usize = 0;

    let mut files_done: usize = 0;
    let progress_path = cache_dir.join("progress.txt");
    while let Some(fname) = order.pop_front() {
        // Everything pending for this file; it is decompressed once and all
        // of its refs are drained together.
        let Some(mut work) = buckets.remove(&fname) else {
            continue;
        };

        let (sf, data) = match env.load_serialized_uncached(&fname) {
            Ok(v) => v,
            Err(e) => {
                log::warn!("LSCR embed-deps: cannot open '{fname}', skipping {} refs: {e}", work.len());
                for pid in work {
                    seen.insert((fname.clone(), pid));
                }
                continue;
            }
        };
        let bytes_all: &[u8] = data.as_ref();

        // Register the source file (its own externals table is needed at merge
        // time to rewrite PPtrs inside embedded objects).
        let src_idx = match src_lookup.get(&fname) {
            Some(v) => *v,
            None => {
                index.sources.push(EmbeddedSource {
                    name: fname.clone(),
                    externals: sf.m_Externals.iter().map(|e| e.pathName.clone()).collect(),
                    big_endian: matches!(sf.m_Header.m_Endianess, Endianness::Big),
                });
                let v = (index.sources.len() - 1) as u32;
                src_lookup.insert(fname.clone(), v);
                v
            }
        };

        let has_mb = sf.objects().any(|o| o.m_ClassID.0 == CLASS_ID_MONOBEHAVIOUR);
        let mb_types: FxHashMap<PathId, &typetree_alias::Node> = if has_mb {
            crate::prepare_monobehaviour_types(env, &sf, &mut Cursor::new(bytes_all))
        } else {
            FxHashMap::default()
        };

        while let Some(pid) = work.pop_front() {
            if !seen.insert((fname.clone(), pid)) {
                continue;
            }
            let Some(info) = sf.get_object_info(pid) else {
                log::warn!("LSCR embed-deps: '{fname}' has no object {pid} (pruned upstream?)");
                skipped += 1;
                continue;
            };
            let class_id = info.m_ClassID.0;
            if class_id == CLASS_ID_MONOSCRIPT {
                // MonoScripts stay external: managed script binding on device
                // already works through external references (scene MBs prove
                // it), and embedding compiled script objects buys nothing.
                continue;
            }
            let off = info.m_Offset as usize;
            let len = info.m_Size as usize;
            if off.checked_add(len).map(|e| e > bytes_all.len()).unwrap_or(true) {
                log::warn!("LSCR embed-deps: object {pid} in '{fname}' out of bounds, skipping");
                skipped += 1;
                continue;
            }
            let obj_bytes = &bytes_all[off..off + len];

            // Typetree: generated/persisted for MonoBehaviours, file-or-tpk
            // for native classes. Without one we cannot trace or rewrite the
            // object's PPtrs, so skip it (references then resolve to null,
            // same as today's behaviour — no regression).
            let tt_owned;
            let tt: &typetree_alias::Node = if class_id == CLASS_ID_MONOBEHAVIOUR {
                match mb_types.get(&pid) {
                    Some(t) => *t,
                    None => match sf.get_typetree_for(info, &env.tpk) {
                        Ok(cow) => {
                            tt_owned = cow.into_owned();
                            &tt_owned
                        }
                        Err(e) => {
                            log::warn!("LSCR embed-deps: no typetree for MB {pid} in '{fname}': {e}");
                            skipped += 1;
                            continue;
                        }
                    },
                }
            } else {
                match sf.get_typetree_for(info, &env.tpk) {
                    Ok(cow) => {
                        tt_owned = cow.into_owned();
                        &tt_owned
                    }
                    Err(e) => {
                        log::warn!(
                            "LSCR embed-deps: no typetree for class {class_id} object {pid} in '{fname}': {e}"
                        );
                        skipped += 1;
                        continue;
                    }
                }
            };

            // Trace references before the file borrow ends.
            let pptrs = match trace_pptr::trace_pptrs_endianned(
                tt,
                &mut Cursor::new(obj_bytes),
                sf.m_Header.m_Endianess,
            ) {
                Ok(p) => p,
                Err(e) => {
                    log::warn!("LSCR embed-deps: trace failed for {pid} in '{fname}': {e}");
                    skipped += 1;
                    continue;
                }
            };
            for p in pptrs {
                if p.m_PathID == 0 {
                    continue;
                }
                let fid = p.m_FileID.value();
                if fid == 0 {
                    work.push_back(p.m_PathID);
                } else if fid > 0 {
                    if let Some(ext) = sf.m_Externals.get((fid - 1) as usize) {
                        if !is_builtin_external(&ext.pathName)
                            && !seen.contains(&(ext.pathName.clone(), p.m_PathID))
                        {
                            if !buckets.contains_key(&ext.pathName) {
                                order.push_back(ext.pathName.clone());
                            }
                            buckets
                                .entry(ext.pathName.clone())
                                .or_default()
                                .push_back(p.m_PathID);
                        }
                    }
                }
                // fid < 0: direct builtin reference, stays as-is
            }

            // Resolve the script binding for MonoBehaviours (kept external).
            let mut script_ext: Option<(Option<String>, i64)> = None;
            if class_id == CLASS_ID_MONOBEHAVIOUR {
                if let Some(sti) = info.m_ScriptTypeIndex {
                    if sti >= 0 {
                        if let Some(st) = sf
                            .m_ScriptTypes
                            .as_ref()
                            .and_then(|v| v.get(sti as usize))
                        {
                            let sfid = st.m_LocalSerializedFileIndex.value();
                            if sfid > 0 {
                                if let Some(ext) = sf.m_Externals.get((sfid - 1) as usize) {
                                    script_ext =
                                        Some((Some(ext.pathName.clone()), st.m_LocalIdentifierInFile));
                                }
                            } else {
                                // Local MonoScript in a data file: exotic. We do not
                                // embed MonoScripts, so leave the type unbound; the
                                // component degrades to "missing script" instead of
                                // corrupting the file.
                                log::warn!(
                                    "LSCR embed-deps: MB {pid} in '{fname}' has a local MonoScript ref; leaving unbound"
                                );
                            }
                        }
                    }
                }
            }

            // Type table entry (deduplicated across all records).
            let src_ty = match sf.m_Types.get(info.m_TypeID as usize) {
                Some(t) => t,
                None => {
                    log::warn!("LSCR embed-deps: bad m_TypeID {} for {pid} in '{fname}'", info.m_TypeID);
                    skipped += 1;
                    continue;
                }
            };
            let script_id_hex = hex16(&src_ty.m_ScriptID);
            let old_hash_hex = hex16(&src_ty.m_OldTypeHash);
            let flat: Vec<FlatTypeTreeNode> = flatten_typetree_node(tt);
            let key = (
                class_id,
                script_id_hex.clone(),
                old_hash_hex.clone(),
                script_ext.clone(),
            );
            let ty_idx = if let Some(v) = type_lookup.get(&key) {
                *v
            } else {
                index.types.push(EmbeddedType {
                    class_id,
                    script_id_hex,
                    old_type_hash_hex: old_hash_hex,
                    script_ext,
                    typetree: Some(flat),
                });
                let v = (index.types.len() - 1) as u32;
                type_lookup.insert(key, v);
                v
            };

            bin.write_all(obj_bytes)
                .context("writing embedded.bin")?;
            index.records.push(EmbeddedRecord {
                src: src_idx,
                path_id: pid,
                ty: ty_idx,
                offset: bin_offset,
                len: len as u64,
            });
            bin_offset += len as u64;
        }
        // sf + data dropped here: peak memory is one source file at a time.
        files_done += 1;
        if files_done % 8 == 0 || (order.is_empty() && buckets.is_empty()) {
            let queued: usize = buckets.values().map(|v| v.len()).sum();
            let _ = std::fs::write(
                &progress_path,
                format!(
                    "embed-deps: files_done={files_done} refs_embedded={} files_pending={} refs_queued={queued}\n",
                    index.records.len(),
                    order.len()
                ),
            );
        }
    }

    bin.flush().context("flushing embedded.bin")?;
    drop(bin);
    std::fs::rename(&tmp_path, &bin_path).context("renaming embedded.bin into place")?;
    index.save(cache_dir)?;

    log::info!(
        "LSCR embed-deps: embedded {} objects from {} source files ({} MiB, {} skipped)",
        index.records.len(),
        index.sources.len(),
        bin_offset / (1024 * 1024),
        skipped
    );

    Ok(EmbedStats {
        records: index.records.len(),
        sources: index.sources.len(),
        bytes: bin_offset,
    })
}

/// Small alias so the borrowed-vs-owned typetree juggling above stays readable.
mod typetree_alias {
    pub use rabex::typetree::TypeTreeNode as Node;
}
