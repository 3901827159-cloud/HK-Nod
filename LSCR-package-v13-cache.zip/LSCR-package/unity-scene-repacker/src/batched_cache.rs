//! Batched/cached repack support: manifest, intermediate scene files and their metadata.
//!
//! Layout of the cache directory:
//! ```text
//! cache_dir/
//! ├── manifest.json
//! ├── scene.000.serialized      # trimmed serialized file
//! ├── scene.000.meta.json
//! ├── scene.001.serialized
//! ├── ...
//! └── final.unity3d             # written by phase 2
//! ```
use anyhow::{Context, Result};
use indexmap::IndexMap;
use rabex::typetree::TypeTreeNode;
use serde_derive::{Deserialize, Serialize};
use std::path::{Path, PathBuf};
use typetree_generator_api::reconstruct_typetree_node;

pub const MANIFEST_FILE: &str = "manifest.json";
/// v2: typetree flat-node order fixed (name, type, level, flags).
/// v3: embed-deps — scene metas carry resolved external references and the
/// cache gains embedded.bin / embedded_index.json (cross-file dependencies
/// embedded into the final bundle; required on Android where the original
/// loose .assets files do not exist at runtime). Older caches must rebuild.
pub const MANIFEST_VERSION: u32 = 3;
pub const FINAL_BUNDLE_FILE: &str = "final.unity3d";

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum SceneStatus {
    Pending,
    Done,
    Failed,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SceneEntry {
    pub status: SceneStatus,
    pub idx: usize,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub error: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ManifestStats {
    pub objects_before: usize,
    pub objects_after: usize,
    pub size_before: usize,
    pub size_after: usize,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct Manifest {
    pub version: u32,
    pub mode: String,
    pub bundle_name: String,
    /// Ordered map (serde_json preserve_order): merge order = insertion order.
    /// Created from scene names sorted alphabetically for determinism.
    pub scenes: IndexMap<String, SceneEntry>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub stats: Option<ManifestStats>,
    /// v12: phase 1b (dependency embedding collection) completed.
    #[serde(default)]
    pub deps_done: bool,
}

impl Manifest {
    pub fn new(mode: &str, bundle_name: &str, scene_names: &[String]) -> Self {
        let mut sorted: Vec<&String> = scene_names.iter().collect();
        sorted.sort();
        let scenes = sorted
            .into_iter()
            .enumerate()
            .map(|(idx, name)| {
                (
                    name.clone(),
                    SceneEntry {
                        status: SceneStatus::Pending,
                        idx,
                        error: None,
                    },
                )
            })
            .collect();
        Manifest {
            version: MANIFEST_VERSION,
            mode: mode.to_owned(),
            bundle_name: bundle_name.to_owned(),
            scenes,
            stats: None,
            deps_done: false,
        }
    }

    pub fn path(cache_dir: &Path) -> PathBuf {
        cache_dir.join(MANIFEST_FILE)
    }

    pub fn load(cache_dir: &Path) -> Result<Option<Manifest>> {
        let path = Self::path(cache_dir);
        if !path.exists() {
            return Ok(None);
        }
        let raw = std::fs::read_to_string(&path)
            .with_context(|| format!("reading manifest {}", path.display()))?;
        let manifest: Manifest =
            serde_json::from_str(&raw).with_context(|| "parsing manifest.json")?;
        if manifest.version != MANIFEST_VERSION {
            log::warn!(
                "cache manifest version {} is stale (expected {}); rebuilding all scenes",
                manifest.version,
                MANIFEST_VERSION
            );
            return Ok(None);
        }
        Ok(Some(manifest))
    }

    /// Atomic save: write to a temp file then rename, so a killed process can
    /// never leave a half-written manifest behind.
    pub fn save(&self, cache_dir: &Path) -> Result<()> {
        let path = Self::path(cache_dir);
        let tmp = path.with_extension("json.tmp");
        let raw = serde_json::to_string_pretty(self)?;
        std::fs::write(&tmp, raw.as_bytes())
            .with_context(|| format!("writing manifest tmp {}", tmp.display()))?;
        std::fs::rename(&tmp, &path)
            .with_context(|| format!("renaming manifest into place {}", path.display()))?;
        Ok(())
    }

    pub fn done_count(&self) -> usize {
        self.scenes
            .values()
            .filter(|e| e.status == SceneStatus::Done)
            .count()
    }

    pub fn failed_count(&self) -> usize {
        self.scenes
            .values()
            .filter(|e| e.status == SceneStatus::Failed)
            .count()
    }
}

pub fn scene_serialized_path(cache_dir: &Path, idx: usize) -> PathBuf {
    cache_dir.join(format!("scene.{idx:03}.serialized"))
}

pub fn scene_meta_path(cache_dir: &Path, idx: usize) -> PathBuf {
    cache_dir.join(format!("scene.{idx:03}.meta.json"))
}

/// Metadata for one intermediate scene file.
///
/// `roots` stores `(scene_object_path, game_object_path_id)` — the path id is
/// the *original* (pre-merge) id; phase 2 remaps it through `RemapSerializedIndices`.
///
/// `monobehaviour_types` stores flattened typetrees in the same
/// `(name, type, level, flags)` format used by the monobehaviour typetree dump.
#[derive(Debug, Serialize, Deserialize)]
pub struct SceneMeta {
    pub scene_name: String,
    pub original_name: PathBuf,
    pub objects_before: usize,
    pub size_before: usize,
    pub roots: Vec<(String, i64)>,
    pub monobehaviour_types: Vec<(i64, Vec<FlatTypeTreeNode>)>,
    /// Requested paths that could not be resolved in this scene.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub missing: Vec<String>,
    /// v12: cross-file references found in this scene's reachable closure,
    /// resolved to `(external file name, path id)`. Builtins are excluded.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub externals: Vec<(String, i64)>,
}

pub type FlatTypeTreeNode = (String, String, u8, i32);

impl SceneMeta {
    pub fn save(&self, cache_dir: &Path, idx: usize) -> Result<()> {
        let path = scene_meta_path(cache_dir, idx);
        let tmp = path.with_extension("json.tmp");
        let raw = serde_json::to_string(self)?;
        std::fs::write(&tmp, raw.as_bytes())
            .with_context(|| format!("writing meta tmp {}", tmp.display()))?;
        std::fs::rename(&tmp, &path)?;
        Ok(())
    }

    pub fn load(cache_dir: &Path, idx: usize) -> Result<SceneMeta> {
        let path = scene_meta_path(cache_dir, idx);
        let raw = std::fs::read_to_string(&path)
            .with_context(|| format!("reading meta {}", path.display()))?;
        serde_json::from_str(&raw).with_context(|| format!("parsing meta {}", path.display()))
    }

    /// Rebuild owned typetree nodes from the flattened representation.
    pub fn owned_monobehaviour_types(&self) -> FxOwnedTypeTrees {
        self.monobehaviour_types
            .iter()
            .map(|(path_id, flat)| (*path_id, reconstruct_typetree_node(flat)))
            .collect()
    }
}

pub type FxOwnedTypeTrees = rustc_hash::FxHashMap<i64, TypeTreeNode>;

/// Flatten a typetree into `(name, type, level, metaflag)` nodes (depth-first).
///
/// IMPORTANT: the tuple order must match `monobehaviour_typetree_export::read`,
/// which pushes `(name, ty, level, flags)` before handing flat nodes to
/// `reconstruct_typetree_node` — i.e. **name first, type second**. The fourth
/// element is restored into `m_MetaFlag` (drives alignment via `requires_align`).
/// Swapping name/type here silently produces typetrees whose `m_Type` strings
/// never match (`PPtr<...>` / `int` / `string` ...), so phase-2 PPtr rewriting
/// skips every reference and the zero-fill fallback then nulls them all out.
pub fn flatten_typetree_node(node: &TypeTreeNode) -> Vec<FlatTypeTreeNode> {
    let mut out = Vec::new();
    fn rec(node: &TypeTreeNode, level: u8, out: &mut Vec<FlatTypeTreeNode>) {
        out.push((
            node.m_Name.clone(),
            node.m_Type.clone(),
            level,
            node.m_MetaFlag.unwrap_or(0),
        ));
        for child in &node.children {
            rec(child, level + 1, out);
        }
    }
    rec(node, 0, &mut out);
    out
}


// ===== v12 embed-deps: intermediate storage for cross-file dependencies =====

pub fn embedded_bin_path(cache_dir: &Path) -> PathBuf {
    cache_dir.join("embedded.bin")
}

pub fn embedded_index_path(cache_dir: &Path) -> PathBuf {
    cache_dir.join("embedded_index.json")
}

/// One source file that embedded objects were pulled from. `externals` is that
/// file's own external reference table (path names, index order preserved) so
/// phase 2 can resolve/rewrite PPtrs inside embedded object data.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EmbeddedSource {
    pub name: String,
    pub externals: Vec<String>,
    pub big_endian: bool,
}

/// A serialized type shared by embedded records. `script_ext` is
/// `Some((Some(file), id))` for MonoBehaviours whose MonoScript lives in an
/// external file (kept external in the final bundle, same as scene scripts).
/// `typetree` is `Some` when the source file carried one or one was generated
/// for a MonoBehaviour; `None` means "native class, take it from the tpk".
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EmbeddedType {
    pub class_id: i32,
    pub script_id_hex: String,
    pub old_type_hash_hex: String,
    #[serde(default)]
    pub script_ext: Option<(Option<String>, i64)>,
    #[serde(default)]
    pub typetree: Option<Vec<FlatTypeTreeNode>>,
}

/// One embedded object: `src` indexes `EmbeddedIndex::sources`, `ty` indexes
/// `EmbeddedIndex::types`, data bytes live in `embedded.bin` at `offset..offset+len`.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EmbeddedRecord {
    pub src: u32,
    pub path_id: i64,
    pub ty: u32,
    pub offset: u64,
    pub len: u64,
}

#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct EmbeddedIndex {
    pub sources: Vec<EmbeddedSource>,
    pub types: Vec<EmbeddedType>,
    pub records: Vec<EmbeddedRecord>,
}

impl EmbeddedIndex {
    pub fn load(cache_dir: &Path) -> Result<Option<EmbeddedIndex>> {
        let path = embedded_index_path(cache_dir);
        if !path.exists() {
            return Ok(None);
        }
        let raw = std::fs::read_to_string(&path)
            .with_context(|| format!("reading {}", path.display()))?;
        let idx: EmbeddedIndex =
            serde_json::from_str(&raw).with_context(|| "parsing embedded_index.json")?;
        Ok(Some(idx))
    }

    pub fn save(&self, cache_dir: &Path) -> Result<()> {
        let path = embedded_index_path(cache_dir);
        let tmp = path.with_extension("json.tmp");
        let raw = serde_json::to_string(self)?;
        std::fs::write(&tmp, raw.as_bytes())
            .with_context(|| format!("writing {}", tmp.display()))?;
        std::fs::rename(&tmp, &path)?;
        Ok(())
    }
}

pub fn hex16(bytes: &[u8; 16]) -> String {
    let mut s = String::with_capacity(32);
    for b in bytes {
        s.push_str(&format!("{b:02x}"));
    }
    s
}

pub fn unhex16(s: &str) -> [u8; 16] {
    let mut out = [0u8; 16];
    for (i, slot) in out.iter_mut().enumerate() {
        if let (Some(a), Some(b)) = (
            s.as_bytes().get(i * 2).and_then(|c| (*c as char).to_digit(16)),
            s.as_bytes().get(i * 2 + 1).and_then(|c| (*c as char).to_digit(16)),
        ) {
            *slot = (a * 16 + b) as u8;
        }
    }
    out
}
