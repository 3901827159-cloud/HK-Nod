pub mod batched_cache;
pub mod embed_deps;
mod merge_serialized;
pub mod monobehaviour_typetree_export;

pub use rabex;
use rabex::objects::ClassId;
use rabex_env::Environment;
use rabex_env::env::Data;
use rabex_env::handle::SerializedFileHandle;
use rabex_env::resolver::{EnvResolver as _, GameFiles};
use rabex_env::scene_lookup::SceneLookup;
use rabex_env::unity::types::{AssetBundle, AssetInfo, MonoBehaviour, PreloadData, Transform};

use anyhow::{Context, Result};
use indexmap::{IndexMap, IndexSet};
use log::warn;
use rabex::UnityVersion;
use rabex::files::bundlefile::{BundleFileBuilder, CompressionType};
use rabex::files::serializedfile::FileIdentifier;
use rabex::files::serializedfile::builder::SerializedFileBuilder;
use rabex::files::{SerializedFile, serializedfile};
use rabex::objects::pptr::{FileId, PPtr, PathId};
use rabex::tpk::TpkTypeTreeBlob;
use rabex::typetree::{TypeTreeNode, TypeTreeProvider};
use rayon::iter::{IntoParallelIterator, IntoParallelRefIterator, ParallelIterator};
use rustc_hash::{FxHashMap, FxHashSet};
use std::borrow::Cow;
use std::collections::BTreeSet;
use std::fmt::Debug;
use std::io::{Cursor, Read, Seek, Write};
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicUsize, Ordering};

pub struct RepackSettings {
    pub scene_objects: IndexMap<String, Vec<String>>,
    pub extra_objects: IndexMap<String, IndexSet<String>>,
}
impl RepackSettings {
    pub fn is_empty(&self) -> bool {
        self.scene_objects.is_empty() && self.extra_objects.is_empty()
    }
}

pub struct RepackScene<'a> {
    pub original_name: PathBuf,
    pub scene_name: String,

    pub serialized: SerializedFile,
    pub serialized_data: Data,

    pub keep_objects: BTreeSet<i64>,
    pub roots: Vec<(String, Transform)>,
    pub replacements: FxHashMap<PathId, Vec<u8>>,

    pub monobehaviour_types: FxHashMap<i64, &'a TypeTreeNode>,

    /// Requested object paths that could not be found in this scene file.
    pub missing: Vec<String>,

    /// v12: cross-file references inside the reachable closure (candidates
    /// for dependency embedding; see `embed_deps`).
    pub externals: BTreeSet<PPtr>,
}

// Filename, PathId, Classname, Objectname
type ExtraObject = (PathBuf, PathId, String, String);

pub fn repack_scenes<'a>(
    env: &'a Environment,
    repack_settings: RepackSettings,
    prepare_scripts: bool,
    disable_roots: bool,
) -> Result<(Vec<RepackScene<'a>>, Vec<ExtraObject>)> {
    let (scenes, extra_objects) = collect_what_to_repack(
        env,
        &repack_settings,
        |filename, scene_name, object_paths, file, data| {
            let settings = RepackSceneSettings {
                object_paths,
                disable_roots,
            };
            repack_scene(
                env,
                prepare_scripts,
                filename,
                scene_name,
                settings,
                file,
                data,
            )
        },
    )?;

    for (class_name, names) in repack_settings.extra_objects {
        for name in names {
            let found = extra_objects
                .iter()
                .any(|(_, _, found_class_name, found_name)| {
                    class_name == *found_class_name && name == *found_name
                });
            if !found {
                warn!("Did not found {class_name} named '{name}' in game files");
            }
        }
    }

    Ok((scenes, extra_objects))
}

// TODO: this is a mess, refactor it away
fn collect_what_to_repack<T: Send + Sync>(
    env: &Environment,
    repack_settings: &RepackSettings,
    // |filename, scene_name, object_paths, file, data|
    f: impl Fn(&Path, &str, &[String], SerializedFile, Data) -> Result<T> + Send + Sync,
) -> Result<(Vec<T>, Vec<ExtraObject>)> {
    let build_settings = env.build_settings()?;
    let has_extra_objects = !repack_settings.extra_objects.is_empty();

    let read = |filename: &Path, scene_name| -> Result<_> {
        let data = env.game_files.read_path(filename).with_context(|| {
            format!(
                "{} does not exist in game files",
                scene_name_display(scene_name, filename)
            )
        })?;

        let mut reader = Cursor::new(data.as_ref());
        let file = SerializedFile::from_reader(&mut reader).with_context(|| {
            format!(
                "Could not parse {}",
                scene_name_display(scene_name, filename)
            )
        })?;

        Ok((data, file))
    };

    // if we have extra monobehaviour to collect, we have to look at every possible file
    let (extra_objects, scenes) = if has_extra_objects {
        let scene_lookup: Vec<_> = build_settings.scene_names().collect();

        env.game_files
            .serialized_files()?
            .into_par_iter()
            .map(|filename| -> Result<_> {
                let (data, file_raw) = read(&filename, None)?;
                let file = SerializedFileHandle::new(env, &file_raw, data.as_ref());

                let extra_objects =
                    find_extra_objects(file, &filename, &repack_settings.extra_objects)?;

                if let Some(scene_index) = filename
                    .to_str()
                    .and_then(|name| name.strip_prefix("level"))
                    .and_then(|x| x.parse::<usize>().ok())
                {
                    let scene_name = scene_lookup[scene_index];

                    if let Some(object_paths) = repack_settings.scene_objects.get(scene_name) {
                        let x = f(&filename, scene_name, object_paths, file_raw, data)?;
                        return Ok((extra_objects, Some(x)));
                    }
                }

                Ok((extra_objects, None))
            })
            .try_fold(
                || (Vec::new(), Vec::new()),
                |mut acc, item| -> Result<_> {
                    let item = item?;
                    acc.0.extend(item.0);
                    if let Some(scene) = item.1 {
                        acc.1.push(scene);
                    }
                    Ok(acc)
                },
            )
            .try_reduce(
                || (Vec::new(), Vec::new()),
                |mut acc, item| {
                    acc.0.extend(item.0);
                    acc.1.extend(item.1);
                    Ok(acc)
                },
            )?
    } else {
        let scene_lookup = build_settings.scene_name_lookup();

        let scene_files = repack_settings
            .scene_objects
            .iter()
            .map(|(scene_name, object_paths)| {
                let scene_index = *scene_lookup.get(scene_name).with_context(|| {
                    let scene_names = scene_lookup
                        .keys()
                        .map(String::as_str)
                        .collect::<Vec<_>>()
                        .join("\n-  ");
                    format!(
                        "Scene '{scene_name}' was not found in game files.\nFound\n- {}",
                        scene_names
                    )
                })?;
                let filename = format!("level{scene_index}");
                Ok((scene_name, PathBuf::from(filename), object_paths.as_slice()))
            })
            .collect::<Result<Vec<_>>>()?;

        let scenes = scene_files
            .par_iter()
            .map(|(scene_name, filename, object_paths)| -> Result<_> {
                let (data, file) = read(filename, None)?;
                f(filename, scene_name, object_paths, file, data)
            })
            .collect::<Result<Vec<_>>>()?;
        (Vec::new(), scenes)
    };

    Ok((scenes, extra_objects))
}

struct RepackSceneSettings<'a> {
    object_paths: &'a [String],
    disable_roots: bool,
}

fn repack_scene<'a>(
    env: &'a Environment,
    prepare_scripts: bool,
    original_name: &Path,
    scene_name: &str,
    settings: RepackSceneSettings,
    file: SerializedFile,
    serialized_data: Data,
) -> Result<RepackScene<'a>> {
    let reader = &mut Cursor::new(serialized_data.as_ref());

    let scene_paths = deduplicate_objects(original_name, scene_name, settings.object_paths);

    let mut replacements = FxHashMap::default();
    let result = rabex_env::reachable::prune::prune_scene(
        env,
        &file,
        reader,
        scene_paths.iter().copied(),
        &mut replacements,
        settings.disable_roots,
    )
    .with_context(|| scene_name_display(scene_name, original_name))?;

    let monobehaviour_types = prepare_scripts
        .then(|| prepare_monobehaviour_types(env, &file, reader))
        .unwrap_or_default();

    Ok(RepackScene {
        original_name: original_name.to_owned(),
        scene_name: scene_name.to_owned(),
        serialized: file,
        serialized_data,
        keep_objects: result.reachable,
        roots: result.roots,
        replacements,
        monobehaviour_types,
        missing: result.missing,
        externals: result.externals,
    })
}

fn find_extra_objects(
    file: SerializedFileHandle<GameFiles, impl TypeTreeProvider>,
    filename: &Path,
    // classname: [objectname]
    extra_objects: &IndexMap<String, IndexSet<String>>,
) -> Result<Vec<(PathBuf, PathId, String, String)>, anyhow::Error> {
    let mut roots = Vec::new();

    for mb_obj in file.objects_of::<MonoBehaviour>() {
        let Some(script) = mb_obj.mono_script()? else {
            continue;
        };

        let Some(mb_names) = extra_objects.get(&script.m_ClassName) else {
            continue;
        };

        let mb = mb_obj.read()?;
        if mb_names.contains(&mb.m_Name) {
            roots.push((
                filename.to_owned(),
                mb_obj.path_id(),
                script.m_ClassName,
                mb.m_Name,
            ));
        }
    }
    Ok(roots)
}

fn scene_name_display<'a>(scene_name: impl Into<Option<&'a str>>, original_name: &Path) -> String {
    match scene_name.into() {
        Some(scene_name) => format!("{scene_name} ({})'", original_name.display()),
        None => format!("'{}'", original_name.display()),
    }
}

fn prune_types(file: &mut SerializedFile) -> FxHashMap<i32, i32> {
    let used_types: FxHashSet<_> = file.objects().map(|obj| obj.m_TypeID).collect();
    let mut old_to_new: FxHashMap<i32, i32> = FxHashMap::default();
    file.m_Types = std::mem::take(&mut file.m_Types)
        .into_iter()
        .enumerate()
        .filter(|&(idx, _)| used_types.contains(&(idx as i32)))
        .enumerate()
        .map(|(new_index, (old_index, ty))| {
            old_to_new.insert(old_index as i32, new_index as i32);
            ty
        })
        .collect();
    old_to_new
}

fn deduplicate_objects<'a>(
    original_name: &Path,
    scene_name: &str,
    paths: &'a [String],
) -> IndexSet<&'a str> {
    let mut deduplicated = IndexSet::new();
    for item in paths {
        if !deduplicated.insert(item.as_str()) {
            warn!(
                "Duplicate object: '{item}' in {}",
                scene_name_display(Some(scene_name), original_name)
            );
        }
    }
    deduplicated
}

#[derive(Debug, Default)]
pub struct Stats {
    pub objects_before: usize,
    pub objects_after: usize,
    pub size_before: usize,
    pub size_after: usize,
}

pub fn pack_to_scene_bundle(
    writer: impl Write + Seek,
    bundle_name: &str,
    tpk_blob: &TpkTypeTreeBlob,
    tpk: &impl TypeTreeProvider,
    unity_version: &UnityVersion,
    scenes: &mut [RepackScene],
    compression: CompressionType,
) -> Result<Stats> {
    let mut stats = Stats::default();
    let common_offset_map = serializedfile::build_common_offset_map(tpk_blob, unity_version);

    let mut asset_bundle = AssetBundle::scene_base(bundle_name);
    for scene in &*scenes {
        let scene_name = &scene.scene_name;
        let scene_hash = get_scene_bundle_filename(bundle_name, scene_name);
        let path = get_scene_bundle_scene_name(bundle_name, scene_name);
        asset_bundle.add_scene(&path, &scene_hash);
    }

    let mut asset_bundle = Some(asset_bundle);

    let mut builder = BundleFileBuilder::unityfs(7, unity_version);
    for scene in scenes {
        let mut sharedassets =
            SerializedFileBuilder::new(unity_version, tpk, &common_offset_map, true);

        sharedassets.add_object_at(1, &PreloadData::default())?;

        if let Some(asset_bundle) = asset_bundle.take() {
            sharedassets.add_object_at(2, &asset_bundle)?;
        }

        let mut out = Cursor::new(Vec::new());
        sharedassets.write(&mut out)?;

        let scene_hash = get_scene_bundle_filename(bundle_name, &scene.scene_name);
        builder.add_file(
            &format!("{scene_hash}.sharedAssets",),
            Cursor::new(out.into_inner()),
        )?;

        let trimmed = {
            let serialized = &mut scene.serialized;

            let data = scene.serialized_data.as_ref();

            stats.objects_before += serialized.objects().len();
            stats.size_before += data.len();

            serialized.modify_objects(|objects| {
                objects.retain(|obj| scene.keep_objects.contains(&obj.m_PathID));
            });
            stats.objects_after += serialized.objects().len();

            let type_remap = prune_types(serialized);

            let new_objects = serialized.take_objects();
            let objects = new_objects.into_iter().map(|mut obj| {
                let data = match scene.replacements.remove(&obj.m_PathID) {
                    Some(owned) => Cow::Owned(owned),
                    None => {
                        let offset = obj.m_Offset as usize;
                        let size = obj.m_Size as usize;
                        Cow::Borrowed(&data[offset..offset + size])
                    }
                };

                obj.m_TypeID = type_remap[&obj.m_TypeID];

                (obj, data)
            });

            let mut writer = Cursor::new(Vec::new());
            serializedfile::write_serialized_with_objects(
                &mut writer,
                serialized,
                &common_offset_map,
                objects,
            )?;
            let out = writer.into_inner();

            stats.objects_after += serialized.objects().len();
            stats.size_after += out.len();

            out
        };
        builder.add_file(&scene_hash, Cursor::new(trimmed))?;
    }

    builder.write(writer, compression)?;

    Ok(stats)
}

pub enum MonobehaviourTypetreeMode<'a> {
    GenerateRuntime,
    Export(&'a [u8]),
}

pub fn pack_to_asset_bundle(
    env: &Environment,
    writer: impl Write + Seek,
    bundle_name: &str,
    tpk_blob: &TpkTypeTreeBlob,
    scenes: Vec<RepackScene>,
    extra_objects: Vec<ExtraObject>,
    compression: CompressionType,
    enable_typetree: bool,
) -> Result<Stats> {
    let unity_version = env.unity_version()?;
    let common_offset_map = serializedfile::build_common_offset_map(tpk_blob, unity_version);
    let mut stats = Stats::default();

    let mut builder =
        SerializedFileBuilder::new(unity_version, &env.tpk, &common_offset_map, enable_typetree);
    builder.next_path_id = 2;

    let mut asset_bundle = AssetBundle::asset_base(bundle_name);
    for (filename, path_id, class_name, object_name) in extra_objects {
        // TODO cached
        let file_id = builder.add_external_uncached(FileIdentifier::try_from(filename)?);
        let info = AssetInfo::new(PPtr::new(file_id, path_id));
        asset_bundle
            .m_Container
            .insert(get_extra_object_asset_name(&class_name, &object_name), info);
    }

    let intermediate = scenes
        .into_iter()
        .map(|mut scene| {
            let serialized = &mut scene.serialized;
            let data = scene.serialized_data.as_ref();

            assert_eq!(serialized.m_bigIDEnabled, None);
            if let Some(ref_types) = &serialized.m_RefTypes
                && !ref_types.is_empty()
            {
                warn!(
                    "Found {} m_RefTypes in scene {}, this is untested.",
                    ref_types.len(),
                    scene.scene_name
                );
            }

            stats.objects_before += serialized.objects().len();
            stats.size_before += data.len();
            serialized.modify_objects(|objects| {
                objects.retain(|obj| scene.keep_objects.contains(&obj.m_PathID))
            });
            stats.objects_after += serialized.objects().len();

            let remap = merge_serialized::add_scene_meta_to_builder(&mut builder, serialized)?;

            if builder.serialized.m_EnableTypeTree {
                for ty in &mut builder.serialized.m_Types {
                    if ty.m_Type.is_none() {
                        if ty.m_ClassID == ClassId::MonoBehaviour {
                            log::warn!(
                                "Asset bundle is to be serialized with type tree information, "
                            );
                            log::warn!("but the repack sources don't contain any.");
                            log::warn!(
                                "Monobehaviours typetrees will not contain serialized fields."
                            );
                        }
                        ty.m_Type = Some(
                            env.tpk
                                .get_typetree_node(ty.m_ClassID, unity_version)
                                .ok_or(serializedfile::Error::NoTypetree(ty.m_ClassID))?
                                .into_owned(),
                        );
                    }
                }
            }

            for (scene_path, transform) in scene.roots.iter() {
                let mut go = transform.m_GameObject;
                assert!(go.is_local());
                if let Some(replacement) = remap.path_id.get(&go.m_PathID) {
                    go.m_PathID = *replacement;
                }

                let info = AssetInfo::new(go.untyped());
                let path = get_asset_bundle_object_asset_name(&scene.scene_name, scene_path);

                asset_bundle.m_Container.insert(path, info);
            }

            Ok((scene, remap))
        })
        .collect::<Result<Vec<_>>>()?;

    let objects = intermediate
        .into_par_iter()
        .map(|(mut scene, remap)| {
            merge_serialized::remap_objects(
                &scene.scene_name,
                scene.original_name,
                &builder.serialized,
                scene.serialized_data.as_ref(),
                &env.tpk,
                scene.serialized.take_objects(),
                scene.replacements,
                scene.monobehaviour_types,
                remap,
                None,
                &scene.serialized.m_Externals,
            )
            .collect::<Vec<_>>()
        })
        .collect::<Vec<Vec<Result<_>>>>();

    objects.into_iter().try_for_each(|objects| -> Result<_> {
        for obj in objects {
            let (obj, data) = obj?;
            builder.objects.insert(obj.m_PathID, (obj, data));
        }
        Ok(())
    })?;

    builder.add_object_at(1, &asset_bundle)?;

    let mut out = Vec::new();
    builder.write(&mut Cursor::new(&mut out))?;
    stats.size_after += out.len();

    let mut bundle_builder = BundleFileBuilder::unityfs(7, unity_version);
    bundle_builder.add_file(&format!("CAB-{bundle_name}"), Cursor::new(out))?;

    bundle_builder.write(writer, compression)?;

    Ok(stats)
}

#[inline(never)]
pub(crate) fn prepare_monobehaviour_types<'a>(
    env: &'a Environment,
    file: &SerializedFile,
    reader: &mut (impl Read + Seek),
) -> FxHashMap<PathId, &'a TypeTreeNode> {
    file.objects_of::<MonoBehaviour>(&env.tpk)
        .map(|mb_info| -> Result<_> {
            let path_id = mb_info.info.m_PathID;

            let mb = mb_info.read(reader)?;
            if mb.m_Script.is_null() {
                return Ok(None);
            }
            let script = env
                .deref_read(mb.m_Script, file, reader)
                .with_context(|| format!("In monobehaviour {}", mb_info.info.m_PathID))?;

            let assembly_name = script.assembly_name();
            let full_name = script.full_name();

            let ty = &file.m_Types[mb_info.info.m_TypeID as usize];
            if let Some(ty) = &ty.m_Type {
                // TODO: check if there is actually more than default information present
                let ty =
                    env.typetree_generator
                        .insert_cache(&assembly_name, &full_name, ty.clone());
                return Ok(Some((path_id, ty)));
            }

            let ty = env
                .generate_typetree(&assembly_name, &full_name)
                .with_context(|| {
                    format!("Reading script {assembly_name} {full_name} at object {path_id}",)
                })?;
            let Some(ty) = ty else { return Ok(None) };

            Ok(Some((path_id, ty)))
        })
        .filter_map(|x| x.transpose())
        .filter_map(|ty| match ty {
            Ok(val) => Some(val),
            Err(e) => {
                log::error!("{e:?}");
                None
            }
        })
        .collect::<FxHashMap<_, _>>()
}

pub fn pack_to_shallow_asset_bundle(
    env: &Environment,
    writer: impl Write + Seek,
    bundle_name: &str,
    repack_settings: RepackSettings,
    compression: CompressionType,
) -> Result<Stats> {
    let objects_before = AtomicUsize::new(0);
    let size_before = AtomicUsize::new(0);

    let (scene_objects, extra_objects) = collect_what_to_repack(
        env,
        &repack_settings,
        |filename, scene_name, object_paths, file, data| {
            let object_paths = deduplicate_objects(filename, scene_name, object_paths);

            objects_before.fetch_add(file.objects().len(), Ordering::Relaxed);
            size_before.fetch_add(data.as_ref().len(), Ordering::Relaxed);

            let reader = &mut Cursor::new(data.as_ref());

            let mut path_ids = Vec::with_capacity(object_paths.len());
            let lookup = SceneLookup::new(&file, reader, &env.tpk)?;
            for path in object_paths {
                let Some((_, transform)) = lookup.lookup_path(reader, path)? else {
                    warn!("Could not find path '{path}' in {scene_name}");
                    continue;
                };
                path_ids.push((path.to_owned(), transform.m_GameObject.m_PathID));
            }

            Ok(((scene_name.to_owned(), filename.to_owned()), path_ids))
        },
    )?;

    create_shallow_assetbundle(
        env,
        writer,
        bundle_name,
        scene_objects,
        extra_objects,
        compression,
    )?;

    Ok(Stats {
        objects_before: objects_before.into_inner(),
        objects_after: 0,
        size_before: size_before.into_inner(),
        size_after: 0,
    })
}

fn create_shallow_assetbundle(
    env: &Environment,
    writer: impl Write + Seek,
    bundle_name: &str,
    // (scenename, Filename)
    objects: Vec<((String, PathBuf), Vec<(String, PathId)>)>,
    extra_objects: Vec<ExtraObject>,
    compression: CompressionType,
) -> Result<()> {
    let unity_version = env.unity_version()?;
    let common_offset_map = serializedfile::build_common_offset_map(&env.tpk.inner, unity_version);

    let mut builder =
        SerializedFileBuilder::new(unity_version, &env.tpk, &common_offset_map, false);

    let mut ab = AssetBundle::asset_base(bundle_name);

    for (filename, path_id, class_name, object_name) in extra_objects {
        // TODO cached
        let file_id = builder.add_external_uncached(FileIdentifier::try_from(filename)?);
        let info = AssetInfo::new(PPtr::new(file_id, path_id));
        ab.m_Container
            .insert(get_extra_object_asset_name(&class_name, &object_name), info);
    }

    for ((scene_name, original_name), objects) in objects {
        // TODO: is this right?
        let file_index = builder.add_external_uncached(FileIdentifier::try_from(original_name)?);

        for (scene_path, path_id) in objects {
            let path = get_asset_bundle_object_asset_name(&scene_name, &scene_path);
            let info = AssetInfo::new(PPtr::new(file_index, path_id));
            ab.m_Container.insert(path, info);
        }
    }

    builder.add_object_at(1, &ab)?;

    let mut builder_out = Vec::new();
    builder.write(Cursor::new(&mut builder_out))?;

    let mut bundle = BundleFileBuilder::unityfs(7, unity_version);
    bundle.add_file(&format!("CAB-{bundle_name}"), Cursor::new(builder_out))?;

    bundle.write(writer, compression)?;

    Ok(())
}

fn get_scene_bundle_filename(bundle_name: &str, scene_name: &str) -> String {
    format!("BuildPlayer-{bundle_name}_{scene_name}")
}

fn get_scene_bundle_scene_name(bundle_name: &str, scene_name: &str) -> String {
    format!("Assets/unity-scene-repacker/{bundle_name}_{scene_name}.unity")
}
fn get_asset_bundle_object_asset_name(scene_name: &str, scene_path: &str) -> String {
    format!("{scene_name}/{scene_path}.prefab").to_lowercase()
}
fn get_extra_object_asset_name(class_name: &str, object_name: &str) -> String {
    format!("ExtraObjects/{class_name}/{object_name}.prefab").to_lowercase()
}

// ============================================================================
// Batched / cached repack (LSCR Layer 1)
//
// Phase 1 (`repack_scenes_batched`): process scenes one at a time, write a
// trimmed intermediate serialized file + metadata to disk, then drop the scene.
// Phase 2 (`pack_to_asset_bundle_from_cache`): merge all intermediates into a
// single AssetBundle, reading only the small trimmed files.
// ============================================================================

use batched_cache::{Manifest, SceneMeta, SceneStatus};

/// Write the trimmed version of a repacked scene (retain keep_objects, prune
/// unused types, apply replacements) to `writer`. Returns the number of
/// objects after trimming.
fn trim_scene_to_writer<W: Write + Seek>(
    scene: &mut RepackScene,
    common_offset_map: &serializedfile::CommonOffsetMap<'_>,
    writer: W,
) -> Result<usize> {
    let RepackScene {
        serialized,
        serialized_data,
        keep_objects,
        replacements,
        ..
    } = scene;

    let data = serialized_data.as_ref();

    serialized.modify_objects(|objects| {
        objects.retain(|obj| keep_objects.contains(&obj.m_PathID));
    });
    let objects_after = serialized.objects().len();

    let type_remap = prune_types(serialized);

    let new_objects = serialized.take_objects();
    let objects = new_objects.into_iter().map(|mut obj| {
        let obj_data = match replacements.remove(&obj.m_PathID) {
            Some(owned) => Cow::Owned(owned),
            None => {
                let offset = obj.m_Offset as usize;
                let size = obj.m_Size as usize;
                Cow::Borrowed(&data[offset..offset + size])
            }
        };
        obj.m_TypeID = type_remap[&obj.m_TypeID];
        (obj, obj_data)
    });

    serializedfile::write_serialized_with_objects(writer, serialized, common_offset_map, objects)?;

    Ok(objects_after)
}

fn write_atomic(path: &Path, data: &[u8]) -> Result<()> {
    let tmp = path.with_extension("tmp");
    std::fs::write(&tmp, data).with_context(|| format!("writing {}", tmp.display()))?;
    std::fs::rename(&tmp, path).with_context(|| format!("renaming into place {}", path.display()))?;
    Ok(())
}

/// Phase 1 of the batched repack: resolve every requested scene, process them
/// sequentially, writing one intermediate file pair per scene to `cache_dir`.
/// Scenes that fail are recorded in the manifest and skipped.
///
/// `resume`: if true and a matching manifest exists, already-done scenes are
/// skipped. If false, `cache_dir` is cleared and rebuilt from scratch.
pub fn repack_scenes_batched(
    env: &Environment,
    repack_settings: RepackSettings,
    prepare_scripts: bool,
    disable_roots: bool,
    tpk_blob: &TpkTypeTreeBlob,
    cache_dir: &Path,
    bundle_name: &str,
    resume: bool,
) -> Result<Manifest> {
    anyhow::ensure!(
        repack_settings.extra_objects.is_empty(),
        "batched repack does not support extra_objects"
    );

    let unity_version = env.unity_version()?;
    let common_offset_map = serializedfile::build_common_offset_map(tpk_blob, unity_version);

    // Resolve scene names -> level files up front (fail fast on unknown scenes,
    // same as the one-shot path).
    let build_settings = env.build_settings()?;
    let scene_lookup = build_settings.scene_name_lookup();
    let scene_files: IndexMap<String, (PathBuf, Vec<String>)> = repack_settings
        .scene_objects
        .iter()
        .map(|(scene_name, object_paths)| {
            let scene_index = *scene_lookup.get(scene_name).with_context(|| {
                format!("Scene '{scene_name}' was not found in game files")
            })?;
            Ok((
                scene_name.clone(),
                (PathBuf::from(format!("level{scene_index}")), object_paths.clone()),
            ))
        })
        .collect::<Result<_>>()?;

    if !resume {
        std::fs::remove_dir_all(cache_dir).ok();
    }
    std::fs::create_dir_all(cache_dir)?;

    let scene_names: Vec<String> = scene_files.keys().cloned().collect();
    let mut manifest = if resume {
        match Manifest::load(cache_dir)? {
            Some(m)
                if m.bundle_name == bundle_name
                    && m.scenes.keys().collect::<std::collections::BTreeSet<_>>()
                        == scene_names.iter().collect::<std::collections::BTreeSet<_>>() =>
            {
                log::info!(
                    "resuming from manifest: {} done, {} failed, {} pending",
                    m.done_count(),
                    m.failed_count(),
                    m.scenes.len() - m.done_count() - m.failed_count()
                );
                m
            }
            Some(_) => {
                log::info!("existing manifest does not match, starting fresh");
                Manifest::new("AssetBundle", bundle_name, &scene_names)
            }
            None => Manifest::new("AssetBundle", bundle_name, &scene_names),
        }
    } else {
        Manifest::new("AssetBundle", bundle_name, &scene_names)
    };

    for scene_name in scene_names.iter() {
        // v13 breadcrumb: live progress for on-device builds (watchable via
        // a file manager while the first cache build runs; embed-deps adds
        // its own lines later in the same file).
        {
            use std::io::Write;
            let line = format!(
                "phase1: {}/{} scenes done, current: {scene_name}\n",
                manifest.done_count(),
                scene_names.len()
            );
            if let Ok(mut f) = std::fs::OpenOptions::new()
                .create(true)
                .append(true)
                .open(cache_dir.join("progress.txt"))
            {
                let _ = f.write_all(line.as_bytes());
            }
        }
        let (filename, object_paths) = &scene_files[scene_name];
        let entry = manifest.scenes.get_mut(scene_name).expect("manifest entry");
        if entry.status == SceneStatus::Done
            && batched_cache::scene_serialized_path(cache_dir, entry.idx).exists()
            && batched_cache::scene_meta_path(cache_dir, entry.idx).exists()
        {
            // v12: also require the intermediates to still be on disk, so a
            // crash between "merge done" and "cleanup" cannot leave a state
            // where phase 2 has nothing to read.
            continue;
        }
        if entry.status == SceneStatus::Done {
            log::info!("scene {scene_name}: marked done but intermediates missing, redoing");
        }
        let idx = entry.idx;

        let result = (|| -> Result<Vec<String>> {
            let data = env.game_files.read_path(filename).with_context(|| {
                format!("{scene_name} ({}) does not exist in game files", filename.display())
            })?;
            let mut reader = Cursor::new(data.as_ref());
            let file = SerializedFile::from_reader(&mut reader)
                .with_context(|| format!("Could not parse {scene_name} ({})", filename.display()))?;

            // LSCR risk #1 diagnostic: if the level file carries no embedded typetrees,
            // pruning traces MonoBehaviour fields with the tpk shell typetree and can
            // miss objects referenced only from MonoBehaviour fields (dangling PPtrs).
            log::info!(
                "scene {scene_name}: parsed {} objects, m_EnableTypeTree={}",
                file.objects().len(),
                file.m_EnableTypeTree,
            );

            let settings = RepackSceneSettings {
                object_paths,
                disable_roots,
            };
            let mut scene = repack_scene(
                env,
                prepare_scripts,
                filename,
                scene_name,
                settings,
                file,
                data,
            )?;

            let objects_before = scene.serialized.objects().len();
            let size_before = scene.serialized_data.as_ref().len();

            let mut out = Cursor::new(Vec::new());
            trim_scene_to_writer(&mut scene, &common_offset_map, &mut out)?;
            write_atomic(&batched_cache::scene_serialized_path(cache_dir, idx), &out.into_inner())?;

            let meta = SceneMeta {
                scene_name: scene_name.clone(),
                original_name: filename.clone(),
                objects_before,
                size_before,
                roots: scene
                    .roots
                    .iter()
                    .map(|(path, transform)| (path.clone(), transform.m_GameObject.m_PathID))
                    .collect(),
                monobehaviour_types: scene
                    .monobehaviour_types
                    .iter()
                    .map(|(path_id, tt)| (*path_id, batched_cache::flatten_typetree_node(tt)))
                    .collect(),
                missing: scene.missing.clone(),
                externals: {
                    let mut v: Vec<(String, i64)> = Vec::new();
                    for p in scene.externals.iter() {
                        let fi = p.m_FileID.value();
                        if fi <= 0 {
                            continue;
                        }
                        if let Some(ext) = scene.serialized.m_Externals.get((fi - 1) as usize) {
                            if embed_deps::is_builtin_external(&ext.pathName) {
                                continue;
                            }
                            v.push((ext.pathName.clone(), p.m_PathID));
                        }
                    }
                    v.sort();
                    v.dedup();
                    v
                },
            };
            meta.save(cache_dir, idx)?;
            Ok(scene.missing.clone())
        })();

        match result {
            Ok(missing) => {
                if !missing.is_empty() {
                    warn!(
                        "scene {scene_name}: {} requested paths not found: {}",
                        missing.len(),
                        missing.join(", ")
                    );
                }
                entry.status = SceneStatus::Done;
                entry.error = None;
                log::info!("repacked scene {scene_name} ({idx})");
            }
            Err(e) => {
                entry.status = SceneStatus::Failed;
                entry.error = Some(format!("{e:?}"));
                warn!("scene {scene_name} failed, skipping: {e:?}");
            }
        }
        manifest.save(cache_dir)?;
    }

    // Aggregate a report of every requested path that could not be found
    // across all completed scenes, so the C# wrapper (or a human) can see the
    // full picture after a run.
    let mut missing_report = indexmap::IndexMap::new();
    for (scene_name, entry) in manifest.scenes.iter() {
        if entry.status != SceneStatus::Done {
            continue;
        }
        let Ok(meta) = SceneMeta::load(cache_dir, entry.idx) else {
            continue;
        };
        if !meta.missing.is_empty() {
            missing_report.insert(scene_name.clone(), meta.missing.clone());
        }
    }
    if missing_report.is_empty() {
        std::fs::remove_file(cache_dir.join("missing_paths.json")).ok();
    } else {
        let raw = serde_json::to_vec_pretty(&missing_report)?;
        write_atomic(&cache_dir.join("missing_paths.json"), &raw)?;
        warn!(
            "LSCR: {} scene(s) had unresolved object paths, see missing_paths.json",
            missing_report.len()
        );
    }

    // Phase 1b (v12 embed-deps): collect the cross-file dependency closure of
    // all done scenes. Non-fatal on failure: phase 2 then keeps the stock
    // external-reference behaviour (invisible/broken assets on Android, but
    // the build itself still produces a bundle).
    if !(manifest.deps_done
        && batched_cache::embedded_index_path(cache_dir).exists()
        && batched_cache::embedded_bin_path(cache_dir).exists())
    {
        manifest.deps_done = false;
        let done_scenes: Vec<(String, usize)> = manifest
            .scenes
            .iter()
            .filter(|(_, e)| e.status == SceneStatus::Done)
            .map(|(n, e)| (n.clone(), e.idx))
            .collect();
        if !done_scenes.is_empty() {
            match embed_deps::collect_embedded_deps(env, cache_dir, &done_scenes) {
                Ok(st) => {
                    log::info!(
                        "LSCR embed-deps: {} objects from {} files, {} MiB",
                        st.records,
                        st.sources,
                        st.bytes / (1024 * 1024)
                    );
                    manifest.deps_done = true;
                }
                Err(e) => {
                    warn!("LSCR embed-deps FAILED, externals stay unresolved: {e:?}");
                }
            }
            manifest.save(cache_dir)?;
        }
    }

    Ok(manifest)
}

/// Phase 2 of the batched repack: merge all completed intermediate files from
/// `cache_dir` into a single AssetBundle. Memory usage is bounded by the size
/// of the trimmed intermediates plus the final merged object table.
pub fn pack_to_asset_bundle_from_cache(
    env: &Environment,
    writer: impl Write + Seek,
    bundle_name: &str,
    tpk_blob: &TpkTypeTreeBlob,
    cache_dir: &Path,
    compression: CompressionType,
    enable_typetree: bool,
) -> Result<Stats> {
    let manifest = Manifest::load(cache_dir)?
        .with_context(|| format!("no manifest found in {}", cache_dir.display()))?;
    if manifest.bundle_name != bundle_name {
        anyhow::bail!(
            "manifest bundle name '{}' does not match requested '{bundle_name}'",
            manifest.bundle_name
        );
    }

    let unity_version = env.unity_version()?;
    let common_offset_map = serializedfile::build_common_offset_map(tpk_blob, unity_version);
    let mut stats = Stats::default();

    let mut builder =
        SerializedFileBuilder::new(unity_version, &env.tpk, &common_offset_map, enable_typetree);
    builder.next_path_id = 2;

    let mut asset_bundle = AssetBundle::asset_base(bundle_name);

    // ===== v12 (embed-deps): load the phase-1b dependency closure =====
    let embedded = if manifest.deps_done
        && batched_cache::embedded_index_path(cache_dir).exists()
        && batched_cache::embedded_bin_path(cache_dir).exists()
    {
        match batched_cache::EmbeddedIndex::load(cache_dir)? {
            Some(idx) => {
                log::info!(
                    "LSCR embed-deps: merging {} objects from {} source files",
                    idx.records.len(),
                    idx.sources.len()
                );
                idx
            }
            None => {
                warn!("deps_done set but embedded_index.json unreadable; externals stay unresolved");
                Default::default()
            }
        }
    } else {
        warn!("dependency embedding not present for this cache; bundle keeps stock external references");
        Default::default()
    };

    let mut src_by_name: FxHashMap<&str, u32> = FxHashMap::default();
    for (i, src) in embedded.sources.iter().enumerate() {
        src_by_name.insert(src.name.as_str(), i as u32);
    }

    // Assign final local path ids to every embedded object BEFORE the scene
    // objects, so scene PPtr rewriting can already localize external refs.
    let mut embedded_ids: FxHashMap<(u32, PathId), PathId> = FxHashMap::default();
    for rec in &embedded.records {
        embedded_ids.insert((rec.src, rec.path_id), builder.get_next_path_id());
    }

    // Register serialized types for the embedded objects (incl. MB script types).
    let mut embedded_type_ids: Vec<i32> = Vec::with_capacity(embedded.types.len());
    for ty in embedded.types.iter() {
        let tt = ty
            .typetree
            .as_ref()
            .map(|flat| typetree_generator_api::reconstruct_typetree_node(flat));
        let mut st = serializedfile::SerializedType::simple(ClassId(ty.class_id), tt);
        st.m_ScriptID = batched_cache::unhex16(&ty.script_id_hex);
        st.m_OldTypeHash = batched_cache::unhex16(&ty.old_type_hash_hex);
        if let Some((ext_name, ext_id)) = ty.script_ext.as_ref() {
            let fid = match ext_name {
                Some(name) => builder.get_or_insert_external(name),
                None => FileId::LOCAL,
            };
            let script_types = builder.serialized.m_ScriptTypes.get_or_insert_default();
            let sti: i16 = script_types
                .len()
                .try_into()
                .expect("m_ScriptTypes exceeded i16::MAX");
            script_types.push(serializedfile::LocalSerializedObjectIdentifier {
                m_LocalSerializedFileIndex: fid,
                m_LocalIdentifierInFile: *ext_id,
            });
            st.m_ScriptTypeIndex = sti;
        }
        embedded_type_ids.push(builder.add_type_uncached(st));
    }

    // (file name, path id) -> fresh local id, for external-reference localization
    let localizer = |name: &str, pid: PathId| -> Option<PathId> {
        let si = src_by_name.get(name).copied()?;
        embedded_ids.get(&(si, pid)).copied()
    };

    for (scene_name, entry) in manifest.scenes.iter() {
        if entry.status != SceneStatus::Done {
            continue;
        }
        let meta = SceneMeta::load(cache_dir, entry.idx)?;
        let serialized_bytes =
            std::fs::read(batched_cache::scene_serialized_path(cache_dir, entry.idx))?;
        let mut file =
            SerializedFile::from_reader(&mut Cursor::new(serialized_bytes.as_slice()))?;

        assert_eq!(file.m_bigIDEnabled, None);

        stats.objects_before += meta.objects_before;
        stats.size_before += meta.size_before;
        stats.objects_after += file.objects().len();

        let remap = merge_serialized::add_scene_meta_to_builder(&mut builder, &mut file)?;

        for (scene_path, go_path_id) in &meta.roots {
            let mut go = PPtr::local(*go_path_id);
            if let Some(replacement) = remap.path_id.get(&go.m_PathID) {
                go.m_PathID = *replacement;
            }
            let info = AssetInfo::new(go);
            let path = get_asset_bundle_object_asset_name(scene_name, scene_path);
            asset_bundle.m_Container.insert(path, info);
        }

        let owned_typetrees = meta.owned_monobehaviour_types();
        let mb_types: FxHashMap<PathId, &TypeTreeNode> =
            owned_typetrees.iter().map(|(k, v)| (*k, v)).collect();

        let scene_externals = file.m_Externals.clone();
        let objects = file.take_objects();
        // NOTE: pass `&builder.serialized` (which now owns the merged type
        // table) as the typetree-fallback source, mirroring the one-shot
        // `pack_to_asset_bundle`; `file.m_Types` was drained by
        // `add_scene_meta_to_builder`.
        let remapped: Vec<Result<(serializedfile::ObjectInfo, Cow<'static, [u8]>)>> =
            merge_serialized::remap_objects(
                scene_name,
                meta.original_name.clone(),
                &builder.serialized,
                &serialized_bytes,
                &env.tpk,
                objects,
                FxHashMap::default(),
                mb_types,
                remap,
                Some(&localizer),
                &scene_externals,
            )
            .collect();
        for obj in remapped {
            let (obj, data) = obj?;
            builder.objects.insert(obj.m_PathID, (obj, data));
        }
    }

    // ===== v12: splice in the embedded dependency objects =====
    if !embedded.records.is_empty() {
        let bin_path = batched_cache::embedded_bin_path(cache_dir);
        let mut binf = std::fs::File::open(&bin_path)
            .with_context(|| format!("opening {}", bin_path.display()))?;
        let mut embedded_count = 0usize;
        for rec in &embedded.records {
            let Some(&new_id) = embedded_ids.get(&(rec.src, rec.path_id)) else {
                continue;
            };
            let Some(src) = embedded.sources.get(rec.src as usize) else {
                continue;
            };
            let Some(ty) = embedded.types.get(rec.ty as usize) else {
                continue;
            };
            let mut bytes = vec![0u8; rec.len as usize];
            binf.seek(std::io::SeekFrom::Start(rec.offset))?;
            if let Err(e) = binf.read_exact(&mut bytes) {
                warn!(
                    "LSCR embed-deps: short read for {}:{} ({e}); skipping",
                    src.name, rec.path_id
                );
                continue;
            }

            // Rewrite the object's own PPtrs: same-source locals -> embedded
            // ids; cross-file refs -> embedded ids when available, else keep
            // external (builtins always keep external).
            let tt_owned = ty
                .typetree
                .as_ref()
                .map(|flat| typetree_generator_api::reconstruct_typetree_node(flat));
            let tt_fallback;
            let tt: Option<&TypeTreeNode> = match &tt_owned {
                Some(t) => Some(t),
                None => {
                    match TypeTreeProvider::get_typetree_node(&env.tpk, ClassId(ty.class_id), unity_version)
                    {
                        Some(cow) => {
                            tt_fallback = cow.into_owned();
                            Some(&tt_fallback)
                        }
                        None => None,
                    }
                }
            };
            if let Some(tt) = tt {
                let endianess = if src.big_endian {
                    serializedfile::Endianness::Big
                } else {
                    serializedfile::Endianness::Little
                };
                let mut resolve = |fid_raw: i32, pid_raw: i64| -> (i32, i64) {
                    if fid_raw == 0 {
                        return match embedded_ids.get(&(rec.src, pid_raw)) {
                            Some(n) => (0, *n),
                            // local ref to an object we did not embed -> null it
                            None => (0, 0),
                        };
                    }
                    if fid_raw < 0 {
                        return (fid_raw, pid_raw);
                    }
                    match src.externals.get((fid_raw - 1) as usize) {
                        None => (fid_raw, pid_raw),
                        Some(nm) => {
                            if !embed_deps::is_builtin_external(nm) {
                                if let Some(nid) = localizer(nm, pid_raw) {
                                    return (0, nid);
                                }
                            }
                            let fid = builder.get_or_insert_external(nm).value();
                            (fid, pid_raw)
                        }
                    }
                };
                if let Err(e) = rabex_env::trace_pptr::replace_pptrs_resolver_endianed(
                    &mut bytes,
                    tt,
                    endianess,
                    &mut resolve,
                ) {
                    warn!(
                        "LSCR embed-deps: PPtr rewrite failed for {}:{} ({e}); embedding unrewritten",
                        src.name, rec.path_id
                    );
                }
            } else {
                warn!(
                    "LSCR embed-deps: no typetree for embedded class {} ({}:{}); embedding unrewritten",
                    ty.class_id, src.name, rec.path_id
                );
            }

            let info = serializedfile::ObjectInfo {
                m_PathID: new_id,
                m_Offset: 0,
                m_Size: 0,
                m_TypeID: embedded_type_ids.get(rec.ty as usize).copied().unwrap_or(0),
                m_ClassID: ClassId(ty.class_id),
                m_IsDestroyed: None,
                m_ScriptTypeIndex: None,
                m_Stripped: None,
            };
            builder.objects.insert(new_id, (info, Cow::Owned(bytes)));
            embedded_count += 1;
        }
        stats.objects_after += embedded_count;
        log::info!("LSCR embed-deps: {embedded_count} objects embedded into the bundle");
    }

    builder.add_object_at(1, &asset_bundle)?;

    // v12: stream the merged serialized file through disk instead of RAM —
    // with dependencies embedded the output can reach hundreds of MB and a
    // 1 GB Android device cannot hold two in-memory copies of it.
    let ser_tmp = cache_dir.join("merged_serialized.tmp");
    {
        let mut f = std::fs::File::create(&ser_tmp).context("creating merged_serialized.tmp")?;
        builder.write(&mut f)?;
        f.sync_all().ok();
    }
    stats.size_after += std::fs::metadata(&ser_tmp).map(|m| m.len() as usize).unwrap_or(0);

    let mut bundle_builder = BundleFileBuilder::unityfs(7, unity_version);
    {
        let f = std::fs::File::open(&ser_tmp).context("reopening merged_serialized.tmp")?;
        bundle_builder.add_file(&format!("CAB-{bundle_name}"), f)?;
    }
    bundle_builder.write(writer, compression)?;
    std::fs::remove_file(&ser_tmp).ok();

    let mut manifest = manifest;
    manifest.stats = Some(batched_cache::ManifestStats {
        objects_before: stats.objects_before,
        objects_after: stats.objects_after,
        size_before: stats.size_before,
        size_after: stats.size_after,
    });
    manifest.save(cache_dir)?;

    Ok(stats)
}

/// v12: best-effort removal of phase-1 intermediates after the final bundle
/// is safely on disk. Called by the bindings layer *after* the atomic rename
/// of `final.unity3d`, so a crash mid-cleanup can never lose the cache.
pub fn cleanup_intermediates(cache_dir: &Path) {
    if let Ok(Some(manifest)) = batched_cache::Manifest::load(cache_dir) {
        for (_, e) in manifest.scenes.iter() {
            std::fs::remove_file(batched_cache::scene_serialized_path(cache_dir, e.idx)).ok();
            std::fs::remove_file(batched_cache::scene_meta_path(cache_dir, e.idx)).ok();
        }
    }
    std::fs::remove_file(batched_cache::embedded_bin_path(cache_dir)).ok();
    std::fs::remove_file(batched_cache::embedded_index_path(cache_dir)).ok();
    std::fs::remove_file(cache_dir.join("merged_serialized.tmp")).ok();
}
