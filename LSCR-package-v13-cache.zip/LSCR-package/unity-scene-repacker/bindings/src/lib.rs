#![allow(clippy::missing_safety_doc)]
use std::collections::hash_map::DefaultHasher;
use std::ffi::{CStr, CString, c_char, c_int, c_void};
use std::hash::{Hash, Hasher};
use std::io::Cursor;
use std::path::{Path, PathBuf};
use std::sync::Mutex;

use anyhow::{Context as _, Result, bail};
use indexmap::IndexMap;
use rabex::objects::ClassId;
use rabex::typetree::TypeTreeProvider as _;
use rabex_env::Environment;
use rabex_env::resolver::GameFiles;
use rabex_env::typetree_generator_cache::TypeTreeGeneratorCache;
use unity_scene_repacker::rabex::files::bundlefile::CompressionType;
use unity_scene_repacker::rabex::tpk::TpkTypeTreeBlob;
use unity_scene_repacker::rabex::typetree::typetree_cache::sync::TypeTreeCache;
use unity_scene_repacker::{
    MonobehaviourTypetreeMode, RepackSettings, Stats, monobehaviour_typetree_export,
};

/// v13 (64-bit cache line): on-disk bundle cache directory, set by the
/// companion C# mod via `set_cache_dir` before the API's preload phase runs.
/// When set, `export(mode=1)` serves repeat launches from
/// `<cache>/bundle-<key>.unity3d` instead of re-walking every scene.
static CACHE_DIR: Mutex<Option<PathBuf>> = Mutex::new(None);

/// Bump whenever the on-disk cache format or repack output changes, so stale
/// entries from older builds are never served.
const CACHE_FORMAT_TAG: &str = "lscr-cache-v13a";

#[unsafe(no_mangle)]
pub unsafe extern "C" fn set_cache_dir(dir: *const c_char) -> c_int {
    if dir.is_null() {
        return -1;
    }
    let path = match unsafe { CStr::from_ptr(dir) }.to_str() {
        Ok(s) => PathBuf::from(s),
        Err(_) => return -2,
    };
    if let Err(e) = std::fs::create_dir_all(&path) {
        eprintln!(
            "[LSCR] set_cache_dir: cannot create {}: {e}",
            path.display()
        );
        return -3;
    }
    *CACHE_DIR.lock().expect("cache dir lock") = Some(path);
    0
}

fn cache_fingerprint(name: &str, mode: u8, preload_json: &[u8], game_dir: &Path) -> u64 {
    let mut h = DefaultHasher::new();
    CACHE_FORMAT_TAG.hash(&mut h);
    name.hash(&mut h);
    mode.hash(&mut h);
    preload_json.hash(&mut h);
    // Game-data identity: APK/file size + mtime changes on every game update
    // or repack, which must invalidate the cache.
    let mut identified = false;
    for cand in [game_dir.to_path_buf(), game_dir.join("data.unity3d")] {
        if let Ok(md) = std::fs::metadata(&cand) {
            md.len().hash(&mut h);
            if let Ok(t) = md.modified() {
                if let Ok(d) = t.duration_since(std::time::UNIX_EPOCH) {
                    d.as_secs().hash(&mut h);
                }
            }
            identified = true;
        }
    }
    if !identified {
        game_dir.to_string_lossy().hash(&mut h);
    }
    h.finish()
}

#[repr(C)]
pub struct CStats {
    pub objects_before: c_int,
    pub objects_after: c_int,
}

enum Mode {
    SceneBundle = 0,
    AssetBundle = 1,
    AssetBundleShallow = 2,
}
impl Mode {
    fn needs_typetree_generator(&self) -> bool {
        matches!(self, Mode::AssetBundle)
    }
}

#[unsafe(no_mangle)]
pub unsafe extern "C" fn export(
    name: *const c_char,
    game_dir: *const c_char,
    preload_json: *const c_char,
    error: *mut *const c_char,
    bundle_size: *mut c_int,
    bundle_data: *mut *mut u8,
    stats_ret: *mut CStats,
    mb_typetree_export: *const u8,
    mb_typetree_len: c_int,
    mode: u8,
) {
    unsafe {
        let name = CStr::from_ptr(name);
        let game_dir = CStr::from_ptr(game_dir);
        let preload_json = CStr::from_ptr(preload_json);

        let mb_typetree_export = (!mb_typetree_export.is_null())
            .then(|| std::slice::from_raw_parts(mb_typetree_export, mb_typetree_len as usize));

        // v13: with a cache dir configured (companion C# mod on 64-bit), the
        // AssetBundle path is served from / persisted to disk. Never returns
        // null on failure of the cached pipeline — falls back to the one-shot
        // in-memory repack — because the API's asset-bundle preload falls
        // back to DoPreloadScenes on a null bundle, which our companion mod
        // redirects here; returning null could ping-pong the two.
        let cache = CACHE_DIR.lock().expect("cache dir lock").clone();
        let result = match (&cache, mode) {
            (Some(dir), 1) => export_cached(name, game_dir, preload_json, mode, mb_typetree_export, dir)
                .or_else(|e| {
                    eprintln!("[LSCR] cached repack failed: {e:#}; falling back to one-shot export");
                    export_inner(name, game_dir, preload_json, mode, mb_typetree_export)
                }),
            _ => export_inner(name, game_dir, preload_json, mode, mb_typetree_export),
        };
        match result {
            Ok((stats, data)) => {
                if data.len() > i32::MAX as usize {
                    let error_string = CString::new("bundle exceeds 2 GiB; cannot pass through export").unwrap();
                    *error = CString::into_raw(error_string);
                    *bundle_size = 0;
                    *bundle_data = std::ptr::null_mut();
                    return;
                }
                *bundle_size = data.len() as c_int;
                *bundle_data = Box::into_raw(data.into_boxed_slice()).cast();
                *stats_ret = CStats {
                    objects_before: stats.objects_before as c_int,
                    objects_after: stats.objects_after as c_int,
                }
            }
            Err(e) => {
                let error_string = CString::new(e.to_string()).unwrap_or_else(|_| c"".to_owned());
                *error = CString::into_raw(error_string);
                *bundle_size = 0;
                *bundle_data = std::ptr::null_mut();
            }
        }
    }
}

#[unsafe(no_mangle)]
pub unsafe extern "C" fn free_str(cstr: *mut c_char) {
    unsafe { drop(CString::from_raw(cstr)) };
}

/// Batched variant of `export` (LSCR Layer 1).
///
/// Processes scenes sequentially, spilling trimmed intermediates to
/// `cache_dir`, and supports resuming after interruption via `resume`.
/// Currently only `mode = 1` (AssetBundle) is supported. On success the final
/// bundle is persisted to `cache_dir/final.unity3d` (streamed through disk —
/// v12: with dependencies embedded it can be hundreds of MB), `bundle_size`
/// receives the file size (capped at i32::MAX) and `bundle_data` stays null;
/// the C# side loads the bundle from disk.
#[unsafe(no_mangle)]
pub unsafe extern "C" fn export_batched(
    name: *const c_char,
    game_dir: *const c_char,
    preload_json: *const c_char,
    cache_dir: *const c_char,
    resume: u8,
    error: *mut *const c_char,
    bundle_size: *mut c_int,
    bundle_data: *mut *mut u8,
    stats_ret: *mut CStats,
    mb_typetree_export: *const u8,
    mb_typetree_len: c_int,
    mode: u8,
) {
    unsafe {
        let name = CStr::from_ptr(name);
        let game_dir = CStr::from_ptr(game_dir);
        let preload_json = CStr::from_ptr(preload_json);
        let cache_dir = CStr::from_ptr(cache_dir);

        let mb_typetree_export = (!mb_typetree_export.is_null())
            .then(|| std::slice::from_raw_parts(mb_typetree_export, mb_typetree_len as usize));

        let result = export_batched_inner(
            name,
            game_dir,
            preload_json,
            cache_dir,
            resume != 0,
            mode,
            mb_typetree_export,
        );
        match result {
            Ok((stats, size)) => {
                // v12: the bundle can be hundreds of MB once dependencies are
                // embedded; handing that back through malloc would OOM a 1 GB
                // device. It is streamed to <cache_dir>/final.unity3d instead
                // and the C# side loads it from disk. bundle_data stays null.
                *bundle_size = if size > i32::MAX as u64 { i32::MAX } else { size as c_int };
                *bundle_data = std::ptr::null_mut();
                *stats_ret = CStats {
                    objects_before: stats.objects_before as c_int,
                    objects_after: stats.objects_after as c_int,
                }
            }
            Err(e) => {
                let error_string = CString::new(e.to_string()).unwrap_or_else(|_| c"".to_owned());
                *error = CString::into_raw(error_string);
                *bundle_size = 0;
                *bundle_data = std::ptr::null_mut();
            }
        }
    }
}

#[unsafe(no_mangle)]
pub extern "C" fn free_array(len: c_int, data: *mut u8) {
    unsafe {
        let data = std::ptr::slice_from_raw_parts_mut(data, len as usize);
        drop(Box::from_raw(data))
    };
}

fn make_environment(
    game_dir: &Path,
    needs_typetree_generator: bool,
    mb_typetree_export: Option<&[u8]>,
) -> Result<Environment> {
    let tpk = TypeTreeCache::new(TpkTypeTreeBlob::embedded());
    let game_files = GameFiles::probe(game_dir)?;
    let mut env = Environment::new(game_files, tpk);

    if needs_typetree_generator {
        let unity_version = env.unity_version()?.clone();
        let monobehaviour_typetree_mode = match mb_typetree_export {
            Some(data) => MonobehaviourTypetreeMode::Export(data),
            None => MonobehaviourTypetreeMode::GenerateRuntime,
        };

        let monobehaviour_node = env
            .tpk
            .get_typetree_node(ClassId::MonoBehaviour, &unity_version)
            .unwrap()
            .into_owned();

        env.typetree_generator = match monobehaviour_typetree_mode {
            MonobehaviourTypetreeMode::GenerateRuntime => {
                TypeTreeGeneratorCache::new(unity_version, monobehaviour_node)
            }
            MonobehaviourTypetreeMode::Export(export) => {
                TypeTreeGeneratorCache::prefilled(monobehaviour_typetree_export::read(export)?)
            }
        };
    }

    Ok(env)
}

fn export_inner(
    name: &CStr,
    game_dir: &CStr,
    scene_objects_json: &CStr,
    mode: u8,
    mb_typetree_export: Option<&[u8]>,
) -> Result<(Stats, Vec<u8>)> {
    let name = name.to_str()?;
    let game_dir = Path::new(game_dir.to_str()?);
    let scene_objects = scene_objects_json.to_str()?;
    let mode = match mode {
        0 => Mode::SceneBundle,
        1 => Mode::AssetBundle,
        2 => Mode::AssetBundleShallow,
        _ => bail!("Expected 0=SceneBundle, 1=AssetBundle or 2=AssetBundleShallow, got {mode}"),
    };

    let tpk_raw = TpkTypeTreeBlob::embedded();

    let compression = CompressionType::None;

    let scene_objects: IndexMap<String, Vec<String>> =
        serde_json::from_str(scene_objects).context("error parsing the objects json")?;

    let repack_settings = RepackSettings {
        scene_objects,
        extra_objects: IndexMap::new(),
    };

    let disable = true;

    let mut out = Cursor::new(Vec::new());

    let env = make_environment(game_dir, mode.needs_typetree_generator(), mb_typetree_export)?;
    let unity_version = env.unity_version()?.clone();

    if let Mode::AssetBundleShallow = mode {
        let stats = unity_scene_repacker::pack_to_shallow_asset_bundle(
            &env,
            &mut out,
            name,
            repack_settings,
            compression,
        )?;
        return Ok((stats, out.into_inner()));
    }

    let (mut repack_scenes, extra_objects) = unity_scene_repacker::repack_scenes(
        &env,
        repack_settings,
        disable,
        matches!(mode, Mode::AssetBundle),
    )?;

    let enable_typetree = false; // TODO: make this configurable / infer if necessary

    let stats = match mode {
        Mode::SceneBundle => unity_scene_repacker::pack_to_scene_bundle(
            &mut out,
            name,
            &tpk_raw,
            &env.tpk,
            &unity_version,
            repack_scenes.as_mut_slice(),
            compression,
        )
        .context("trying to repack bundle")?,
        Mode::AssetBundle => unity_scene_repacker::pack_to_asset_bundle(
            &env,
            &mut out,
            name,
            &tpk_raw,
            repack_scenes,
            extra_objects,
            compression,
            enable_typetree,
        )?,
        Mode::AssetBundleShallow => unreachable!(),
    };

    Ok((stats, out.into_inner()))
}

fn export_batched_inner(
    name: &CStr,
    game_dir: &CStr,
    scene_objects_json: &CStr,
    cache_dir: &CStr,
    resume: bool,
    mode: u8,
    mb_typetree_export: Option<&[u8]>,
) -> Result<(Stats, u64)> {
    eprintln!("[LSCR] export_batched: v17 embed-deps build (cross-file dependencies are embedded into the bundle; final.unity3d is streamed to cache_dir)");
    let name = name.to_str()?;
    let game_dir = Path::new(game_dir.to_str()?);
    let cache_dir = Path::new(cache_dir.to_str()?);
    let scene_objects = scene_objects_json.to_str()?;
    match mode {
        1 => {}
        m => bail!("export_batched currently only supports mode=1 (AssetBundle), got {m}"),
    }

    let tpk_raw = TpkTypeTreeBlob::embedded();

    let scene_objects: IndexMap<String, Vec<String>> =
        serde_json::from_str(scene_objects).context("error parsing the objects json")?;

    let repack_settings = RepackSettings {
        scene_objects,
        extra_objects: IndexMap::new(),
    };

    let env = make_environment(game_dir, true, mb_typetree_export)?;

    // Phase 1: sequential per-scene repack with disk spill + manifest.
    // prepare_scripts=true, disable_roots=true — same as the one-shot
    // AssetBundle path in `export_inner`.
    unity_scene_repacker::repack_scenes_batched(
        &env,
        repack_settings,
        true,
        true,
        &tpk_raw,
        cache_dir,
        name,
        resume,
    )?;

    // Phase 2: merge intermediates into the final AssetBundle, streamed to
    // disk (v12: with dependencies embedded this can be hundreds of MB).
    let compression = CompressionType::None;
    let enable_typetree = false;
    let final_path =
        cache_dir.join(unity_scene_repacker::batched_cache::FINAL_BUNDLE_FILE);
    let tmp_path = final_path.with_extension("unity3d.tmp");
    let mut out = std::fs::File::create(&tmp_path)
        .with_context(|| format!("creating {}", tmp_path.display()))?;
    let stats = unity_scene_repacker::pack_to_asset_bundle_from_cache(
        &env,
        &mut out,
        name,
        &tpk_raw,
        cache_dir,
        compression,
        enable_typetree,
    )?;
    out.sync_all().ok();
    drop(out);
    let size = std::fs::metadata(&tmp_path)
        .with_context(|| format!("stat {}", tmp_path.display()))?
        .len();
    std::fs::rename(&tmp_path, &final_path)
        .with_context(|| format!("renaming {} into place", tmp_path.display()))?;

    // Surface the missing-path report (if any) to stderr for adb logcat.
    let missing_report_path = cache_dir.join("missing_paths.json");
    if missing_report_path.exists() {
        eprintln!(
            "[LSCR] warning: some requested object paths were not found; see {}",
            missing_report_path.display()
        );
    }

    // v12: the final bundle is safely on disk — free the phone's storage by
    // dropping the phase-1 intermediates (trimmed scenes + embedded deps).
    unity_scene_repacker::cleanup_intermediates(cache_dir);

    Ok((stats, size))
}

/// v13: cached AssetBundle repack for the 64-bit companion mod.
/// Miss runs the resumable batched pipeline into `<cache>/work-<key>/`,
/// publishes the final bundle atomically as `<cache>/bundle-<key>.unity3d`
/// (+ 8-byte stats sidecar), drops the work dir, and returns the bundle
/// bytes in memory (the API loads them via LoadFromMemoryAsync).
fn export_cached(
    name: &CStr,
    game_dir: &CStr,
    preload_json: &CStr,
    mode: u8,
    mb_typetree_export: Option<&[u8]>,
    cache: &Path,
) -> Result<(Stats, Vec<u8>)> {
    let key = cache_fingerprint(
        name.to_str()?,
        mode,
        preload_json.to_bytes(),
        Path::new(game_dir.to_str()?),
    );
    let bundle_path = cache.join(format!("bundle-{key:016x}.unity3d"));
    let stats_path = cache.join(format!("bundle-{key:016x}.stats"));
    let work_dir = cache.join(format!("work-{key:016x}"));

    if bundle_path.exists() && stats_path.exists() {
        let data = std::fs::read(&bundle_path)
            .with_context(|| format!("reading cached bundle {}", bundle_path.display()))?;
        let sb = std::fs::read(&stats_path)?;
        if sb.len() == 8 && !data.is_empty() {
            let stats = Stats {
                objects_before: i32::from_le_bytes([sb[0], sb[1], sb[2], sb[3]]) as usize,
                objects_after: i32::from_le_bytes([sb[4], sb[5], sb[6], sb[7]]) as usize,
                size_before: 0,
                size_after: data.len(),
            };
            eprintln!(
                "[LSCR] cache HIT bundle-{key:016x}.unity3d ({} MiB)",
                data.len() / (1024 * 1024)
            );
            return Ok((stats, data));
        }
        eprintln!("[LSCR] cache entry corrupt, rebuilding");
    }

    eprintln!("[LSCR] cache MISS, batched repack into {}", work_dir.display());
    std::fs::create_dir_all(&work_dir)?;
    let work_c = CString::new(
        work_dir
            .to_str()
            .context("work dir path is not valid UTF-8")?
            .to_owned(),
    )?;
    let (stats, _size) = export_batched_inner(
        name,
        game_dir,
        preload_json,
        &work_c,
        true, // resume: a crashed first run continues where the manifest left off
        mode,
        mb_typetree_export,
    )
    .with_context(|| format!("batched repack into {}", work_dir.display()))?;

    let final_path = work_dir.join(unity_scene_repacker::batched_cache::FINAL_BUNDLE_FILE);
    let data = std::fs::read(&final_path).context("reading freshly built final.unity3d")?;

    let tmp = bundle_path.with_extension("unity3d.tmp");
    std::fs::write(&tmp, &data).context("writing cached bundle")?;
    std::fs::rename(&tmp, &bundle_path).context("publishing cached bundle")?;
    std::fs::write(
        &stats_path,
        [
            (stats.objects_before as i32).to_le_bytes(),
            (stats.objects_after as i32).to_le_bytes(),
        ]
        .concat(),
    )
    .ok();
    let _ = std::fs::remove_dir_all(&work_dir);
    eprintln!(
        "[LSCR] cache STORED bundle-{key:016x}.unity3d ({} MiB)",
        data.len() / (1024 * 1024)
    );
    Ok((stats, data))
}

#[cfg(target_os = "android")]
unsafe extern "C" {
    fn mprotect(addr: *mut u8, len: usize, prot: c_int) -> c_int;
}

/// v13.1: instruction-cache flush after self-modifying a code page.
///
/// Android's bionic does NOT export `__clear_cache` (it is a compiler-rt
/// builtin that JITs inline), so referencing it leaves an undefined dynamic
/// symbol and the linker refuses to load the .so at install time
/// (observed as DllNotFoundException on device). Do what the system's own
/// JIT does: read the icache line size from CTR_EL0 and issue IC IVAU per
/// line, then DSB ISH + ISB.
#[cfg(target_arch = "aarch64")]
unsafe fn flush_icache(start: usize, end: usize) {
    let ctr: u64;
    core::arch::asm!("mrs {}, ctr_el0", out(reg) ctr, options(nostack, preserves_flags));
    let line = 1usize << ((ctr >> 16) & 0xF);
    let mut p = start & !(line - 1);
    while p < end {
        core::arch::asm!("ic ivau, {}", in(reg) p, options(nostack, preserves_flags));
        p += line;
    }
    core::arch::asm!("dsb ish", options(nostack, preserves_flags));
    core::arch::asm!("isb", options(nostack, preserves_flags));
}

// ---- v13.2: JNI self-setup ----------------------------------------------
//
// HybridCLR refuses P/Invoke from interpreted (hot-update) assemblies
// ("NotSupportManaged2NativeFunctionMethod"), so the C# companion mod cannot
// call set_cache_dir / install_scene_redirect directly. Instead it resolves
// the two native method addresses itself (reflection + the API's resolver,
// both proven to work from interpreted code), writes them plus the cache
// dir into <persistentDataPath>/RepackBridge64/bridge.cfg, and then loads
// this library via java.lang.Runtime.loadLibrary. That triggers JNI_OnLoad,
// which reads the config, self-configures, and writes a receipt file the
// C# side logs. Zero P/Invoke involved.

/// Package name of the hosting app, from /proc/self/cmdline.
#[cfg(all(target_os = "android", target_arch = "aarch64"))]
fn android_pkg_name() -> Option<String> {
    let raw = std::fs::read("/proc/self/cmdline").ok()?;
    let end = raw.iter().position(|&b| b == 0).unwrap_or(raw.len());
    let s = String::from_utf8_lossy(&raw[..end]).trim().to_string();
    if s.is_empty() {
        None
    } else {
        Some(s)
    }
}

#[cfg(all(target_os = "android", target_arch = "aarch64"))]
fn bridge_cfg_path() -> Option<PathBuf> {
    let pkg = android_pkg_name()?;
    let ext = std::env::var("EXTERNAL_STORAGE")
        .unwrap_or_else(|_| "/storage/emulated/0".to_string());
    Some(
        Path::new(&ext)
            .join("Android/data")
            .join(pkg)
            .join("files/RepackBridge64/bridge.cfg"),
    )
}

#[cfg(all(target_os = "android", target_arch = "aarch64"))]
fn jni_self_setup() -> String {
    let mut report = String::new();
    let Some(cfg_path) = bridge_cfg_path() else {
        return "cfg path unresolved (cmdline/env)".to_string();
    };
    let Ok(content) = std::fs::read_to_string(&cfg_path) else {
        return format!("cfg unreadable: {}", cfg_path.display());
    };
    let mut cache: Option<String> = None;
    let mut from: Option<usize> = None;
    let mut to: Option<usize> = None;
    for line in content.lines() {
        let (k, v) = match line.split_once('=') {
            Some(kv) => kv,
            None => continue,
        };
        match k {
            "cache_dir" => cache = Some(v.to_string()),
            "from" | "to" => {
                let n = usize::from_str_radix(v.trim().trim_start_matches("0x"), 16).ok();
                if k == "from" {
                    from = n;
                } else {
                    to = n;
                }
            }
            _ => {}
        }
    }
    match cache {
        Some(dir) => {
            let p = PathBuf::from(&dir);
            match std::fs::create_dir_all(&p) {
                Ok(_) => {
                    *CACHE_DIR.lock().expect("cache dir lock") = Some(p);
                    report.push_str("cache_dir=ok; ");
                }
                Err(e) => report.push_str(&format!("cache_dir=err({e}); ")),
            }
        }
        None => report.push_str("cache_dir=missing; "),
    }
    match (from, to) {
        (Some(f), Some(t)) => {
            let r = unsafe { install_scene_redirect(f as *mut u8, t as *const u8) };
            report.push_str(&format!("redirect={r}"));
        }
        _ => report.push_str("redirect=missing-addrs"),
    }
    report
}

#[cfg(all(target_os = "android", target_arch = "aarch64"))]
#[unsafe(no_mangle)]
pub extern "C" fn JNI_OnLoad(_vm: *mut c_void, _reserved: *mut c_void) -> c_int {
    let report = jni_self_setup();
    if let Some(cfg_path) = bridge_cfg_path() {
        let _ = std::fs::write(
            cfg_path.with_file_name("bridge_status.txt"),
            format!("{report}\n"),
        );
    }
    0x00010006 // JNI_VERSION_1_6
}

/// v13 companion-mod support: rewrites the first 16 bytes of `from`
/// (native entry of `Modding.Preloader.DoPreloadScenes`) into an
/// unconditional jump to `to` (`DoPreloadAssetBundle`). Both are il2cpp
/// iterator-allocator methods with identical (this, dict, dict, dict) ->
/// IEnumerator* signatures, so a bare entry jump forwards all arguments.
///
/// Patch: `LDR X16, #8 ; BR X16 ; <to as u64 le>`.
/// Returns 0 on success, negative codes on failure (-100 = not arm64).
#[unsafe(no_mangle)]
pub unsafe extern "C" fn install_scene_redirect(from: *mut u8, to: *const u8) -> c_int {
    #[cfg(all(target_os = "android", target_arch = "aarch64"))]
    unsafe {
        if from.is_null() || to.is_null() {
            return -1;
        }
        if (from as usize) % 4 != 0 || (to as usize) % 4 != 0 {
            return -2;
        }
        let page = 4096usize;
        let start = (from as usize) & !(page - 1);
        let end = ((from as usize) + 16 + page - 1) & !(page - 1);
        if mprotect(start as *mut u8, end - start, 7) != 0 {
            return -3;
        }
        let words: [u32; 4] = [
            0x58000050, // LDR X16, #8
            0xD61F0200, // BR X16
            to as u64 as u32,
            (to as u64 >> 32) as u32,
        ];
        std::ptr::copy_nonoverlapping(words.as_ptr().cast::<u8>(), from, 16);
        flush_icache(from as usize, from as usize + 16);
        mprotect(start as *mut u8, end - start, 5);
        0
    }
    #[cfg(not(all(target_os = "android", target_arch = "aarch64")))]
    {
        let _ = (from, to);
        -100
    }
}
