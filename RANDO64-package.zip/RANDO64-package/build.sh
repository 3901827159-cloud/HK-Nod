#!/bin/bash
# ============================================================================
# RANDO64 云端链式编译脚本（Randomizer 4 家族五工程 → 安卓 64 位移植版）
# ----------------------------------------------------------------------------
# 编译顺序（依赖链）：
#   RandomizerCore → RandomizerCore.Json → ItemChanger → MenuChanger → RandomizerMod
# 关键点：
#   1. 裸 dotnet-csc 不跑 NuGet 源生成器 → PolySharp 垫片改由 polyfill/Polyfills.cs
#      手工提供，编进每个程序集（internal，规避 CS0433）。
#   2. ImplicitUsings → 每个工程一份 usings/<x>.usings.cs（global using，忠实复刻
#      csproj 的 Using Include/Remove/Alias）。
#   3. EmbeddedResource → 按 MSBuild 默认命名 {RootNamespace}.{相对路径分隔符转点}
#      逐个 /res: 挂入（IC=ItemChanger、RM=RandomizerMod）。资源名与源码里
#      GetManifestResourceStream("ItemChanger.Resources.…") 的期望严格对齐。
#   4. 不定义任何符号：源码里 NETSTANDARD2_0 / NET8_0_OR_GREATER / DEBUG 在
#      net472-release 下均应为假，走 #else 正确分支。
#   5. 版本号显式设定（csproj VersionPrefix），使 RM 菜单显示 4.1.6+xxx 而非 0.0.0。
#   6. 每个工程都引用全部 refs/*.dll（与 ER64 一致）→ IsExternalInit(public,
#      Assembly-CSharp) / Index·Range·HashCode(public, mscorlib) 对五工程均可见。
# ============================================================================
set -e
cd "$(dirname "$0")"
mkdir -p out

# 选【最新】的 csc（按 SDK 版本排序取尾），而非 head -1。
# 原因：RandomizerCore 用 C#11 required 成员 + C#10 global using；若 runner 上
# 同时装了旧 SDK（如 .NET 6 = C#10），head -1 可能抓到旧编译器 → required 语法报错、
# RandomizerCore.dll 编不出（ER64 不用 required/global using 故从未暴露此坑）。
echo "available csc candidates (version-sorted):"
find /usr/share/dotnet /usr/lib/dotnet "$HOME/.dotnet" -name csc.dll -path '*bincore*' 2>/dev/null \
  | awk -F/ '{v="0"; for(i=1;i<NF;i++) if($i=="sdk") v=$(i+1); print v"\t"$0}' \
  | sort -t"$(printf '\t')" -k1,1V | tee /tmp/csc_candidates.txt
CSC=$(tail -1 /tmp/csc_candidates.txt | cut -f2-)
if [ -z "$CSC" ]; then echo "FATAL: csc.dll not found"; exit 1; fi
echo "using compiler (newest): $CSC"

# refs 解析：本包不自带 refs（40MB，与 ER64 包字节相同）。优先用本地 refs/，
# 否则回退到同级 ER64-package/refs（云端流水线会先解出 ER64 包提供 refs）。
REFS=refs
if [ ! -d "$REFS" ] || [ -z "$(ls -A $REFS/*.dll 2>/dev/null)" ]; then
  if [ -d ../ER64-package/refs ]; then REFS=../ER64-package/refs;
  elif [ -d ER64-package/refs ]; then REFS=ER64-package/refs; fi
fi
if [ -z "$(ls -A $REFS/*.dll 2>/dev/null)" ]; then
  echo "FATAL: 找不到 refs/*.dll（本包不含 refs，需同级存在 ER64-package/refs）"; exit 1
fi
echo "using refs: $REFS ($(ls $REFS/*.dll | wc -l) dll)"

R=$(ls $REFS/*.dll | sed 's|^|/r:|' | tr '\n' ' ')
NULL=-nullable:annotations
NOWARN=-nowarn:1701,1702,1591,IDE0018
POLY=polyfill/Polyfills.cs

# ---- 生成源码响应文件（逐行加引号，容忍空格）----
mk_srcs(){ # $1=输出rsp $2=工程目录 $3=usings垫片
  : > "$1"
  find "$2" -name '*.cs' -not -path '*/obj/*' -not -path '*/bin/*' | sort | sed 's/.*/"&"/' >> "$1"
  echo "\"$POLY\"" >> "$1"
  echo "\"$3\"" >> "$1"
}

# ---- 生成嵌入资源响应文件（/res:"文件","manifest名"）----
mk_res(){ # $1=输出rsp $2=工程目录 $3=RootNamespace
  : > "$1"
  [ -d "$2/Resources" ] || return 0
  find "$2/Resources" -type f \( -name '*.png' -o -name '*.json' -o -name '*.xml' -o -name '*.wav' -o -name '*.txt' \) | sort | while read -r f; do
    rel="${f#$2/}"                 # Resources/xxx/yyy.ext
    man="$3.${rel//\//.}"          # NS.Resources.xxx.yyy.ext
    printf '/res:"%s","%s"\n' "$f" "$man" >> "$1"
  done
}

echo "=== [1/5] RandomizerCore ==="
mk_srcs rc.srcs   src/RandomizerCore      usings/rc.usings.cs
dotnet "$CSC" -nologo -noconfig -target:library -optimize+ -langversion:latest $NULL $NOWARN \
  -version:2.1.2.0 -out:out/RandomizerCore.dll $R @rc.srcs

echo "=== [2/5] RandomizerCore.Json ==="
mk_srcs rcj.srcs  src/RandomizerCore.Json usings/rcj.usings.cs
dotnet "$CSC" -nologo -noconfig -target:library -optimize+ -langversion:latest $NULL $NOWARN \
  -version:1.1.1.0 -out:out/RandomizerCore.Json.dll $R /r:out/RandomizerCore.dll @rcj.srcs

echo "=== [3/5] ItemChanger ==="
mk_srcs ic.srcs   src/ItemChanger         usings/ic.usings.cs
mk_res  ic.res    src/ItemChanger         ItemChanger
echo "    嵌入资源: $(grep -c '^/res' ic.res) 个"
dotnet "$CSC" -nologo -noconfig -target:library -optimize+ -langversion:latest $NULL $NOWARN \
  -version:2.1.6.0 -out:out/ItemChanger.dll $R \
  /r:out/RandomizerCore.dll /r:out/RandomizerCore.Json.dll @ic.res @ic.srcs

echo "=== [4/5] MenuChanger ==="
mk_srcs mc.srcs   src/MenuChanger         usings/mc.usings.cs
dotnet "$CSC" -nologo -noconfig -target:library -optimize+ -langversion:latest $NULL $NOWARN \
  -version:1.1.0.0 -out:out/MenuChanger.dll $R @mc.srcs

echo "=== [5/5] RandomizerMod ==="
mk_srcs rm.srcs   src/RandomizerMod       usings/rm.usings.cs
mk_res  rm.res    src/RandomizerMod       RandomizerMod
echo "    嵌入资源: $(grep -c '^/res' rm.res) 个"
dotnet "$CSC" -nologo -noconfig -target:library -optimize+ -langversion:preview $NULL $NOWARN \
  -version:4.1.6.0 -out:out/RandomizerMod.dll $R \
  /r:out/RandomizerCore.dll /r:out/RandomizerCore.Json.dll /r:out/ItemChanger.dll /r:out/MenuChanger.dll \
  @rm.res @rm.srcs

echo "=== 产物 ==="
ls -la out/
echo "=== 版本校验 ==="
for d in out/*.dll; do echo -n "$d  "; done; echo
