// ============================================================================
// Polyfills.cs  —  PolySharp 等价垫片（RANDO64 云端裸 csc 编译专用）
// ----------------------------------------------------------------------------
// PC 原版五个工程靠 PolySharp 源生成器为 net472 注入新语法所需的编译器特性
// 类型。裸 dotnet-csc 不跑源生成器，所以这里手工补上——但只补 refs 里"缺"的、
// 且源码"实际用到"的那几个，全部 internal（每个程序集各编一份，互不可见，
// 天然规避 CS0433）。
//
// 已由 refs 提供、【绝不能】在此重复定义的类型（探测实证）：
//   System.Index / System.Range / System.HashCode   → mscorlib.dll (public)
//   System.Runtime.CompilerServices.IsExternalInit  → Assembly-CSharp.dll (public)
//   （云端 build.sh 给每个工程都引用全部 refs/*.dll，故上述对五个工程均可见，
//     init-only / records / 切片语法直接可用。）
//
// 本文件补齐（源码实测用到、refs 中不存在或仅 internal 不可见）：
//   required 成员三件套：RequiredMemberAttribute / SetsRequiredMembersAttribute
//                        / CompilerFeatureRequiredAttribute
//     —— 用于 RandomizerCore(SphereBuilder,Token) 与 ItemChanger(CostDisplayer…)
//   可空性标注：NotNullWhenAttribute / MaybeNullWhenAttribute
//     —— 用于 RandomizerCore(StringLogic 等)；refs 里 Newtonsoft 那份是 internal
//        不可见，必须自补。
// ============================================================================

namespace System.Runtime.CompilerServices
{
    [AttributeUsage(
        AttributeTargets.Class | AttributeTargets.Struct | AttributeTargets.Field |
        AttributeTargets.Property | AttributeTargets.Interface,
        AllowMultiple = false, Inherited = false)]
    internal sealed class RequiredMemberAttribute : Attribute { }

    [AttributeUsage(AttributeTargets.Constructor, AllowMultiple = false, Inherited = false)]
    internal sealed class SetsRequiredMembersAttribute : Attribute { }

    [AttributeUsage(
        AttributeTargets.Class | AttributeTargets.Struct | AttributeTargets.Field |
        AttributeTargets.Property | AttributeTargets.Interface,
        AllowMultiple = true, Inherited = false)]
    internal sealed class CompilerFeatureRequiredAttribute : Attribute
    {
        public const string RequiredMembers = "RequiredMembers";
        public CompilerFeatureRequiredAttribute(string featureName) { FeatureName = featureName; }
        public string FeatureName { get; }
        // 注意：用 { get; set; } 而非 PolySharp 原版的 init，避免对 IsExternalInit
        // 的额外依赖（RC/RC.Json 纯逻辑库场景下更稳）。语义等价，编译器只按名识别。
        public bool IsOptional { get; set; }
    }
}

namespace System.Diagnostics.CodeAnalysis
{
    [AttributeUsage(
        AttributeTargets.Parameter | AttributeTargets.Property |
        AttributeTargets.ReturnValue | AttributeTargets.Field,
        AllowMultiple = true, Inherited = false)]
    internal sealed class NotNullWhenAttribute : Attribute
    {
        public NotNullWhenAttribute(bool returnValue) { ReturnValue = returnValue; }
        public bool ReturnValue { get; }
    }

    [AttributeUsage(
        AttributeTargets.Parameter | AttributeTargets.Property |
        AttributeTargets.ReturnValue | AttributeTargets.Field,
        AllowMultiple = true, Inherited = false)]
    internal sealed class MaybeNullWhenAttribute : Attribute
    {
        public MaybeNullWhenAttribute(bool returnValue) { ReturnValue = returnValue; }
        public bool ReturnValue { get; }
    }
}
