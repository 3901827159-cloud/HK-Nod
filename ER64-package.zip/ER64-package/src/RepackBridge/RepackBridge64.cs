using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using Modding;
using UnityEngine;
using UnityEngine.Networking;

namespace RepackBridge64Mod
{
    /// <summary>
    /// 64-bit preload cache bridge.
    ///
    /// The mobile API forces PreloadMode.FullScene on Android, which walks
    /// every scene at boot (~4 min) and leaves the retained prefabs on a
    /// heap that is already tight on 8 GB devices. The API already contains
    /// the full RepackAssets pipeline (Preloader.DoPreloadAssetBundle ->
    /// UnitySceneRepacker.Repack -> libunityscenerepacker.so); it is simply
    /// never reached on Android.
    ///
    /// This mod, from its constructor (which runs before the preload phase):
    ///   1. tells the v13 repacker .so where to keep its on-disk bundle
    ///      cache (persistentDataPath/PreloadCache), and
    ///   2. redirects the native entry of Preloader.DoPreloadScenes to
    ///      Preloader.DoPreloadAssetBundle (identical signatures), so the
    ///      API takes the asset-bundle path with built-in disk caching.
    ///
    /// PreloadUX (v2), a GameObject created at boot:
    ///   - polls progress.txt and draws a small bar above the loading bar
    ///     (cache builds: scene names; FullScene builds: elapsed timer),
    ///   - plays user music from files/PreloadMusic/*.ogg|mp3|wav during the
    ///     preload window (AudioSource + AudioListener.pause fight, so the
    ///     game's own menu music stays muted while our music plays), and
    ///   - suppresses the game's menu music until Initialize() runs (the
    ///     first menu visit is the "waiting" room; the real menu music must
    ///     only start after the preload completes), via On.AudioManager.
    ///     ApplyMusicCue / BeginApplyMusicCue hooks (no PlayMusic hook exists
    ///     in the 64-bit MMHOOK, but these carry the menu music switch).
    ///
    /// Every step degrades gracefully: if the .so is missing/old, address
    /// resolution fails, or a hook signature mismatches, the game stays on
    /// the stock FullScene path with its stock audio.
    /// </summary>
    public class RepackBridge64 : Mod
    {
        private const string LibName = "unityscenerepacker";

        public RepackBridge64()
        {
            Log("RepackBridge64 v3.9: ctor");
            try
            {
                SetupRedirect();
            }
            catch (Exception e)
            {
                LogError("RepackBridge64 v3.9: redirect setup failed: " + e);
            }
            LogDataLayout();
            PreloadUx.Boot(this);
        }

        // v3.5 layout stethoscope: the repack pipeline's next unknown is the
        // on-device game-data layout. Log the truth (marker files + top
        // entries of each candidate dir) into the mod log the user sends
        // anyway, so a miss costs zero extra round trips.
        private void LogDataLayout()
        {
            try
            {
                string pdp = Application.persistentDataPath;
                string[] roots = { pdp, Path.Combine(pdp, "Data"), Path.Combine(pdp, "data"), Path.Combine(pdp, "ModdingApi.PreloadCache", "apkdata") };
                string[] marks = { "level0", "data.unity3d", "sharedassets0.assets", "resources.assets", "mainData" };
                foreach (string r in roots)
                {
                    if (!Directory.Exists(r))
                    {
                        Log("RepackBridge64 v3.9: layout miss: " + r);
                        continue;
                    }
                    var hit = new List<string>();
                    foreach (string m in marks)
                        if (File.Exists(Path.Combine(r, m))) hit.Add(m);
                    Log("RepackBridge64 v3.9: layout " + r + " marks=[" + string.Join(",", hit.ToArray()) + "]");
                    // v3.6: drill one level so the log answers "does the
                    // extracted data dir actually hold the unity files?"
                    if (r.EndsWith("apkdata"))
                    {
                        foreach (string sub in Directory.GetDirectories(r))
                        {
                            var hit2 = new List<string>();
                            foreach (string m in marks)
                                if (File.Exists(Path.Combine(sub, m)) || File.Exists(Path.Combine(sub, "bin", "Data", m))) hit2.Add(m);
                            Log("RepackBridge64 v3.9: layout " + sub + " marks=[" + string.Join(",", hit2.ToArray()) + "]"
                                + (Directory.Exists(Path.Combine(sub, "bin", "Data")) ? " (nested bin/Data present)" : ""));
                        }
                    }
                    try
                    {
                        string[] entries = Directory.GetFileSystemEntries(r);
                        Array.Sort(entries);
                        var top = new List<string>();
                        for (int i = 0; i < entries.Length && i < 12; i++) top.Add(Path.GetFileName(entries[i]));
                        Log("RepackBridge64 v3.9: layout top: " + string.Join(", ", top.ToArray()));
                    }
                    catch { }
                }
            }
            catch (Exception e)
            {
                Log("RepackBridge64 v3.9: layout probe failed: " + e.Message);
            }
        }

        private void SetupRedirect()
        {
            Assembly api = typeof(ModHooks).Assembly;
            Type preloader = api.GetType("Modding.Preloader");
            if (preloader == null)
            {
                Log("RepackBridge64 v3.9: Modding.Preloader not found - API too old? staying FullScene");
                return;
            }

            const BindingFlags Flags = BindingFlags.NonPublic | BindingFlags.Instance;
            MethodInfo from = preloader.GetMethod("DoPreloadScenes", Flags);
            MethodInfo to = preloader.GetMethod("DoPreloadAssetBundle", Flags);
            if (from == null || to == null)
            {
                Log("RepackBridge64 v3.9: DoPreloadScenes=" + (from != null) + " DoPreloadAssetBundle=" + (to != null) + " - staying FullScene");
                return;
            }

            Type resolver = api.GetType("Modding.Il2CppResolver");
            MethodInfo tryGet = resolver == null
                ? null
                : resolver.GetMethod("TryGetMethodPointer", new[] { typeof(MethodInfo) });
            if (tryGet == null)
            {
                Log("RepackBridge64 v3.9: Il2CppResolver.TryGetMethodPointer not found - staying FullScene");
                return;
            }

            IntPtr a = (IntPtr)tryGet.Invoke(null, new object[] { from });
            IntPtr b = (IntPtr)tryGet.Invoke(null, new object[] { to });

            // v3.1: the 64-bit Assembly-CSharp ships with zero manifest
            // resources, so the API's GetEmbeddedTypetreeDump null-refs and
            // DoPreloadAssetBundle ping-pongs into our redirect forever.
            // Hand its address over too; the .so feeds the dump natively.
            IntPtr dumpAddr = IntPtr.Zero;
            try
            {
                Type repacker = api.GetType("Modding.UnitySceneRepacker");
                MethodInfo getDump = repacker == null
                    ? null
                    : repacker.GetMethod("GetEmbeddedTypetreeDump", BindingFlags.NonPublic | BindingFlags.Static);
                if (getDump != null)
                    dumpAddr = (IntPtr)tryGet.Invoke(null, new object[] { getDump });
            }
            catch (Exception e)
            {
                Log("RepackBridge64 v3.9: dump address resolution failed: " + e.GetType().Name);
            }
            Log("RepackBridge64 v3.9: DoPreloadScenes@" + a + " DoPreloadAssetBundle@" + b + " GetEmbeddedTypetreeDump@" + dumpAddr);
            if (a == IntPtr.Zero || b == IntPtr.Zero)
            {
                Log("RepackBridge64 v3.9: native address resolution failed - staying FullScene");
                return;
            }

            // HybridCLR forbids P/Invoke from interpreted assemblies
            // (NotSupportManaged2NativeFunctionMethod), so hand the addresses
            // to the native side via a config file and let the library's
            // JNI_OnLoad pick them up when Java loads it.
            string cfgDir = Path.Combine(Application.persistentDataPath, "RepackBridge64");
            Directory.CreateDirectory(cfgDir);
            string cacheDir = Path.Combine(Application.persistentDataPath, "PreloadCache");
            File.WriteAllText(
                Path.Combine(cfgDir, "bridge.cfg"),
                "cache_dir=" + cacheDir + "\n" +
                "from=0x" + a.ToInt64().ToString("x") + "\n" +
                "to=0x" + b.ToInt64().ToString("x") + "\n" +
                "dump=0x" + dumpAddr.ToInt64().ToString("x") + "\n");

            string statusPath = Path.Combine(cfgDir, "bridge_status.txt");
            if (File.Exists(statusPath)) File.Delete(statusPath);
            // v3.7: prefer a loose native library copied next to this dll —
            // updating it then costs the same file copy as a dll update and
            // NEVER an APK repackage/reinstall. The apk-baked copy remains as
            // the fallback seed. Once the loose lib is loaded its SONAME is
            // resident, so the API's by-name native binding hits this instance.
            string looseSo = Path.Combine(Application.persistentDataPath, "Mods/RepackBridge/libunityscenerepacker.so");
            bool loaded = false;
            if (File.Exists(looseSo))
            {
                try
                {
                    using (var sysClass = new AndroidJavaClass("java.lang.System"))
                    {
                        sysClass.CallStatic("load", looseSo);
                    }
                    loaded = true;
                    Log("RepackBridge64 v3.9: loose .so loaded from " + looseSo);
                }
                catch (Exception el)
                {
                    Log("RepackBridge64 v3.9: loose .so load failed (" + el.GetType().Name + ": " + el.Message + ") - falling back to apk-baked");
                }
            }
            if (!loaded)
            {
                try
                {
                    using (var rtClass = new AndroidJavaClass("java.lang.Runtime"))
                    using (var rt = rtClass.CallStatic<AndroidJavaObject>("getRuntime"))
                    {
                        rt.Call("loadLibrary", LibName);
                    }
                    Log("RepackBridge64 v3.9: apk-baked .so loaded via loadLibrary");
                }
                catch (Exception e)
                {
                    Log("RepackBridge64 v3.9: loadLibrary failed: " + e.GetType().Name + ": " + e.Message + " - staying FullScene");
                    return;
                }
            }
            string status = File.Exists(statusPath) ? File.ReadAllText(statusPath).Trim() : "(no receipt - .so too old or JNI_OnLoad missing)";
            Log("RepackBridge64 v3.9: native self-setup receipt: " + status);
        }

        public override void Initialize()
        {
            // v3.3: overlay stays up through the whole preload phase now;
            // it closes itself when the menu scene actually appears.
            Log("RepackBridge64 v3.9: initialize (overlay stays through preload)");
        }

        public override string GetVersion()
        {
            return "3.9.0-64a";
        }
    }

    /// <summary>
    /// Preload waiting-room UX: tiny overlay bar + user music + first-menu
    /// music suppression. Lives on its own DontDestroyOnLoad GameObject.
    /// </summary>
    public static class PreloadUx
    {
        private static PreloadUxBehaviour _behaviour;

        public static void Boot(Mod mod)
        {
            try
            {
                var go = new GameObject("RepackBridge64UX");
                UnityEngine.Object.DontDestroyOnLoad(go);
                _behaviour = go.AddComponent<PreloadUxBehaviour>();
                _behaviour.LogTarget = mod;
            }
            catch (Exception e)
            {
                mod.Log("RepackBridge64 v3.9: UX boot failed: " + e.GetType().Name + " " + e.Message);
            }
        }

        public static void FinishWindow(Mod mod)
        {
            try
            {
                if (_behaviour != null) _behaviour.Finish();
            }
            catch (Exception e)
            {
                mod.Log("RepackBridge64 v3.9: UX finish failed: " + e.GetType().Name);
            }
        }
    }

    public class PreloadUxBehaviour : MonoBehaviour
    {
        public Mod LogTarget;

        private float _start;
        private float _lastPoll = -10f;
        private bool _cacheBuild;
        private bool _done;

        // music + mute window
        private AudioSource _music;
        private readonly List<AudioSource> _muted = new List<AudioSource>();
        private bool _menuCueEaten;
        private float _muteScan;

        private GUIStyle _labelStyle;

        // v3.3 download-style overlay state (parsed from progress.txt)
        private float _frac = -1f;        // overall 0..1, -1 = unknown
        private float _phaseFrac = -1f;   // current phase 0..1
        private string _label = "";       // what is being worked on right now
        private bool _failed;             // export_diag.txt seen -> red
        private bool _cacheReady;         // bundle-*.unity3d seen -> green text
        private bool _green;              // menu reached -> green flash, then close
        private float _greenAt;
        private int _scenesTotal;

        private static string ProgressPath =>
            Path.Combine(UnityEngine.Application.persistentDataPath, "PreloadCache", "progress.txt");

        private void Awake()
        {
            _start = Time.unscaledTime;
            InstallMusicMute();
            TryStartMusic();
            if (LogTarget != null) LogTarget.Log("RepackBridge64 v3.9: UX overlay up");
        }

        // ---- first-menu music suppression: DISABLED in v3.8 ----
        // 2026-09-27 实机证据：64 位钩子桥把引用类型参数递给解释器 handler 时
        // 变成 null（MusicCue cue 到手即 null，LooksLikeMenu 永假），转发
        // orig(self, null, …) 又被游戏拒收 —— "Unable to apply null MusicCue"，
        // 结果是装了钩子反而全场无音乐。参数转换是移植版的系统性 bug，mod 侧
        // 无解，只能整个不装。代价：双菜单时首菜单音乐会响（可接受）。
        // 下方 EatFirstMenuCue / EatFirstMenuCueBegin 保留作 32 位时代档案，
        // 移植组修好参数转换后可一行恢复武装。
        private void InstallMusicMute()
        {
            if (LogTarget != null) LogTarget.Log("RepackBridge64 v3.9: music hooks NOT installed (ref-args arrive null on this port; forwarding would mute all music)");
        }

        private static bool LooksLikeMenu(MusicCue cue)
        {
            return cue != null && cue.name != null &&
                   cue.name.IndexOf("Menu", StringComparison.OrdinalIgnoreCase) >= 0;
        }

        private void EatFirstMenuCue(On.AudioManager.orig_ApplyMusicCue orig, global::AudioManager self,
            MusicCue cue, float a, float b, bool c)
        {
            if (!_done && !_menuCueEaten && LooksLikeMenu(cue) && DoubleMenuExpected())
            {
                _menuCueEaten = true;
                if (LogTarget != null) LogTarget.Log("RepackBridge64 v3.9: ate first menu music cue (" + cue.name + ")");
                return;
            }
            orig(self, cue, a, b, c);
        }

        private System.Collections.IEnumerator EatFirstMenuCueBegin(On.AudioManager.orig_BeginApplyMusicCue orig, global::AudioManager self,
            MusicCue cue, float a, float b, bool c)
        {
            if (!_done && !_menuCueEaten && LooksLikeMenu(cue) && DoubleMenuExpected())
            {
                _menuCueEaten = true;
                if (LogTarget != null) LogTarget.Log("RepackBridge64 v3.9: ate first menu music cue (begin, " + cue.name + ")");
                return NoMusic();
            }
            return orig(self, cue, a, b, c);
        }

        private System.Collections.IEnumerator NoMusic()
        {
            yield break;
        }

        // The double-menu (and its duplicate music) only exists when some mod
        // declared preloads -> the preload phase runs -> a throwaway menu is
        // visited before the real one. Without preloads there is exactly one
        // menu and its music must NOT be eaten. Decided lazily at the first
        // menu cue, when all mods are guaranteed to be constructed.
        private bool? _doubleMenuExpected;

        private bool DoubleMenuExpected()
        {
            if (_doubleMenuExpected.HasValue) return _doubleMenuExpected.Value;
            bool v = AnyModHasPreloads();
            _doubleMenuExpected = v;
            if (LogTarget != null)
                LogTarget.Log("RepackBridge64 v3.9: double-menu expected = " + v + (v ? " (suppression armed)" : " (suppression OFF, single menu)"));
            return v;
        }

        private bool AnyModHasPreloads()
        {
            try
            {
                Assembly api = typeof(ModHooks).Assembly;
                Type ml = api.GetType("Modding.ModLoader");
                PropertyInfo prop = ml?.GetProperty("LoadedMods", BindingFlags.Public | BindingFlags.Static);
                if (prop != null)
                {
                    var mods = prop.GetValue(null, null) as System.Collections.IEnumerable;
                    if (mods != null)
                    {
                        foreach (object o in mods)
                        {
                            var imod = o as IMod;
                            if (imod == null) continue;
                            try
                            {
                                var names = imod.GetPreloadNames();
                                if (names != null && names.Count > 0) return true;
                            }
                            catch { }
                        }
                        return false;
                    }
                }
            }
            catch { }
            // Reflection surface missing: fall back to the known offender.
            foreach (var asm in AppDomain.CurrentDomain.GetAssemblies())
            {
                if (asm.GetName().Name == "EnemyRandomizer") return true;
            }
            return false;
        }

        // ---- user music from files/PreloadMusic ----
        private void TryStartMusic()
        {
            try
            {
                string dir = Path.Combine(UnityEngine.Application.persistentDataPath, "PreloadMusic");
                if (!Directory.Exists(dir))
                {
                    Directory.CreateDirectory(dir);
                    if (LogTarget != null) LogTarget.Log("RepackBridge64 v3.9: created PreloadMusic folder - drop .ogg/.mp3/.wav there for preload music");
                    return;
                }
                string pick = null;
                foreach (var f in Directory.GetFiles(dir))
                {
                    string e = Path.GetExtension(f).ToLowerInvariant();
                    if (e == ".ogg" || e == ".mp3" || e == ".wav") { pick = f; break; }
                }
                if (pick == null)
                {
                    if (LogTarget != null) LogTarget.Log("RepackBridge64 v3.9: no music file in PreloadMusic, silent preload");
                    return;
                }
                StartCoroutine(LoadClip(pick));
            }
            catch (Exception e)
            {
                if (LogTarget != null) LogTarget.Log("RepackBridge64 v3.9: music setup failed: " + e.GetType().Name);
            }
        }

        private IEnumerator LoadClip(string path)
        {
            AudioType t = AudioType.UNKNOWN;
            string e = Path.GetExtension(path).ToLowerInvariant();
            if (e == ".ogg") t = AudioType.OGGVORBIS;
            else if (e == ".mp3") t = AudioType.MPEG;
            else if (e == ".wav") t = AudioType.WAV;
            using (UnityWebRequest u = UnityWebRequestMultimedia.GetAudioClip("file://" + path, t))
            {
                yield return u.SendWebRequest();
#pragma warning disable 618
                bool failed = u.isNetworkError || u.isHttpError;
#pragma warning restore 618
                if (failed || _done)
                {
                    if (LogTarget != null) LogTarget.Log("RepackBridge64 v3.9: music load failed for " + Path.GetFileName(path));
                    yield break;
                }
                AudioClip clip = DownloadHandlerAudioClip.GetContent(u);
                if (clip == null) yield break;
                _music = gameObject.AddComponent<AudioSource>();
                _music.clip = clip;
                _music.loop = true;
                _music.Play();
                if (LogTarget != null) LogTarget.Log("RepackBridge64 v3.9: preload music playing: " + Path.GetFileName(path));
            }
        }

        // ---- per-frame window: fight API mute, mute game sources ----
        private void Update()
        {
            if (_done) return;

            // The API's MuteAllAudio pauses the global listener; we need it
            // awake for our own music, so game audio is muted per-source.
            if (AudioListener.pause) AudioListener.pause = false;

            _muteScan -= Time.unscaledDeltaTime;
            if (_muteScan <= 0f)
            {
                _muteScan = 0.4f;
                foreach (var s in FindObjectsOfType<AudioSource>())
                {
                    if (s == _music) continue;
                    if (!s.mute) { s.mute = true; _muted.Add(s); }
                }
            }

            if (Time.unscaledTime - _lastPoll > 1f)
            {
                _lastPoll = Time.unscaledTime;
                PollProgress();
            }

            // v3.3: preload is over when the menu scene shows up. Flash green,
            // then close the waiting room.
            if (!_green && Time.unscaledTime - _start > 5f &&
                UnityEngine.SceneManagement.SceneManager.GetActiveScene().name.IndexOf("Menu", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                _green = true;
                _greenAt = Time.unscaledTime;
            }
            if (_green && Time.unscaledTime - _greenAt > 1.5f) Finish();
        }

        private void PollProgress()
        {
            try
            {
                string cacheDir = Path.GetDirectoryName(ProgressPath);
                if (Directory.Exists(cacheDir))
                {
                    if (File.Exists(Path.Combine(cacheDir, "export_diag.txt"))) _failed = true;
                    if (Directory.GetFiles(cacheDir, "bundle-*.unity3d").Length > 0) _cacheReady = true;
                }
                // v3.9: the real progress file lives in the active work dir
                // (PreloadCache/work-<key>/progress.txt) — the root path this
                // overlay used to watch exclusively is never written, which
                // is why the bar never showed phase progress on device.
                string prog = ProgressPath;
                if (!File.Exists(prog) && cacheDir != null)
                {
                    try
                    {
                        DateTime best = DateTime.MinValue;
                        foreach (string d in Directory.GetDirectories(cacheDir, "work-*"))
                        {
                            string p = Path.Combine(d, "progress.txt");
                            if (!File.Exists(p)) continue;
                            DateTime w = File.GetLastWriteTime(p);
                            if (w > best) { best = w; prog = p; }
                        }
                    }
                    catch { }
                }
                if (!File.Exists(prog)) return;
                string[] lines = File.ReadAllLines(prog);
                for (int i = lines.Length - 1; i >= 0; i--)
                {
                    string l = lines[i].Trim();
                    if (l.Length == 0) continue;
                    ParseBreadcrumb(l);
                    break;
                }
            }
            catch { }
        }

        // "phase1: 12/156 scenes done, current: Tutorial_01"
        // "embed-deps: files_done=64 refs_embedded=812 files_pending=900 refs_queued=7"
        private void ParseBreadcrumb(string l)
        {
            try
            {
                if (l.StartsWith("phase1:"))
                {
                    _cacheBuild = true;
                    string[] p = l.Split(' ');
                    string[] dt = p[1].Split('/');
                    int done = int.Parse(dt[0]);
                    int total = int.Parse(dt[1]);
                    _scenesTotal = total;
                    _frac = total > 0 ? (float)done / total : -1f;
                    _phaseFrac = _frac;
                    int ci = l.IndexOf("current:");
                    _label = ci >= 0
                        ? "scene: " + l.Substring(ci + 8).Trim() + " (" + done + "/" + total + ")"
                        : "scenes " + done + "/" + total;
                    return;
                }
                if (l.StartsWith("embed-deps:"))
                {
                    _cacheBuild = true;
                    int fd = Grab(l, "files_done=");
                    int rp = Grab(l, "files_pending=");
                    int tot = fd + rp;
                    _phaseFrac = tot > 0 ? (float)fd / tot : -1f;
                    if (_scenesTotal > 0)
                        _frac = (float)(_scenesTotal + fd) / (_scenesTotal + tot);
                    _label = "embedding deps: file " + fd + "/" + tot;
                    return;
                }
                // v13.14 .so phase-2 breadcrumbs (merge/pack used to be silent):
                // "phase2: scenes 8/156 current: Room_X data_mb=12 rss_mb=340"
                // "phase2: embedded 256/1028 data_mb=40 rss_mb=350"
                // "phase2: writing merged file (1234 objects, 56 MB, rss_mb=300)"
                // "phase2: merged 56 MB in 240s (rss_mb=290), writing bundle"
                // "phase2: bundle written in 400s (rss_mb=290)"
                if (l.StartsWith("phase2:"))
                {
                    _cacheBuild = true;
                    _frac = -1f; // overall unknown; second bar shows this phase
                    int dm = Grab(l, "data_mb=");
                    int rss = Grab(l, "rss_mb=");
                    if (l.Contains("scenes "))
                    {
                        int n = Grab(l, "scenes ");
                        int t = GrabAfterSlash(l, "scenes ");
                        _phaseFrac = t > 0 ? (float)n / t : -1f;
                        _label = "packing scenes " + n + "/" + t
                            + (dm > 0 ? " · " + dm + " MB" : "")
                            + (rss > 0 ? " · rss " + rss + " MB" : "");
                    }
                    else if (l.Contains("embedded "))
                    {
                        int n = Grab(l, "embedded ");
                        int t = GrabAfterSlash(l, "embedded ");
                        _phaseFrac = t > 0 ? (float)n / t : -1f;
                        _label = "splicing deps " + n + "/" + t
                            + (dm > 0 ? " · " + dm + " MB" : "");
                    }
                    else if (l.Contains("writing merged"))
                    {
                        _phaseFrac = -1f;
                        _label = "writing merged file…";
                    }
                    else if (l.Contains("writing bundle"))
                    {
                        _phaseFrac = -1f;
                        _label = "writing final bundle…";
                    }
                    else if (l.Contains("bundle written"))
                    {
                        _phaseFrac = 1f;
                        _label = "bundle done, publishing…";
                    }
                    else
                    {
                        _phaseFrac = -1f;
                        _label = "phase 2: " + l.Substring(7).Trim();
                    }
                }
            }
            catch { }
        }

        private static int Grab(string l, string key)
        {
            int i = l.IndexOf(key);
            if (i < 0) return 0;
            i += key.Length;
            int j = i;
            while (j < l.Length && l[j] >= '0' && l[j] <= '9') j++;
            return j > i ? int.Parse(l.Substring(i, j - i)) : 0;
        }

        // "…scenes 8/156…" -> 156 (the denominator after the key's N/)
        private static int GrabAfterSlash(string l, string key)
        {
            int i = l.IndexOf(key);
            if (i < 0) return 0;
            int slash = l.IndexOf('/', i + key.Length);
            if (slash < 0) return 0;
            int j = slash + 1;
            int k = j;
            while (k < l.Length && l[k] >= '0' && l[k] <= '9') k++;
            return k > j ? int.Parse(l.Substring(j, k - j)) : 0;
        }

        public void Finish()
        {
            if (_done) return;
            _done = true;
            foreach (var s in _muted)
            {
                if (s != null) s.mute = false;
            }
            _muted.Clear();
            if (_music != null)
            {
                _music.Stop();
                Destroy(_music);
                _music = null;
            }
        }

        private void OnDestroy()
        {
            Finish();
        }

        // ---- overlay ----
        private void OnGUI()
        {
            if (_done) return;
            if (_labelStyle == null)
            {
                _labelStyle = new GUIStyle(GUI.skin.label);
                _labelStyle.fontSize = Math.Max(14, Screen.height / 60);
                _labelStyle.normal.textColor = Color.white;
                _labelStyle.alignment = TextAnchor.MiddleCenter;
            }

            // v3.3: shorter + a bit thicker, download-style: name of what is
            // being worked on, double bar (overall + current phase),
            // blue working / green done / red failed.
            float w = Screen.width * 0.46f;
            float x = (Screen.width - w) / 2f;
            float y = Screen.height * 0.10f;
            float barH = 14f;
            float ph = 118f;
            // v3.4: the loading screen is mostly black, so the panel gets a
            // white 2px border + dark translucent fill -- never black-on-black
            GUI.color = new Color(1f, 1f, 1f, 0.92f);
            GUI.DrawTexture(new Rect(x - 10, y - 8, w + 20, ph), Texture2D.whiteTexture);
            GUI.color = new Color(0.05f, 0.05f, 0.08f, 0.78f);
            GUI.DrawTexture(new Rect(x - 8, y - 6, w + 16, ph - 4), Texture2D.whiteTexture);
            GUI.color = Color.white;

            string head;
            if (_failed) head = "打包失败：本次跳过预载（不影响进入游戏）";
            else if (_green || _cacheReady && !_cacheBuild) head = "预载完成";
            else if (_cacheReady) head = "缓存已建好";
            else if (_cacheBuild) head = "第一次建缓存（之后每次秒过）";
            else head = "预载中";
            string body = _label.Length > 0
                ? _label
                : string.Format("已耗时 {0:D2}:{1:D2}", (int)(Time.unscaledTime - _start) / 60, (int)(Time.unscaledTime - _start) % 60);
            GUI.Label(new Rect(x, y, w, 30), head, _labelStyle);
            GUI.Label(new Rect(x, y + 26, w, 30), body, _labelStyle);

            Color state = _failed
                ? new Color(0.92f, 0.28f, 0.28f, 0.95f)
                : (_green || _cacheReady)
                    ? new Color(0.30f, 0.85f, 0.40f, 0.95f)
                    : new Color(0.35f, 0.8f, 1f, 0.9f);
            GUI.color = state;
            DrawBar(x, y + 60, w, barH, _frac);
            DrawBar(x, y + 60 + barH + 6, w, barH, _phaseFrac);
            GUI.color = Color.white;
        }

        // v3.4 download-style bar: thin white border, always-visible light
        // track, colored fill growing left to right. fraction < 0 (percentage
        // genuinely unknown) keeps the track but runs a highlight segment --
        // never fakes a number we do not have.
        private void DrawBar(float x, float y, float w, float h, float frac)
        {
            GUI.color = new Color(1f, 1f, 1f, 0.9f);
            GUI.DrawTexture(new Rect(x - 1, y - 1, w + 2, h + 2), Texture2D.whiteTexture);
            GUI.color = new Color(1f, 1f, 1f, 0.30f);
            GUI.DrawTexture(new Rect(x, y, w, h), Texture2D.whiteTexture);
            if (_failed) GUI.color = new Color(0.92f, 0.28f, 0.28f, 0.95f);
            else if (_green || _cacheReady) GUI.color = new Color(0.30f, 0.85f, 0.40f, 0.95f);
            else GUI.color = new Color(0.35f, 0.8f, 1f, 0.9f);
            if (frac >= 0f)
            {
                GUI.DrawTexture(new Rect(x, y, Math.Max(4f, w * Mathf.Clamp01(frac)), h), Texture2D.whiteTexture);
            }
            else
            {
                float t = (Time.unscaledTime % 2f) / 2f;
                GUI.DrawTexture(new Rect(x + w * t, y, Math.Max(8f, w * 0.12f), h), Texture2D.whiteTexture);
            }
            GUI.color = Color.white;
        }
    }
}
