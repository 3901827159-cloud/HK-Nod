using System;
using System.Collections.Generic;
using Modding;
using UnityEngine;
using UnityEngine.UI;

namespace EnemyRandomizerMod
{
    /// <summary>
    /// LSCR-ZH-28: display-time Chinese localisation for the Enemy Randomizer
    /// menus (root menu, general settings, module list, every module subpage).
    ///
    /// HARD CONSTRAINT: persisted keys are never touched. Logic names, option
    /// keys (saved-logic lists, subpage/element lookups) and the
    /// HorizontalOption Values arrays all stay English; only the
    /// UnityEngine.UI.Text components that RENDER them get their .text
    /// swapped at display time, and their font swapped to the game's own
    /// bundled CJK font so glyphs actually render on an English build.
    ///
    /// Why a sweeper instead of patching Satchel: Satchel's
    /// HorizontalOption.Update() re-sets Label/Description from Name/
    /// Description every update, so a one-shot translation would be undone
    /// within a frame. We therefore (a) periodically scan for Text components
    /// whose current text is a known English string and register them, and
    /// (b) in LateUpdate (after Satchel's Update, before rendering) re-apply
    /// the Chinese string + font to every registered component - resets are
    /// invisible to the player.
    ///
    /// Degrades quietly: no CJK font found -> localiser stays off and the
    /// menus remain English (translated text in a glyph-less font would be
    /// tofu, which is worse than English).
    /// </summary>
    public static class ZhStrings
    {
        public static readonly Dictionary<string, string> Zh = new Dictionary<string, string>
        {
            // ---- root menu ----
            { "Enemy Randomizer Settings", "敌人随机器设置" },
            { "General Settings", "通用设置" },
            { "Module List", "模块列表" },
            { "------- Enabled Modules --------", "------- 已启用模块 --------" },
            { "Select a module to configure it", "选择一个模块进行配置" },
            { "Seed settings, credits, and other general mod settings", "种子设置、制作人员与其他通用设置" },
            { "The list of modules that may be enabled", "可启用模块的列表" },

            // ---- general settings ----
            { "Randomizer Seed", "随机器种子" },
            { "Click to type a custom seed", "点击输入自定义种子" },
            { "Custom Colosseum Seed", "自定义斗兽场种子" },
            { "Click to set a custom seed for colosseum", "点击为斗兽场设置自定义种子" },
            { "Use custom seed for new game", "新存档使用自定义种子" },
            { "Applies to new files or files first loaded without a saved seed", "作用于新存档，或首次加载时没有已存种子的存档" },
            { "Use custom seed for colosseum", "斗兽场使用自定义种子" },
            { "Will use this seed instead of your player settings seed for colosseum", "斗兽场将改用此种子，而非玩家设置里的种子" },
            { "Balance Replacement HP", "平衡替换敌人血量" },
            { "Should the randomizer try to balance the HP of the enemy it spawns? [RECOMMENDED TO KEEP ENABLED]", "随机器是否尝试平衡所生成敌人的血量？[建议保持开启]" },
            { "Randomize Replacement Geo", "随机替换敌人吉欧" },
            { "Should the randomizer try to place geo into enemies it generates? (Without this, many will have zero by default)", "随机器是否尝试往生成的敌人身上放吉欧？（不开则许多敌人默认为零）" },
            { "Allow Custom Enemies", "允许自定义敌人" },
            { "May the randomizer spawn non-vanilla things?", "允许随机器生成非原版内容吗？" },
            { "Allow Enemy Rando Extras", "允许随机器附加改动" },
            { "May the randomizer modify the game in extra ways (mostly cosmetic)?", "允许随机器以额外方式（多为外观）改动游戏吗？" },
            { "Reset To Default Settings", "恢复默认设置" },
            { "Change all settings back to the mod defaults", "将所有设置改回模组默认值" },
            { "Credits", "制作人员" },
            { "Enemy Randomizer Author: Kerr1291", "敌人随机器作者：Kerr1291" },
            { "Satchel/UI: Mulhima", "Satchel/界面：Mulhima" },
            { "Special Thanks: TheDanielMat", "特别感谢：TheDanielMat" },
            { "_Playtesters_", "_测试玩家_" },
            { "...and you; thanks for playing!", "……以及你；感谢游玩！" },

            // ---- module names + infos (display only; keys stay English) ----
            { "Zote Mode", "佐特模式" },
            { "Precept Forty-Five: 'One Thing Is Not Another'. This one should be obvious, but I've had others try to argue that one thing, which is clearly what it is and not something else, is actually some other thing, which it isn't. Stay on your guard!", "戒律四十五：「一物非他物」。这本该不言自明，但总有人硬要争辩：明明是此物、绝非他物的东西，其实是另一个并非此物的他物。保持警惕！" },
            { "Allow Custom Zotes", "允许自定义佐特" },
            { "[NOT YET IMPLEMENTED] Precept Thirty-Two: 'Names Have Power'. Names have power, and so to name something is to grant it power. I myself named my nail 'Life Ender'. Do not steal the name I came up with! Invent your own!", "［尚未实现］戒律三十二：「名字即力量」。命名即赋予力量。我给自己的钉起名「生命终结者」。别偷我想的名字！自己发明一个！" },
            { "Enemy Filter", "敌人筛选器" },
            { "Control which enemies will be replaced", "控制哪些敌人会被替换" },
            { "Enemy Enabler", "敌人启用器" },
            { "Enable/Disable individual enemies from randomization", "单独启用/禁用参与随机的敌人" },
            { "Replacement Logic", "替换逻辑" },
            { "Defines if enemies, hazards, and effects should be replace/randomized.", "定义敌人、危害物与特效是否参与替换/随机" },
            { "Randomization Modes", "随机化模式" },
            { "Configure how objects should be randomized", "配置物件的随机化方式" },
            { "Enemy Size Changer", "敌人体型修改器" },
            { "Changes the size of enemies", "改变敌人的体型" },
            { "Fix Object Positions", "修正物件位置" },
            { "Attempts to correctly reposition objects that have been randomized using the old logic. Does not always work...", "尝试把按旧逻辑随机化的物件摆回正确位置。不总有效……" },
            { "Enable All", "全部启用" },
            { "Disable All", "全部禁用" },
            { "Enable all options", "启用所有选项" },
            { "Disable all options", "禁用所有选项" },

            // ---- Replacement Logic subpage ----
            { "Randomize Enemies", "随机化敌人" },
            { "Should enemies be randomized?", "是否随机化敌人？" },
            { "Randomize Hazards", "随机化危害物" },
            { "[VERY JANKY]: Should (some) hazards be randomized?", "［非常粗糙］：是否随机化（部分）危害物？" },
            { "Randomize Effects", "随机化特效" },
            { "[EXTREMELY JANKY]:Should (some) effects be randomized?", "［极其粗糙］：是否随机化（部分）特效？" },
            { "Use basic replacement matching?", "使用基础替换匹配？" },
            { "Try to replace enemies with similar types? (DO NOT USE WITH ZOTE MODE!)", "尝试用相似类型替换敌人？（勿与佐特模式同用！）" },
            { "Allow bad replacements?", "允许劣质替换？" },
            { "Try and pick enemies that won't instantly die when spawned", "尽量挑选生成后不会立刻死亡的敌人" },

            // ---- Randomization Modes subpage ----
            { "Choose 1", "选一个" },
            { "Randomization Type", "随机化类型" },
            { "Object", "物件" },
            { "Transition", "换房" },
            { "Room", "房间" },
            { "Zone", "区域" },
            { "Type", "类型" },
            { "Each object will change to a different type (Best Setting)", "每个物件变为不同类型（最佳设置）" },
            { "Each time you change rooms everything is will be different (Old Chaos Mode)", "每次换房，一切都会不同（旧混沌模式）" },
            { "Each room will change one object type", "每个房间改变一种物件类型" },
            { "Each zone will change one object type", "每个区域改变一种物件类型" },
            { "This will result in one type of object being changed in the same way throughout the game", "全游戏内同一种物件以相同方式被改变" },

            // ---- Enemy Size Changer subpage ----
            { "Enemy Scaling Type", "敌人缩放类型" },
            { "Match Audio to Scaling", "音效随缩放匹配" },
            { "Should enemies have their sounds changed too?", "敌人的音效是否也随之改变？" },
            { "Match", "匹配" },
            { "Random", "随机" },
            { "All Big", "全大" },
            { "All Tiny", "全小" },
            { "New enemies match the size of the original enemy. Best for stability.", "新敌人匹配原敌人的体型。最稳。" },
            { "New enemies match the size of the original enemy. Best for stability", "新敌人匹配原敌人的体型。最稳。" },
            { "Scale each enemy randomly", "每个敌人随机缩放" },
            { "Giant Enemies Everywhere (WARNING Unstable: Many enemies will not fit places...)", "处处巨型敌人（警告 不稳定：许多敌人塞不进场景……）" },
            { "Giant Enemies Everywhere", "处处巨型敌人" },
            { "Tiny Enemies Everywhere", "处处微小敌人" },
        };
    }

    public class ZhLocalizerBehaviour : MonoBehaviour
    {
        private readonly Dictionary<Text, string> _map = new Dictionary<Text, string>();
        private Font _cjk;
        private float _nextScan;
        private Mod _log;

        public void Init(Mod log)
        {
            _log = log;
            _cjk = FindCjkFont();
            if (_cjk == null)
            {
                if (_log != null) _log.Log("LSCR-ZH-28: no CJK font found - menu localiser stays OFF (menus remain English)");
                enabled = false;
                return;
                }
            if (_log != null) _log.Log("LSCR-ZH-28: localiser up, font=" + _cjk.name + ", entries=" + ZhStrings.Zh.Count);
        }

        // The Modding API's menu resource bundle exposes the game's bundled
        // CJK font as a property; fall back to a direct Resources load.
        private static Font FindCjkFont()
        {
            try
            {
                var t = typeof(ModHooks).Assembly.GetType("Modding.Menu.MenuResources");
                if (t != null)
                {
                    var p = t.GetProperty("NotoSerifCJKSCRegular",
                        System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.NonPublic
                        | System.Reflection.BindingFlags.Static | System.Reflection.BindingFlags.Instance);
                    if (p != null)
                    {
                        object v = null;
                        try { v = p.GetValue(null, null); }
                        catch
                        {
                            var inst = Resources.FindObjectsOfTypeAll(t);
                            if (inst != null && inst.Length > 0) v = p.GetValue(inst[0], null);
                        }
                        var f = v as Font;
                        if (f != null) return f;
                    }
                }
            }
            catch { }
            try
            {
                var f2 = Resources.Load<Font>("NotoSerifCJKSCRegular");
                if (f2 != null) return f2;
            }
            catch { }
            return null;
        }

        private void Update()
        {
            if (Time.unscaledTime < _nextScan) return;
            _nextScan = Time.unscaledTime + 0.4f;
            try
            {
                Scan();
            }
            catch (Exception e)
            {
                if (_log != null) _log.Log("LSCR-ZH-28: scan swallowed " + e.GetType().Name);
                enabled = false;
            }
        }

        private void Scan()
        {
            // drop destroyed components
            var dead = new List<Text>();
            foreach (var kv in _map) if (kv.Key == null) dead.Add(kv.Key);
            foreach (var d in dead) _map.Remove(d);

            foreach (var t in FindObjectsOfType<Text>())
            {
                if (t == null || _map.ContainsKey(t)) continue;
                string cur;
                try { cur = t.text; } catch { continue; }
                if (cur == null) continue;
                if (ZhStrings.Zh.ContainsKey(cur))
                {
                    _map[t] = cur;
                    Apply(t);
                }
            }
        }

        // Satchel re-sets Label/Description from the English keys in its own
        // Update; LateUpdate runs after that and before rendering, so the
        // player never sees the English flash back.
        private void LateUpdate()
        {
            if (_map.Count == 0) return;
            foreach (var kv in _map)
            {
                var t = kv.Key;
                if (t == null) continue;
                string zh;
                if (!ZhStrings.Zh.TryGetValue(kv.Value, out zh)) continue;
                if (t.text != zh) Apply(t);
            }
        }

        private void Apply(Text t)
        {
            string zh;
            if (!ZhStrings.Zh.TryGetValue(_map.ContainsKey(t) ? _map[t] : t.text, out zh)) return;
            t.text = zh;
            if (_cjk != null && t.font != _cjk) t.font = _cjk;
        }
    }
}
