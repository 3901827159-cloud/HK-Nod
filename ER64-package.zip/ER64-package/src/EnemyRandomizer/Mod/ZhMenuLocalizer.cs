using System;
using System.Collections.Generic;
using Modding;
using UnityEngine;
using UnityEngine.UI;

namespace EnemyRandomizerMod
{
    /// <summary>
    /// LSCR-ZH-28: display-time Chinese localisation for the Enemy Randomizer
    /// menus (root menu, general settings, module list, every module subpage).
    ///
    /// HARD CONSTRAINT: persisted keys are never touched. Logic names, option
    /// keys (saved-logic lists, subpage/element lookups) and the
    /// HorizontalOption Values arrays all stay English; only the
    /// UnityEngine.UI.Text components that RENDER them get their .text
    /// swapped at display time, and their font swapped to the game's own
    /// bundled CJK font so glyphs actually render on an English build.
    ///
    /// Why a sweeper instead of patching Satchel: Satchel's
    /// HorizontalOption.Update() re-sets Label/Description from Name/
    /// Description every update, so a one-shot translation would be undone
    /// within a frame. We therefore (a) periodically scan for Text components
    /// whose current text is a known English string and register them, and
    /// (b) in LateUpdate (after Satchel's Update, before rendering) re-apply
    /// the Chinese string + font to every registered component - resets are
    /// invisible to the player.
    ///
    /// Degrades quietly: no CJK font found -> localiser stays off and the
    /// menus remain English (translated text in a glyph-less font would be
    /// tofu, which is worse than English).
    /// </summary>
    public static class ZhStrings
    {
        public static readonly Dictionary<string, string> Zh = new Dictionary<string, string>
        {
            // ---- root menu ----
            { "Enemy Randomizer Settings", "敌人随机器设置" },
            { "General Settings", "通用设置" },
            { "Module List", "模块列表" },
            { "------- Enabled Modules --------", "------- 已启用模块 --------" },
            { "Select a module to configure it", "选择一个模块进行配置" },
            { "Seed settings, credits, and other general mod settings", "种子设置、制作人员与其他通用设置" },
            { "The list of modules that may be enabled", "可启用模块的列表" },

            // ---- general settings ----
            { "Randomizer Seed", "随机器种子" },
            { "Click to type a custom seed", "点击输入自定义种子" },
            { "Custom Colosseum Seed", "自定义斗兽场种子" },
            { "Click to set a custom seed for colosseum", "点击为斗兽场设置自定义种子" },
            { "Use custom seed for new game", "新存档使用自定义种子" },
            { "Applies to new files or files first loaded without a saved seed", "作用于新存档，或首次加载时没有已存种子的存档" },
            { "Use custom seed for colosseum", "斗兽场使用自定义种子" },
            { "Will use this seed instead of your player settings seed for colosseum", "斗兽场将改用此种子，而非玩家设置里的种子" },
            { "Balance Replacement HP", "平衡替换敌人血量" },
            { "Should the randomizer try to balance the HP of the enemy it spawns? [RECOMMENDED TO KEEP ENABLED]", "随机器是否尝试平衡所生成敌人的血量？[建议保持开启]" },
            { "Randomize Replacement Geo", "随机替换敌人吉欧" },
            { "Should the randomizer try to place geo into enemies it generates? (Without this, many will have zero by default)", "随机器是否尝试往生成的敌人身上放吉欧？（不开则许多敌人默认为零）" },
            { "Allow Custom Enemies", "允许自定义敌人" },
            { "May the randomizer spawn non-vanilla things?", "允许随机器生成非原版内容吗？" },
            { "Allow Enemy Rando Extras", "允许随机器附加改动" },
            { "May the randomizer modify the game in extra ways (mostly cosmetic)?", "允许随机器以额外方式（多为外观）改动游戏吗？" },
            { "Reset To Default Settings", "恢复默认设置" },
            { "Change all settings back to the mod defaults", "将所有设置改回模组默认值" },
            { "Credits", "制作人员" },
            { "Enemy Randomizer Author: Kerr1291", "敌人随机器作者：Kerr1291" },
            { "Satchel/UI: Mulhima", "Satchel/界面：Mulhima" },
            { "Special Thanks: TheDanielMat", "特别感谢：TheDanielMat" },
            { "_Playtesters_", "_测试玩家_" },
            { "...and you; thanks for playing!", "……以及你；感谢游玩！" },

            // ---- module names + infos (display only; keys stay English) ----
            { "Zote Mode", "佐特模式" },
            { "Precept Forty-Five: 'One Thing Is Not Another'. This one should be obvious, but I've had others try to argue that one thing, which is clearly what it is and not something else, is actually some other thing, which it isn't. Stay on your guard!", "戒律四十五：「一物非他物」。这本该不言自明，但总有人硬要争辩：明明是此物、绝非他物的东西，其实是另一个并非此物的他物。保持警惕！" },
            { "Allow Custom Zotes", "允许自定义佐特" },
            { "[NOT YET IMPLEMENTED] Precept Thirty-Two: 'Names Have Power'. Names have power, and so to name something is to grant it power. I myself named my nail 'Life Ender'. Do not steal the name I came up with! Invent your own!", "［尚未实现］戒律三十二：「名字即力量」。命名即赋予力量。我给自己的钉起名「生命终结者」。别偷我想的名字！自己发明一个！" },
            { "Enemy Filter", "敌人筛选器" },
            { "Control which enemies will be replaced", "控制哪些敌人会被替换" },
            { "Enemy Enabler", "敌人启用器" },
            { "Enable/Disable individual enemies from randomization", "单独启用/禁用参与随机的敌人" },
            { "Replacement Logic", "替换逻辑" },
            { "Defines if enemies, hazards, and effects should be replace/randomized.", "定义敌人、危害物与特效是否参与替换/随机" },
            { "Randomization Modes", "随机化模式" },
            { "Configure how objects should be randomized", "配置物件的随机化方式" },
            { "Enemy Size Changer", "敌人体型修改器" },
            { "Changes the size of enemies", "改变敌人的体型" },
            { "Fix Object Positions", "修正物件位置" },
            { "Attempts to correctly reposition objects that have been randomized using the old logic. Does not always work...", "尝试把按旧逻辑随机化的物件摆回正确位置。不总有效……" },
            { "Enable All", "全部启用" },
            { "Disable All", "全部禁用" },
            { "Enable all options", "启用所有选项" },
            { "Disable all options", "禁用所有选项" },

            // ---- Replacement Logic subpage ----
            { "Randomize Enemies", "随机化敌人" },
            { "Should enemies be randomized?", "是否随机化敌人？" },
            { "Randomize Hazards", "随机化危害物" },
            { "[VERY JANKY]: Should (some) hazards be randomized?", "［非常粗糙］：是否随机化（部分）危害物？" },
            { "Randomize Effects", "随机化特效" },
            { "[EXTREMELY JANKY]:Should (some) effects be randomized?", "［极其粗糙］：是否随机化（部分）特效？" },
            { "Use basic replacement matching?", "使用基础替换匹配？" },
            { "Try to replace enemies with similar types? (DO NOT USE WITH ZOTE MODE!)", "尝试用相似类型替换敌人？（勿与佐特模式同用！）" },
            { "Allow bad replacements?", "允许劣质替换？" },
            { "Try and pick enemies that won't instantly die when spawned", "尽量挑选生成后不会立刻死亡的敌人" },

            // ---- Randomization Modes subpage ----
            { "Choose 1", "选一个" },
            { "Randomization Type", "随机化类型" },
            { "Object", "物件" },
            { "Transition", "换房" },
            { "Room", "房间" },
            { "Zone", "区域" },
            { "Type", "类型" },
            { "Each object will change to a different type (Best Setting)", "每个物件变为不同类型（最佳设置）" },
            { "Each time you change rooms everything is will be different (Old Chaos Mode)", "每次换房，一切都会不同（旧混沌模式）" },
            { "Each room will change one object type", "每个房间改变一种物件类型" },
            { "Each zone will change one object type", "每个区域改变一种物件类型" },
            { "This will result in one type of object being changed in the same way throughout the game", "全游戏内同一种物件以相同方式被改变" },

            // ---- Enemy Size Changer subpage ----
            { "Enemy Scaling Type", "敌人缩放类型" },
            { "Match Audio to Scaling", "音效随缩放匹配" },
            { "Should enemies have their sounds changed too?", "敌人的音效是否也随之改变？" },
            { "Match", "匹配" },
            { "Random", "随机" },
            { "All Big", "全大" },
            { "All Tiny", "全小" },
            { "New enemies match the size of the original enemy. Best for stability.", "新敌人匹配原敌人的体型。最稳。" },
            { "New enemies match the size of the original enemy. Best for stability", "新敌人匹配原敌人的体型。最稳。" },
            { "Scale each enemy randomly", "每个敌人随机缩放" },
            { "Giant Enemies Everywhere (WARNING Unstable: Many enemies will not fit places...)", "处处巨型敌人（警告 不稳定：许多敌人塞不进场景……）" },
            { "Giant Enemies Everywhere", "处处巨型敌人" },
            { "Tiny Enemies Everywhere", "处处微小敌人" },

            // ---- enemy names (LSCR-ZH-37) ----
            // Display-name translation for the enemy lists (Enemy Enabler /
            // Enemy Filter and anywhere else an ObjectName is rendered as a
            // Text). Corpus = every object name seen in the 2026-10-01 dense
            // gameplay round (swap sources + replacement targets, 283 raw ->
            // 149 base names after stripping " (N)"/"(Clone)" suffixes; the
            // sweeper below matches base names too, so one entry covers a
            // whole instance family). Persisted keys and logs stay English -
            // this is display-only, same contract as the menu strings above.
            { "Abyss Crawler", "深渊爬行者" },
            { "Acid Walker", "酸液行者" },
            { "Angry Buzzer", "狂怒鸣蜂" },
            { "Baby Centipede", "幼体蜈蚣" },
            { "Bee Hatchling Ambient", "蜂巢幼蜂（环境）" },
            { "Bee Stinger", "蜂刺者" },
            { "Big Centipede", "巨型蜈蚣" },
            { "Black Knight", "黑骑士" },
            { "Blow Fly", "气囊飞蝇" },
            { "Bursting Bouncer", "爆裂弹跳虫" },
            { "Bursting Zombie", "爆裂行尸" },
            { "Buzzer", "鸣蜂" },
            { "Buzzer 3", "鸣蜂三型" },
            { "Ceiling Dropper", "顶棚潜伏虫" },
            { "Climber", "攀爬者" },
            { "Colosseum_Armoured_Roller", "斗兽场装甲滚虫" },
            { "Colosseum_Flying_Sentry", "斗兽场飞行哨卫" },
            { "Colosseum_Miner", "斗兽场矿工" },
            { "Colosseum_Shield_Zombie", "斗兽场盾兵行尸" },
            { "Corpse Garden Zombie", "尸园行尸" },
            { "Crawler", "爬行者" },
            { "Crystal Crawler", "水晶爬行者" },
            { "Crystal Flyer", "水晶飞虫" },
            { "Crystallised Lazer Bug", "结晶激光虫" },
            { "Dream Mage Lord", "梦魇法师领主" },
            { "Dung Defender", "粪虫防御者" },
            { "Enemy", "敌人" },
            { "False Knight New", "假骑士（新）" },
            { "Fat Fluke", "肥吸虫" },
            { "Fat Fly", "肥胖飞蝇" },
            { "Flip Hopper", "翻转跳虫" },
            { "Fluke Fly", "吸虫蝇" },
            { "Fluke Mother", "吸虫母体" },
            { "Flukeman", "吸虫人" },
            { "Fly", "飞蝇" },
            { "Fung Crawler", "真菌爬行者" },
            { "Fungoon Baby", "幼体真菌兽" },
            { "Garden Zombie", "花园行尸" },
            { "Ghost Warrior Galien", "鬼魂武士·加利安" },
            { "Giant Buzzer Col", "巨型鸣蜂（斗兽场）" },
            { "Giant Hopper", "巨型跳虫" },
            { "Gorgeous Husk", "华丽尸壳" },
            { "Grass Hopper", "草跳虫" },
            { "Grave Zombie", "墓地行尸" },
            { "Great Shield Zombie", "巨盾行尸" },
            { "Grey Prince", "灰王子佐特" },
            { "Hatcher", "孵化者" },
            { "Hopper", "跳虫" },
            { "Hornet Boss 1", "大黄蜂（首领战一）" },
            { "Hornet Boss 2", "大黄蜂（首领战二）" },
            { "Hornet Nosk", "大黄蜂（诺斯克巢）" },
            { "Infected Knight", "感染骑士" },
            { "Inflater", "充气虫" },
            { "Jar Collector", "罐中收藏家" },
            { "Jellyfish", "水母" },
            { "Jellyfish Baby", "小水母" },
            { "Laser Turret", "激光炮台" },
            { "Laser Turret Frames", "激光炮台（帧体）" },
            { "Lazy Flyer Enemy", "懒飞虫" },
            { "Lesser Mawlek", "小型毛里克" },
            { "Lobster", "螯虾" },
            { "Lost Kin", "迷失亲族" },
            { "Mage", "法师" },
            { "Mage Balloon", "法师气球" },
            { "Mage Blob", "法师黏团" },
            { "Mage Blob 2", "法师黏团二型" },
            { "Mage Knight", "法师骑士" },
            { "Mantis", "螳螂" },
            { "Mantis Flyer Child", "螳螂飞兵（幼体）" },
            { "Mantis Heavy", "重装螳螂" },
            { "Mato", "马托" },
            { "Mawlek Turret", "毛里克炮台" },
            { "Mega Fat Bee", "超肥胖蜂" },
            { "Mega Moss Charger", "超级苔藓冲锋者" },
            { "Mender Bug", "修缝虫" },
            { "Mimic Spider", "拟态蜘蛛" },
            { "Mines Crawler", "矿洞爬行者" },
            { "Mosquito", "蚊虫" },
            { "Moss Charger", "苔藓冲锋者" },
            { "Moss Flyer", "苔藓飞虫" },
            { "Moss Knight", "苔藓骑士" },
            { "Moss Knight Fat", "肥胖苔藓骑士" },
            { "Moss Walker", "苔藓行者" },
            { "Mossman_Runner", "苔藓人·奔跑者" },
            { "Mossman_Shaker", "苔藓人·摇荡者" },
            { "Mushroom Baby", "幼菇" },
            { "Mushroom Brawler", "蘑菇拳手" },
            { "Mushroom Roller", "滚球蘑菇" },
            { "Mushroom Turret", "蘑菇炮台" },
            { "Ordeal Zoteling", "试炼小佐特" },
            { "Oro", "奥罗" },
            { "Parasite Balloon", "寄生气球" },
            { "Pigeon", "鸽子" },
            { "Plant Trap", "植物陷阱" },
            { "Plant Turret", "植物炮台" },
            { "Prayer Slug", "祈祷蛞蝓" },
            { "Roller", "滚球虫" },
            { "Royal Gaurd", "皇家守卫" },
            { "Royal Zombie", "皇家行尸" },
            { "Royal Zombie Coward", "胆小皇家行尸" },
            { "Royal Zombie Fat", "肥胖皇家行尸" },
            { "Ruins Flying Sentry", "遗迹飞行哨卫" },
            { "Ruins Flying Sentry Javelin", "遗迹飞行标枪哨卫" },
            { "Ruins Sentry", "遗迹哨卫" },
            { "Ruins Sentry 1", "遗迹哨卫一型" },
            { "Ruins Sentry Fat", "肥胖遗迹哨卫" },
            { "Ruins Sentry Fat B", "肥胖遗迹哨卫乙型" },
            { "Shade Sibling", "暗影同胞" },
            { "Sheo Boss", "西奥（首领）" },
            { "Slash Spider", "挥砍蜘蛛" },
            { "Spider Flyer", "飞行蜘蛛" },
            { "Spider Mini", "迷你蜘蛛" },
            { "Spitter", "喷吐者" },
            { "Spitting Zombie", "喷吐行尸" },
            { "Super Spitter", "超级喷吐者" },
            { "Tiny Spider", "小蜘蛛" },
            { "White Palace Fly", "白色宫殿飞蝇" },
            { "Worm", "蠕虫" },
            { "Worm 1", "蠕虫一型" },
            { "Worm 2", "蠕虫二型" },
            { "Worm 3", "蠕虫三型" },
            { "Zap Cloud", "电击云" },
            { "Zombie Barger", "冲撞行尸" },
            { "Zombie Beam Miner", "光束矿工行尸" },
            { "Zombie Fungus A", "真菌行尸甲型" },
            { "Zombie Fungus B", "真菌行尸乙型" },
            { "Zombie Guard", "行尸守卫" },
            { "Zombie Hive", "蜂巢行尸" },
            { "Zombie Hornhead", "角头行尸" },
            { "Zombie Hornhead Sp", "角头行尸（喷吐）" },
            { "Zombie Leaper", "跳跃行尸" },
            { "Zombie Miner", "矿工行尸" },
            { "Zombie Myla", "米拉行尸" },
            { "Zombie Runner", "奔跑行尸" },
            { "Zombie Runner Sp", "奔跑行尸（喷吐）" },
            { "Zombie Shield", "持盾行尸" },
            { "Zombie Spider 1", "蜘蛛行尸一型" },
            { "Zombie Spider 2", "蜘蛛行尸二型" },
            { "Zote Balloon", "佐特气球" },
            { "Zote Crew Fat", "佐特船员（胖）" },
            { "Zote Crew Tall", "佐特船员（高）" },
            { "Zote Salubra", "佐特萨鲁布拉" },
            { "Zote Turret", "佐特炮台" },
            { "Zoteling", "小佐特" },
            { "fluke_baby_01", "吸虫幼体一号" },
            { "fluke_baby_02", "吸虫幼体二号" },
            { "fluke_baby_03", "吸虫幼体三号" },
            { "stomper_fast", "践踏者（快速）" },
            { "stomper_offset", "践踏者（错位）" },

            // ---- enemy names, second wave (LSCR-ZH-37) ----
            // Corpus = the full enemyNames category of the on-device database
            // dump (EnemyRandomizerDatabase.xml, 221 entries) diffed against
            // wave 1 - these are the bosses/colosseum/variant prefabs the
            // single gameplay round never happened to spawn. With this wave
            // the Enemy Enabler / Enemy Filter lists are fully covered.
            { "Enemy Randomizer", "敌人随机器" },
            { "Enable MSLP Journal Mode", "启用 MSLP 图鉴模式" },
            { "If enabled, killed enemies will give you the journal entry of the one they replaced", "开启后，杀死的敌人会把它所替换对象的图鉴条目记给你" },
            { "Scale Enemies", "缩放敌人" },
            { "Scale Hazards", "缩放危害物" },
            { "Scale Effects", "缩放特效" },
            { "Should this effect randomized enemies?", "此项是否作用于随机化后的敌人？" },
            { "Should this effect randomized hazards?", "此项是否作用于随机化后的危害物？" },
            { "Should this effect randomized effects?", "此项是否作用于随机化后的特效？" },
            { "Absolute Radiance", "绝对辐光" },
            { "Abyss Tendrils", "深渊触须" },
            { "Acid Flyer", "酸液飞虫" },
            { "Bee Dropper", "蜂巢投递蜂" },
            { "Big Bee", "巨蜂" },
            { "Blobble", "弹跳黏球" },
            { "Blocker", "格挡虫" },
            { "Buzzer Col", "鸣蜂（斗兽场）" },
            { "Buzzer R", "鸣蜂·R" },
            { "Ceiling Dropper Col", "顶棚潜伏虫（斗兽场）" },
            { "Centipede Hatcher", "蜈蚣孵化体" },
            { "Colosseum Grass Hopper", "斗兽场草跳虫" },
            { "Colosseum_Armoured_Mosquito", "斗兽场装甲蚊" },
            { "Colosseum_Armoured_Mosquito R", "斗兽场装甲蚊·R" },
            { "Colosseum_Armoured_Roller R", "斗兽场装甲滚虫·R" },
            { "Colosseum_Worm", "斗兽场蠕虫" },
            { "Dream Mage Lord Phase2", "梦魇法师领主（二阶段）" },
            { "Egg Sac", "卵囊" },
            { "Electric Mage", "电击法师" },
            { "False Knight Dream", "假骑士（梦境）" },
            { "Flamebearer Large", "燃焰者（大）" },
            { "Flamebearer Med", "燃焰者（中）" },
            { "Flamebearer Small", "燃焰者（小）" },
            { "Flamebearer Spawn", "燃焰者衍生物" },
            { "Flukeman Bot", "吸虫人（下段）" },
            { "Flukeman Top", "吸虫人（上段）" },
            { "Fungus Flyer", "真菌飞虫" },
            { "Ghost Warrior Hu", "鬼魂武士·胡" },
            { "Ghost Warrior Markoth", "鬼魂武士·马克欧斯" },
            { "Ghost Warrior Marmu", "鬼魂武士·玛尔穆" },
            { "Ghost Warrior No Eyes", "鬼魂武士·无眼者" },
            { "Ghost Warrior Slug", "鬼魂武士·蛞蝓" },
            { "Ghost Warrior Xero", "鬼魂武士·泽罗" },
            { "Giant Buzzer", "巨型鸣蜂" },
            { "Giant Fly", "巨型飞蝇" },
            { "Giant Fly Col", "巨型飞蝇（斗兽场）" },
            { "Great Shield Zombie bottom", "巨盾行尸（下段）" },
            { "Grimm Boss", "格林（首领）" },
            { "Grub Mimic", "幼虫拟态者" },
            { "Grub Mimic Bottle", "幼虫拟态者（瓶中）" },
            { "HK Prime", "空洞骑士（本体）" },
            { "Hatcher Baby", "孵化者幼体" },
            { "Health Cocoon", "生命茧" },
            { "Health Scuttler", "生命疾行虫" },
            { "Hive Knight", "蜂巢骑士" },
            { "Hollow Knight Boss", "空洞骑士（首领）" },
            { "Jelly Egg Bomb", "水母卵炸弹" },
            { "Jellyfish GG", "水母（万神殿）" },
            { "Lancer", "长矛虫" },
            { "Lil Jellyfish", "迷你水母" },
            { "Mace Head Bug", "锤头虫" },
            { "Mage Lord", "法师领主" },
            { "Mage Lord Phase2", "法师领主（二阶段）" },
            { "Mantis Heavy Flyer", "重装螳螂飞兵" },
            { "Mantis Heavy Spawn", "重装螳螂（衍生）" },
            { "Mantis Traitor Lord", "螳螂叛徒领主" },
            { "Mawlek Body", "毛里克躯体" },
            { "Mawlek Col", "毛里克（斗兽场）" },
            { "Mawlek Turret Ceiling", "毛里克炮台（顶棚）" },
            { "Mega Jellyfish", "巨型水母" },
            { "Mega Zombie Beam Miner", "超级光束矿工行尸" },
            { "Nightmare Grimm Boss", "梦魇格林（首领）" },
            { "Pale Lurker", "苍白潜伏者" },
            { "Plant Turret Right", "植物炮台（右向）" },
            { "Radiance", "辐光" },
            { "Roller R", "滚球虫·R" },
            { "Sly Boss", "斯莱（首领）" },
            { "Spitter R", "喷吐者·R" },
            { "Super Spitter Col", "超级喷吐者（斗兽场）" },
            { "Super Spitter R", "超级喷吐者·R" },
            { "White Defender", "白色防御者" },
            { "Zombie Beam Miner Rematch", "光束矿工行尸（再战）" },
            { "Zote Balloon Ordeal", "佐特气球（试炼）" },
            { "Zote Boss", "佐特（首领）" },
            { "Zote Crew Normal", "佐特船员（普通）" },
            { "Zote Fluke", "佐特吸虫" },
            { "Zote Thwomp", "佐特砸击者" },
            { "Zoteling Buzzer", "小佐特鸣蜂" },
            { "Zoteling Hopper", "小佐特跳虫" },
        };
    }

    public class ZhLocalizerBehaviour : MonoBehaviour
    {
        private readonly Dictionary<Text, string> _map = new Dictionary<Text, string>();
        private Font _cjk;
        private float _nextScan;
        private Mod _log;

        public void Init(Mod log)
        {
            _log = log;
            _cjk = FindCjkFont();
            if (_cjk == null)
            {
                if (_log != null) _log.Log("LSCR-ZH-28: no CJK font found - menu localiser stays OFF (menus remain English)");
                enabled = false;
                return;
                }
            if (_log != null) _log.Log("LSCR-ZH-28: localiser up, font=" + _cjk.name + ", entries=" + ZhStrings.Zh.Count);
            if (_log != null) _log.Log("LSCR-ZH-37: enemy-name entries merged (display-only, base-name matching on)");
        }

        // LSCR-ZH-37: scene objects reach the menus with instance suffixes
        // ("Angry Buzzer (1)", "Corpse Garden Zombie(Clone)"); the dictionary
        // carries base names only. Strip the suffix before lookup so one
        // entry covers a whole family. Pure string op - never touches keys.
        internal static string BaseKey(string s)
        {
            if (string.IsNullOrEmpty(s)) return s;
            string t = s.TrimEnd();
            const string clone = "(Clone)";
            if (t.EndsWith(clone, StringComparison.Ordinal))
                t = t.Substring(0, t.Length - clone.Length).TrimEnd();
            int open = t.LastIndexOf('(');
            if (open > 0 && t.EndsWith(")", StringComparison.Ordinal))
            {
                string mid = t.Substring(open + 1, t.Length - open - 2);
                bool allDigits = mid.Length > 0;
                foreach (char c in mid) if (c < '0' || c > '9') { allDigits = false; break; }
                if (allDigits) t = t.Substring(0, open).TrimEnd();
            }
            return t;
        }

        // The Modding API's menu resource bundle exposes the game's bundled
        // CJK font as a property; fall back to a direct Resources load.
        private static Font FindCjkFont()
        {
            try
            {
                var t = typeof(ModHooks).Assembly.GetType("Modding.Menu.MenuResources");
                if (t != null)
                {
                    var p = t.GetProperty("NotoSerifCJKSCRegular",
                        System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.NonPublic
                        | System.Reflection.BindingFlags.Static | System.Reflection.BindingFlags.Instance);
                    if (p != null)
                    {
                        object v = null;
                        try { v = p.GetValue(null, null); }
                        catch
                        {
                            var inst = Resources.FindObjectsOfTypeAll(t);
                            if (inst != null && inst.Length > 0) v = p.GetValue(inst[0], null);
                        }
                        var f = v as Font;
                        if (f != null) return f;
                    }
                }
            }
            catch { }
            try
            {
                var f2 = Resources.Load<Font>("NotoSerifCJKSCRegular");
                if (f2 != null) return f2;
            }
            catch { }
            return null;
        }

        private void Update()
        {
            if (Time.unscaledTime < _nextScan) return;
            _nextScan = Time.unscaledTime + 0.4f;
            try
            {
                Scan();
            }
            catch (Exception e)
            {
                if (_log != null) _log.Log("LSCR-ZH-28: scan swallowed " + e.GetType().Name);
                enabled = false;
            }
        }

        private void Scan()
        {
            // drop destroyed components
            var dead = new List<Text>();
            foreach (var kv in _map) if (kv.Key == null) dead.Add(kv.Key);
            foreach (var d in dead) _map.Remove(d);

            foreach (var t in FindObjectsOfType<Text>())
            {
                if (t == null || _map.ContainsKey(t)) continue;
                string cur;
                try { cur = t.text; } catch { continue; }
                if (cur == null) continue;
                if (ZhStrings.Zh.ContainsKey(cur))
                {
                    _map[t] = cur;
                    Apply(t);
                }
                else
                {
                    // LSCR-ZH-37: instance-suffixed enemy labels match on
                    // their base name ("Angry Buzzer (1)" -> "Angry Buzzer").
                    string bk = BaseKey(cur);
                    if (!ReferenceEquals(bk, cur) && bk != cur && ZhStrings.Zh.ContainsKey(bk))
                    {
                        _map[t] = bk;
                        Apply(t);
                    }
                }
            }
        }

        // Satchel re-sets Label/Description from the English keys in its own
        // Update; LateUpdate runs after that and before rendering, so the
        // player never sees the English flash back.
        private void LateUpdate()
        {
            if (_map.Count == 0) return;
            foreach (var kv in _map)
            {
                var t = kv.Key;
                if (t == null) continue;
                string zh;
                if (!ZhStrings.Zh.TryGetValue(kv.Value, out zh)) continue;
                if (t.text != zh) Apply(t);
            }
        }

        private void Apply(Text t)
        {
            string zh;
            if (!ZhStrings.Zh.TryGetValue(_map.ContainsKey(t) ? _map[t] : t.text, out zh)) return;
            t.text = zh;
            if (_cjk != null && t.font != _cjk) t.font = _cjk;
        }
    }
}
