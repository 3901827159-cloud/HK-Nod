using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Threading;
using Modding;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace CrashRecorderMod
{
    public class CrashRecorder : Mod
    {
        private static readonly object _lock = new object();
        private static bool _guardsInstalled;
        private static int _blockedCount;

        // 刷怪记录用
        private static readonly HashSet<string> _seenEnemies = new HashSet<string>();
        private static int _enemyLogCount;
        private static string _enemyFile;

        public CrashRecorder()
        {
            Log("CrashRecorder v6-64: constructor");
        }

        public override void Initialize()
        {
            Log("CrashRecorder v6-64: Initialize called");

            // ============ 第零部分：managed 日志监听（v6-64 新增） ============
            // 64 位新解释器上两条子进程通道全坏（ProcessBuilder NoSuchMethodError、
            // Process.Start 同病），v5 的 capture 腿等于断了。引擎自己会把每条
            // Error/Exception/Assert 推给订阅者——直接订阅、实时落盘，不需要
            // 子进程：managed 层崩溃（空引用/缺方法/钩子链腐蚀）全带栈经过这里。
            try
            {
                string dir0 = Path.Combine(Application.persistentDataPath, "CrashRecorder");
                Directory.CreateDirectory(dir0);
                InstallManagedSink(dir0, DateTime.Now.ToString("yyyyMMdd_HHmmss"));
            }
            catch (Exception e0)
            {
                Log("CrashRecorder v6-64: managed sink boot failed: " + e0.Message);
            }

            // ============ 第一部分：logcat 抓取（沿用 v2，功能不变） ============
            try
            {
                string dir = Path.Combine(Application.persistentDataPath, "CrashRecorder");
                Directory.CreateDirectory(dir);
                Log("CrashRecorder v6-64: dir = " + dir);

                string stamp = DateTime.Now.ToString("yyyyMMdd_HHmmss");

                // 1) 启动瞬间先把系统日志缓冲区的最后 6000 行倒出来。
                //    系统日志由系统服务保管，游戏重启后还在；
                //    如果上一次是闪退，崩溃的底层记录就在这里面。这是最稳的一道保险。
                string snap = Path.Combine(dir, "snapshot_" + stamp + ".txt");
                StartLogcat("exec /system/bin/logcat -d -v time -t 6000 >> '" + snap + "' 2>&1", "snapshot", snap);

                // 2) 再启动一个常驻后台进程，持续把系统日志写进文件。
                //    游戏闪退后它会继续活着，把崩溃瞬间那几行补写进文件。
                string session = Path.Combine(dir, "capture_" + stamp + ".txt");
                StartLogcat("pkill -x logcat >/dev/null 2>&1; echo '== stream start ==' >> '" + session + "'; exec /system/bin/logcat -v time >> '" + session + "' 2>&1", "stream", session);

                // 3) 顺手把游戏引擎自己的崩溃报告也倒出来（如果有）
                DumpUnityCrashReports(dir);

                // 3b) v6-64：原生崩溃缓冲区转储。子进程接口坏了，但
                //     Runtime.exec(String[]) 还在；输出交给 shell 重定向，
                //     不需要读流（读流才是坏掉的那半）。
                try
                {
                    string crashbuf = Path.Combine(dir, "crashbuf_" + stamp + ".txt");
                    using (var rtClass = new AndroidJavaClass("java.lang.Runtime"))
                    using (var rt = rtClass.CallStatic<AndroidJavaObject>("getRuntime"))
                    using (rt.Call<AndroidJavaObject>("exec", new object[] {
                        new string[] { "/system/bin/sh", "-c",
                            "logcat -b crash -d -v time > '" + crashbuf + "' 2>&1" } }))
                    { }
                    Log("CrashRecorder v6-64: crash-buffer dump launched -> " + crashbuf);
                }
                catch (Exception eb)
                {
                    Log("CrashRecorder v6-64: crash-buffer dump failed: " + eb.GetType().Name + ": " + eb.Message);
                }

                // 4) 3 秒后自查一次：文件到底写出来没有，结果直接进游戏日志
                Thread checker = new Thread(delegate()
                {
                    Thread.Sleep(3000);
                    try
                    {
                        FileInfo fi = new FileInfo(snap);
                        FileInfo fc = new FileInfo(session);
                        Log("CrashRecorder v6-64: check after 3s -> snapshot exists=" + fi.Exists + " size=" + (fi.Exists ? fi.Length.ToString() : "0")
                            + " ; capture exists=" + fc.Exists + " size=" + (fc.Exists ? fc.Length.ToString() : "0"));
                    }
                    catch (Exception e)
                    {
                        Log("CrashRecorder v6-64: check failed: " + e.Message);
                    }
                });
                checker.IsBackground = true;
                checker.Start();
            }
            catch (Exception e)
            {
                Log("CrashRecorder v6-64: recorder FAILED: " + e);
            }

            // ============ 第二部分：对象池空引用防护 ============
            // 崩溃根因：EnemyRandomizer 替换敌人时，如果缓存包里缺某个替换对象，
            // 它会传一个 null 的 prefab 进 ObjectPool.CreatePool；游戏原版代码在这里
            // 没有 null 检查，Instantiate(null) 之后直接 GetComponent -> 闪退。
            InstallPoolGuards();

            // ============ 第三部分：刷怪记录 ============
            // 目的：随机器数据库里有 11 个敌人任何场景都查不到落点（斗技场波次、
            // 灰烬帐篷、Flukeman 两截这类运行时才刷的）。与其去拆 700MB 整包，
            // 不如让游戏自己报——每个带 HealthManager 的东西被激活时记一条
            // 「场景 + 名字」，同一场景同名只记一次，跑一趟就攒出一张完整的
            // 敌人落点表。记录写进 CrashRecorder/enemies_时间戳.txt。
            InstallEnemyLogger();
        }

        // ---- v6-64 managed sink ------------------------------------------
        private string _crashFile;
        private string _sessionStartFile;
        private readonly Dictionary<string, int> _errorSeen = new Dictionary<string, int>();
        private int _errorLines;
        private const int ErrorLineCap = 300;

        private void InstallManagedSink(string dir, string stamp)
        {
            _crashFile = Path.Combine(dir, "crash_" + stamp + ".txt");
            File.WriteAllText(_crashFile,
                "# crash log v6-64 (Exception/Assert immediate with stack, Error deduped+capped, pulse every 15s)\n");

            // 上一次会话的死法判定：有 .start 没 .end = 没走优雅退出（崩/冻/被杀）。
            try
            {
                foreach (string f in Directory.GetFiles(dir, "session_*.start"))
                {
                    string endf = f.Substring(0, f.Length - ".start".Length) + ".end";
                    if (!File.Exists(endf))
                        Log("CrashRecorder v6-64: previous session ended UNNATURALLY: " + Path.GetFileName(f));
                    try { File.Delete(endf); } catch { }
                    try { File.Delete(f); } catch { }
                }
                _sessionStartFile = Path.Combine(dir, "session_" + stamp + ".start");
                File.WriteAllText(_sessionStartFile, DateTime.Now.ToString("o"));
            }
            catch (Exception e) { Log("CrashRecorder v6-64: session marker failed: " + e.Message); }

            try { Application.quitting += OnQuitting; }
            catch (Exception e) { Log("CrashRecorder v6-64: quitting hook failed: " + e.Message); }

            try
            {
                Application.logMessageReceivedThreaded += OnLog;
                Log("CrashRecorder v6-64: managed log sink armed -> " + _crashFile);
            }
            catch (Exception e)
            {
                Log("CrashRecorder v6-64: managed sink unavailable: " + e.Message);
            }

            // 心跳：冻死/卡死类事故没有异常可抓，靠脉搏定位死在哪个场景。
            Thread pulse = new Thread(delegate()
            {
                while (true)
                {
                    Thread.Sleep(15000);
                    try
                    {
                        AppendCrash("pulse | scene=" + UnityEngine.SceneManagement.SceneManager.GetActiveScene().name
                            + " | mem=" + (GC.GetTotalMemory(false) / 1048576L) + "MB"
                            + " | enemies=" + _enemyLogCount);
                    }
                    catch { }
                }
            });
            pulse.IsBackground = true;
            pulse.Start();
        }

        private void OnQuitting()
        {
            try
            {
                AppendCrash("session quitting gracefully");
                if (_sessionStartFile != null)
                    File.WriteAllText(_sessionStartFile.Replace(".start", ".end"), DateTime.Now.ToString("o"));
            }
            catch { }
        }

        private void OnLog(string condition, string stackTrace, LogType type)
        {
            try
            {
                if (type == LogType.Exception || type == LogType.Assert)
                {
                    AppendCrash(type + " | scene=" + UnityEngine.SceneManagement.SceneManager.GetActiveScene().name + " | " + condition
                        + "\n--- stack ---\n" + stackTrace + "\n--- end stack ---");
                    return;
                }
                if (type == LogType.Error)
                {
                    lock (_lock)
                    {
                        int n;
                        _errorSeen.TryGetValue(condition, out n);
                        n++;
                        _errorSeen[condition] = n;
                        if (n > 3) return; // 同款错误只记前三次（死循环刷屏防护）
                        if (_errorLines >= ErrorLineCap) return;
                        _errorLines++;
                    }
                    AppendCrash("Error | scene=" + UnityEngine.SceneManagement.SceneManager.GetActiveScene().name + " | " + condition);
                }
            }
            catch { }
        }

        private void AppendCrash(string line)
        {
            if (_crashFile == null) return;
            try
            {
                lock (_lock)
                {
                    File.AppendAllText(_crashFile, DateTime.Now.ToString("HH:mm:ss.fff") + " " + line + "\n");
                }
            }
            catch { }
        }

        // 优先用手机系统自带的接口拉起进程（最稳），失败再走备用通道
        private void StartLogcat(string shellCommand, string tag, string outFile)
        {
            try
            {
                StartViaJava(shellCommand);
                Log("CrashRecorder v6-64: " + tag + " started (system way), file = " + outFile);
                return;
            }
            catch (Exception e1)
            {
                Log("CrashRecorder v6-64: " + tag + " system way failed: " + e1.Message);
            }

            try
            {
                ProcessStartInfo psi = new ProcessStartInfo();
                psi.FileName = "/system/bin/sh";
                psi.Arguments = "-c \"" + shellCommand.Replace("\"", "\\\"") + "\"";
                psi.UseShellExecute = false;
                Process p = Process.Start(psi);
                Log("CrashRecorder v6-64: " + tag + " started (fallback way), pid=" + (p == null ? "null" : p.Id.ToString()) + ", file = " + outFile);
            }
            catch (Exception e2)
            {
                Log("CrashRecorder v6-64: " + tag + " fallback failed: " + e2);
            }
        }

        private static void StartViaJava(string shellCommand)
        {
            AndroidJavaObject pb = new AndroidJavaObject("java.lang.ProcessBuilder", "/system/bin/sh", "-c", shellCommand);
            try
            {
                pb.Call<AndroidJavaObject>("redirectErrorStream", true);
                pb.Call<AndroidJavaObject>("start");
            }
            finally
            {
                pb.Dispose();
            }
        }

        private void DumpUnityCrashReports(string dir)
        {
            try
            {
                CrashReport[] reports = CrashReport.reports;
                int n = reports == null ? 0 : reports.Length;
                Log("CrashRecorder v6-64: engine crash reports = " + n);
                for (int i = 0; i < n; i++)
                {
                    try
                    {
                        string txt = reports[i].text;
                        if (string.IsNullOrEmpty(txt)) txt = "(empty)";
                        File.WriteAllText(Path.Combine(dir, "enginecrash_" + i + ".txt"), txt);
                    }
                    catch { }
                }
            }
            catch (Exception e)
            {
                Log("CrashRecorder v6-64: engine crash report api failed: " + e.Message);
            }
        }

        // =====================================================================
        //  对象池空引用防护
        //
        //  崩溃根因：EnemyRandomizer 替换敌人时，如果缓存包里缺某个替换对象，
        //  它会传一个 null 的 prefab 进 ObjectPool.CreatePool；游戏原版代码在这里
        //  没有 null 检查，Instantiate(null) 之后直接 GetComponent -> 闪退。
        //
        //  做法：挂 MMHOOK 的 On.ObjectPool.CreatePool / On.PersonalObjectPool.CreatePool。
        //  本 mod 是最先加载的，hook 装得最早、位于 hook 链最内层，
        //  所以 EnemyRandomizer 传出来的 null 一定会先穿过我们这里 —— 正好拦住。
        // =====================================================================
        private void InstallPoolGuards()
        {
            lock (_lock)
            {
                if (_guardsInstalled) return;
                _guardsInstalled = true;
            }

            int installed = 0;

            try
            {
                On.ObjectPool.CreatePool += PoolGuard_CreatePool;
                installed++;
                Log("CrashRecorder v6-64: ObjectPool.CreatePool guard installed");
            }
            catch (Exception e)
            {
                Log("CrashRecorder v6-64: ObjectPool.CreatePool guard install failed: " + e.Message);
            }

            try
            {
                On.PersonalObjectPool.CreatePool += PoolGuard_PersonalCreatePool;
                installed++;
                Log("CrashRecorder v6-64: PersonalObjectPool.CreatePool guard installed");
            }
            catch (Exception e)
            {
                Log("CrashRecorder v6-64: PersonalObjectPool.CreatePool guard install failed: " + e.Message);
            }

            if (installed > 0)
            {
                StartBlockReporter();
            }
        }

        private static void PoolGuard_CreatePool(On.ObjectPool.orig_CreatePool orig, UnityEngine.GameObject prefab, int count)
        {
            if (prefab == null)
            {
                int n = Interlocked.Increment(ref _blockedCount);
                if (n <= 50)
                {
                    Emit("CrashRecorder v6-64: BLOCKED null prefab (ObjectPool.CreatePool) (block #" + n + ")");
                }
                else if (n % 200 == 0)
                {
                    Emit("CrashRecorder v6-64: BLOCKED null prefab (ObjectPool.CreatePool) (block total #" + n + ")");
                }
                if (n <= 5 || n % 50 == 0) EmitCallerStack("CreatePool");
                return; // 这个敌人不创建池（不会出现），但游戏不会崩
            }
            orig(prefab, count);
        }

        private static void PoolGuard_PersonalCreatePool(On.PersonalObjectPool.orig_CreatePool orig, PersonalObjectPool self, UnityEngine.GameObject prefab, int count)
        {
            if (prefab == null)
            {
                string name = "unknown";
                try { name = self == null ? "unknown" : self.name; } catch { }
                int n = Interlocked.Increment(ref _blockedCount);
                if (n <= 50)
                {
                    Emit("CrashRecorder v6-64: BLOCKED null prefab (PersonalObjectPool " + name + ") (block #" + n + ")");
                }
                else if (n % 200 == 0)
                {
                    Emit("CrashRecorder v6-64: BLOCKED null prefab (PersonalObjectPool " + name + ") (block total #" + n + ")");
                }
                if (n <= 5 || n % 50 == 0) EmitCallerStack("PersonalCreatePool:" + name);
                return;
            }
            orig(self, prefab, count);
        }

        // =====================================================================
        //  刷怪记录
        //
        //  挂 On.HealthManager.OnEnable：任何带血量的东西被激活的瞬间，它就在
        //  它出生的那个场景里。同一场景同名只记一次（去重集合），所以日志量
        //  = 场景数 × 每场景的 distinct 敌人数，不会刷屏。
        //
        //  两条输出：
        //   1) 独立文件 enemies_时间戳.txt（跟 capture 文件同目录，发我这一个就够）
        //   2) 游戏日志一条汇总（方便手机上看有没有在记）
        // =====================================================================
        private void InstallEnemyLogger()
        {
            try
            {
                string dir = Path.Combine(Application.persistentDataPath, "CrashRecorder");
                Directory.CreateDirectory(dir);
                _enemyFile = Path.Combine(dir, "enemies_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".txt");
                File.WriteAllText(_enemyFile, "# enemy log (scene|enemy per line, deduped per scene)\r\n");
                Log("CrashRecorder v6-64: enemy log file = " + _enemyFile);
            }
            catch (Exception e)
            {
                Log("CrashRecorder v6-64: enemy log file init failed: " + e.Message);
            }

            try
            {
                On.HealthManager.OnEnable += EnemyLogger_OnEnable;
                Log("CrashRecorder v6-64: enemy logger installed (HealthManager.OnEnable)");
            }
            catch (Exception e)
            {
                Log("CrashRecorder v6-64: enemy logger install failed: " + e.Message);
            }
        }

        private static void EnemyLogger_OnEnable(On.HealthManager.orig_OnEnable orig, HealthManager self)
        {
            try
            {
                RecordEnemy(self);
            }
            catch
            {
                // 记录失败绝不影响游戏本体
            }
            orig(self);
        }

        private static void RecordEnemy(HealthManager hm)
        {
            if (hm == null) return;
            Transform t = hm.transform;
            if (t == null) return;

            string scene;
            try
            {
                Scene s = t.gameObject.scene;
                scene = s.IsValid() ? s.name : "(no scene)";
            }
            catch
            {
                scene = "(no scene)";
            }

            string name = t.name;
            if (name != null && name.EndsWith("(Clone)"))
            {
                name = name.Substring(0, name.Length - 7);
            }

            string key = scene + "|" + name;
            if (!_seenEnemies.Add(key)) return; // 同场景同名只记一次

            int n = Interlocked.Increment(ref _enemyLogCount);
            string line = scene + "|" + name;

            // 文件追加（去重后量很小），失败不影响游戏
            try
            {
                if (_enemyFile != null)
                {
                    File.AppendAllText(_enemyFile, line + "\r\n");
                }
            }
            catch
            {
                _enemyFile = null; // 文件写不动就只走游戏日志，别反复抛异常
            }

            // 前 300 条逐条进游戏日志，之后每 200 条报一次总数，控制刷屏
            if (n <= 300 || n % 200 == 0)
            {
                Emit("ENEMY #" + n + " scene=" + scene + " enemy=" + name);
            }
        }

        // 后台线程：每当拦截计数变化，把数字打进日志（守卫本体里少干活，别拖慢游戏）
        private static void StartBlockReporter()
        {
            try
            {
                Thread t = new Thread(delegate()
                {
                    int last = 0;
                    while (true)
                    {
                        try
                        {
                            Thread.Sleep(2000);
                            int now = _blockedCount;
                            if (now != last)
                            {
                                Emit("CrashRecorder v6-64: null-prefab blocks changed +" + (now - last) + " (total " + now + ")");
                                last = now;
                            }
                        }
                        catch
                        {
                            return;
                        }
                    }
                });
                t.IsBackground = true;
                t.Start();
            }
            catch { }
        }

        // 空对象是谁传进来的？打一截调用堆栈出来，好定位缺成品的是哪一批敌人。
        // 只在 BLOCKED 的头几次和每 50 次时打一次，避免刷屏。
        private static void EmitCallerStack(string tag)
        {
            try
            {
                string st = Environment.StackTrace;
                if (string.IsNullOrEmpty(st)) return;
                string[] lines = st.Split(new char[] { '\n' });
                List<string> keep = new List<string>();
                for (int i = 0; i < lines.Length && keep.Count < 7; i++)
                {
                    string l = lines[i].Trim();
                    if (l.Length == 0) continue;
                    if (l.Contains("EmitCallerStack") || l.Contains("get_StackTrace")) continue;
                    if (l.Contains("PoolGuard_")) continue;
                    keep.Add(l);
                }
                if (keep.Count == 0) return;
                Emit("CrashRecorder v6-64: STACK[" + tag + "] " + string.Join(" <- ", keep.ToArray()));
            }
            catch
            {
                // 堆栈拿不到就算了，不影响守卫本身
            }
        }

        private static void Emit(string msg)
        {
            string line = "[CrashRecorder] - " + msg;
            // CR_DEBUG_STDERR=1 时走 stderr（本地 mono 验证用；手机上不设置，走正常 Unity 日志）
            try
            {
                if (Environment.GetEnvironmentVariable("CR_DEBUG_STDERR") == "1")
                {
                    Console.Error.WriteLine(line);
                    return;
                }
            }
            catch { }
            try
            {
                UnityEngine.Debug.Log(line);
            }
            catch { }
        }
    }
}
