#!/bin/bash
set -e
cd "$(dirname "$0")"
mkdir -p out
CSC=$(find /usr/share/dotnet /usr/lib/dotnet -name csc.dll -path '*bincore*' 2>/dev/null | head -1)
if [ -z "$CSC" ]; then echo "FATAL: csc.dll not found"; exit 1; fi
echo "using compiler: $CSC"
DEF=/define:UNITY_2018_3_OR_NEWER,UNITY_2019_3_OR_NEWER,UNITY_2020_1_OR_NEWER,UNITY_2020_2_OR_NEWER
R=$(ls refs/*.dll | sed 's|^|/r:|' | tr '\n' ' ')
find src/EnemyRandomizerDB -name '*.cs' | sort > db.srcs
find src/EnemyRandomizer -name '*.cs' | sort > er.srcs
dotnet "$CSC" -nologo -noconfig -target:library -optimize+ -langversion:latest $DEF -out:out/EnemyRandomizerDB.dll $R @db.srcs
dotnet "$CSC" -nologo -noconfig -target:library -optimize+ -langversion:latest $DEF -out:out/EnemyRandomizer.dll $R /r:out/EnemyRandomizerDB.dll @er.srcs
ls -la out/
