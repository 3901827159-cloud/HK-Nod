#!/bin/bash
set -e
cd "$(dirname "$0")"
mkdir -p out
CSC=$(find /usr/share/dotnet /usr/lib/dotnet -name csc.dll -path '*bincore*' 2>/dev/null | head -1)
if [ -z "$CSC" ]; then echo "FATAL: csc.dll not found"; exit 1; fi
echo "using compiler: $CSC"
DEF=/define:UNITY_2018_3_OR_NEWER,UNITY_2019_3_OR_NEWER,UNITY_2020_1_OR_NEWER,UNITY_2020_2_OR_NEWER
R=$(ls refs/*.dll | sed 's|^|/r:|' | tr '\n' ' ')
find src/EnemyRandomizerDB -name '*.cs' | grep -v 'TextMeshProAsyncExtensions.InputField1.cs' | sort > db.srcs
find src/EnemyRandomizer -name '*.cs' | grep -vE 'Mod/(BattleManager|BattleStateMachine|ManagedObject|ObjectMetadata|TEMPLATE_LOGIC_MODULE)\.cs' | sort > er.srcs
dotnet "$CSC" -nologo -noconfig -target:library -optimize+ -langversion:latest $DEF -out:out/EnemyRandomizerDB.dll $R @db.srcs
dotnet "$CSC" -nologo -noconfig -target:library -optimize+ -langversion:latest $DEF -out:out/EnemyRandomizer.dll $R /r:out/EnemyRandomizerDB.dll @er.srcs
find src/CrashRecorder -name '*.cs' | sort > cr.srcs
dotnet "$CSC" -nologo -noconfig -target:library -optimize+ -langversion:latest $DEF -out:out/CrashRecorder.dll $R @cr.srcs
find src/RepackBridge -name '*.cs' | sort > rb.srcs
dotnet "$CSC" -nologo -noconfig -target:library -optimize+ -langversion:latest $DEF -out:out/RepackBridge64.dll $R @rb.srcs
ls -la out/
